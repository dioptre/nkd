﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace LumiSoft.SIP.UA.UI
{
    /// <summary>
    /// Settings -> Account window.
    /// </summary>
    public class wfrm_Settings_Account : Form
    {
        private Label   mt_DisplayName = null;
        private TextBox m_pDisplayName = null;
        private Label   mt_AOR         = null;
        private TextBox m_pAOR         = null;
        //-
        private CheckBox m_pUseProxy = null;
        //-
        private CheckBox      m_pRegister        = null;
        private Label         mt_RegistrarServer = null;
        private TextBox       m_pRegistrarServer = null;
        private Label         mt_RefreshInterval = null;
        private NumericUpDown m_pRefreshInterval = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Settings_Account()
        {
            InitUI();
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            
        }

        #endregion
    }
}
