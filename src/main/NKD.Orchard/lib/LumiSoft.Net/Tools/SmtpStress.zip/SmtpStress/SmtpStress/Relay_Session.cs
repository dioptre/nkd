using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Net;

using LumiSoft.Net;
using LumiSoft.Net.SMTP.Client;
using LumiSoft.Net.Mime;

namespace SmtpStress
{
    /// <summary>
    /// This class implements relay server session.
    /// </summary>
    public class Relay_Session
    {
        private Relay_Server m_pRelayServer    = null;
        private string       m_MessageFile     = "";
        private FileStream   m_pMessageStream  = null;
        private string       m_SessionID       = "";
        private DateTime     m_SessionStartTime;
        private SmtpClientEx m_pSmtpClient     = null;
        private IPEndPoint   m_pRemoteEndPoint = null;
        private long         m_ReadedCount     = 0;
        private long         m_WrittenCount    = 0;
        private bool         m_Ended           = false;

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="server">Reference to owner relay server.</param>
        /// <param name="file">Message file to relay.</param>
        public Relay_Session(Relay_Server server,string file)
        {
            m_pRelayServer = server;
            m_MessageFile  = file;

            m_pMessageStream = File.Open(m_MessageFile,FileMode.Open,FileAccess.Read,FileShare.Read);
            m_SessionID = Guid.NewGuid().ToString();
            m_SessionStartTime = DateTime.Now;
            m_pSmtpClient = new SmtpClientEx();
			m_pSmtpClient.DnsServers = new string[]{m_pRelayServer.Dns1,m_pRelayServer.Dns2};
			if(m_pRelayServer.LogCommands){
                m_pSmtpClient.SessionLog += new LogEventHandler(OnSMTP_LogPart);
			}
        }
        
        #region method Dispose

        /// <summary>
        /// Clean up any resources beeing used.
        /// </summary>
        public void Dispose()
        {               
            if(m_pMessageStream != null){
                try{
                    m_pMessageStream.Dispose();
                }
                catch{
                }
                m_pMessageStream = null;
            }
            if(m_pSmtpClient != null){
                try{
                    m_ReadedCount  = m_pSmtpClient.ReadedCount;
                    m_WrittenCount = m_pSmtpClient.WrittenCount;

                    m_pSmtpClient.Dispose();
                    m_pSmtpClient = null;
                }
                catch{
                }
            }
            m_pRemoteEndPoint = null;
        }

        #endregion


        #region method Start

        /// <summary>
        /// Starts relay session processing.
        /// </summary>
        public void Start()
        {
            try{				
				// Smart host enabled, use it
				if(m_pRelayServer.UseSmartHost){
					m_pSmtpClient.BeginConnect(new IPEndPoint(m_pRelayServer.SendingIP,0),m_pRelayServer.SmartHost,m_pRelayServer.SmartHostPort,m_pRelayServer.SmartHostUseSSL,new CommadCompleted(this.ConnectCompleted));
				}
				// Use direct delivery
				else{
					//m_pSmtpClient.BeginConnect(new IPEndPoint(m_pRelayServer.SendingIP,0),m_pRelayInfo.To,25,new CommadCompleted(this.ConnectCompleted));
				}
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
			
				End(false,x);
			}
        }

        #endregion

        #region method End

		/// <summary>
		/// Ends RelaySession, does clean up.
		/// </summary>
		/// <param name="sendOk">Specifies if message sent ok.</param>
		/// <param name="exception">If sendOk=false, then exception is filled with error info.</param>
		private void End(bool sendOk,Exception exception)
		{	
			// This method may be called multiple times, if session timed out.  Just block it.
			if(m_Ended){
				return;
			}
			m_Ended = true;

			try{                
                // If exception and logging enabled, log exception.
                if(m_pSmtpClient.SessionActiveLog != null && exception != null){
                    m_pSmtpClient.SessionActiveLog.AddTextEntry("Exception: " + exception.Message);                    
                }

				if(sendOk){
					Dispose();
				}
				else{
					Dispose();

                    Error.DumpError(exception);
				}
			}
			catch(Exception x){	
				Error.DumpError(x,new System.Diagnostics.StackTrace());
			}
			finally{
				m_pRelayServer.RemoveSession(this);                
                m_pRelayServer = null;
			}
		}

		#endregion

        #region method Kill

        /// <summary>
        /// Kills this session.
        /// </summary>
        /// <param name="text">Text to reply to connected server.</param>
        public void Kill(string text)
        {
            if(m_pSmtpClient != null && m_pSmtpClient.SessionActiveLog != null){
                m_pSmtpClient.SessionActiveLog.AddTextEntry(text);
            }

			End(false,new Exception(text));
        }

        #endregion


        #region method OnSMTP_LogPart

        private void OnSMTP_LogPart(object sender,Log_EventArgs e)
        {              
            //Logger.WriteLog(m_pRelayServer.LogsPath + "relay-" + DateTime.Today.ToString("yyyyMMdd") + ".log",e.Logger);
        }

        #endregion


        #region method ConnectCompleted

		/// <summary>
		/// Is called when Connect completed.
		/// </summary>
		/// <param name="result"></param>
		/// <param name="exception"></param>
		private void ConnectCompleted(LumiSoft.Net.SocketCallBackResult result,Exception exception)
		{
			try{
				if(LumiSoft.Net.SocketCallBackResult.Ok == result){
                    m_pRemoteEndPoint = (IPEndPoint)m_pSmtpClient.RemoteEndPoint;

					m_pSmtpClient.BeginEhlo(m_pRelayServer.HostName,new CommadCompleted(this.EhloCompleted));
				}
				else if(exception != null){
					End(false,exception);
				}
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
				
				End(false,x);
			}
		}

		#endregion

		#region method EhloCompleted

		/// <summary>
		/// Is called when EHLO is completed.
		/// </summary>
		/// <param name="result"></param>
		/// <param name="exception"></param>
		private void EhloCompleted(LumiSoft.Net.SocketCallBackResult result,Exception exception)
		{
			try{
				if(LumiSoft.Net.SocketCallBackResult.Ok == result){
					if(m_pRelayServer.UseSmartHost && m_pRelayServer.SmartHostUserName.Length > 0){
						m_pSmtpClient.BeginAuthenticate(m_pRelayServer.SmartHostUserName,m_pRelayServer.SmartHostPassword,new CommadCompleted(this.AuthenticationCompleted));
					}
					else{
						m_pSmtpClient.BeginSetSender(m_pRelayServer.From,m_pMessageStream.Length - m_pMessageStream.Position,new CommadCompleted(this.SetSenderCompleted));
					}
				}
				else if(exception != null){
					End(false,exception);
				}
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
				
				End(false,x);
			}
		}

		#endregion

		#region method AuthenticationCompleted

		/// <summary>
		/// Is called when authentication is completed.
		/// </summary>
		/// <param name="result"></param>
		/// <param name="exception"></param>
		private void AuthenticationCompleted(LumiSoft.Net.SocketCallBackResult result,Exception exception)
		{
			try{
				if(LumiSoft.Net.SocketCallBackResult.Ok == result){
					m_pSmtpClient.BeginSetSender(m_pRelayServer.From,-1,new CommadCompleted(this.SetSenderCompleted));
				}
				else if(exception != null){
					End(false,exception);
				}
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
				
				End(false,exception);
			}
		}

		#endregion

		#region method SetSenderCompleted

		/// <summary>
		/// Is called SetSender completed.
		/// </summary>
		/// <param name="result"></param>
		/// <param name="exception"></param>
		private void SetSenderCompleted(LumiSoft.Net.SocketCallBackResult result,Exception exception)
		{
			try{
				if(LumiSoft.Net.SocketCallBackResult.Ok == result){
					m_pSmtpClient.BeginAddRecipient(m_pRelayServer.To,new CommadCompleted(this.SetRecipientCompleted));
				}
				else if(exception != null){
					End(false,exception);
				}
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
				
				End(false,x);
			}
		}

		#endregion

		#region method SetRecipientCompleted

		/// <summary>
		/// Is called when SetRecipient completed.
		/// </summary>
		/// <param name="result"></param>
		/// <param name="exception"></param>
		private void SetRecipientCompleted(LumiSoft.Net.SocketCallBackResult result,Exception exception)
		{
			try{
				if(LumiSoft.Net.SocketCallBackResult.Ok == result){
					m_pSmtpClient.BeginSendMessage(m_pMessageStream,new CommadCompleted(this.MessageSendingCompleted));                                    
				}
				else if(exception != null){
					End(false,exception);
				}
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
				
				End(false,x);
			}
		}

		#endregion

		#region method MessageSendingCompleted

		/// <summary>
		/// Is called when MessageSending completed.
		/// </summary>
		/// <param name="result"></param>
		/// <param name="exception"></param>
		private void MessageSendingCompleted(LumiSoft.Net.SocketCallBackResult result,Exception exception)
		{
			try{
				if(LumiSoft.Net.SocketCallBackResult.Ok == result){
					End(true,null);
				}
				else if(exception != null){
					End(false,exception);
				}
			}
			catch(Exception x){				
				End(false,x);
			}
		}

		#endregion


        #region Properties Implementation
                
        /// <summary>
        /// Gets relay session ID.
        /// </summary>
        public string SessionID
        {
            get{ return m_SessionID; }
        }

        /// <summary>
        /// Gets session start time.
        /// </summary>
        public DateTime SessionStartTime
        {
            get{ return m_SessionStartTime; }
        }

        /// <summary>
		/// Gets session local endpoint.
		/// </summary>
		public EndPoint LocalEndPoint
		{
			get{ return m_pSmtpClient.LocalEndpoint; }
		}

		/// <summary>
		/// Gets session remote endpoint.
		/// </summary>
		public EndPoint RemoteEndPoint
		{
			get{ return m_pSmtpClient.RemoteEndPoint; }
		}

        /// <summary>
        /// Gets time when was session last activity.
        /// </summary>
        public DateTime LastActivity
        {
            get{ return m_pSmtpClient.LastDataTime; }
        }

        /// <summary>
        /// Gets how many seconds has left before timout is triggered.
        /// </summary>
        public int ExpectedTimeout
        {
            get{
                return (int)(m_pRelayServer.SessionIdleTimeout - ((DateTime.Now.Ticks - LastActivity.Ticks) / 10000));
            }
        }

        /// <summary>
        /// Gets log entries that are currently in log buffer.
        /// </summary>
        public SocketLogger SessionActiveLog
        {
            get{ return m_pSmtpClient.SessionActiveLog; }
        }

        /// <summary>
        /// Gets how many bytes are readed through this session.
        /// </summary>
        public long ReadedCount
        {
            get{ 
                if(m_pSmtpClient != null){
                    m_ReadedCount = m_pSmtpClient.ReadedCount;                    
                }

                return m_ReadedCount;
            }
        }
        
        /// <summary>
        /// Gets how many bytes are written through this session.
        /// </summary>
        public long WrittenCount
        {
            get{
                if(m_pSmtpClient != null){
                    m_WrittenCount = m_pSmtpClient.WrittenCount;                    
                }

                return m_WrittenCount;
            }
        }
        
        /// <summary>
        /// Gets if the connection is an SSL connection.
        /// </summary>
        public bool IsSecureConnection
        {
            get{ return m_pSmtpClient.IsSecureConnection; }
        }

        /// <summary>
        /// Gets file name which is relayed by this session.
        /// </summary>
        public string FileName
        {
            get{ return m_MessageFile; }
        }

        /// <summary>
        /// Gets connected host name. If no connected host or name getting failed, returns "".
        /// </summary>
        public string ConnectedHostName
        {
            get{
                if(m_pRemoteEndPoint != null){
                    try{
                        return Dns.GetHostEntry(((IPEndPoint)m_pSmtpClient.RemoteEndPoint).Address).HostName;
                    }
                    catch{
                        return m_pRemoteEndPoint.Address.ToString();
                    }
                }
                
                return ""; 
            }
        }

        /// <summary>
        /// Gets relay message ID.
        /// </summary>
        public string MessageID
        {
            get{ return Path.GetFileNameWithoutExtension(m_MessageFile); }
        }


        /// <summary>
        /// Gets relay session owner relay server.
        /// </summary>
        internal Relay_Server OwnerServer
        {
            get{ return m_pRelayServer; }
        }

        #endregion

    }
}
