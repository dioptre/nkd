using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using SmtpStress.Resources;

namespace SmtpStress
{
    /// <summary>
    /// Errors viewer window.
    /// </summary>
    public class wfrm_Errors : Form
    {
        private ListView m_pErrors = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Errors()
        {
            InitUI();

            LoadErrors();
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(500,300);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Error Viewer:";
            this.Icon = ResManager.GetIcon("error.ico");

            ImageList imglistErrors = new ImageList();
            imglistErrors.Images.Add(ResManager.GetIcon("error.ico"));

            m_pErrors = new ListView();
            m_pErrors.Dock = DockStyle.Fill;
            m_pErrors.View = View.Details;
            m_pErrors.HideSelection = false;
            m_pErrors.FullRowSelect = true;
            m_pErrors.SmallImageList = imglistErrors;
            m_pErrors.Columns.Add("Error Message",480);

            this.Controls.Add(m_pErrors);
        }

        #endregion


        #region method LoadErrors

        /// <summary>
        /// Loads errors to UI.
        /// </summary>
        private void LoadErrors()
        {
            foreach(Exception x in Error.Errors){
                ListViewItem it = new ListViewItem(x.Message);
                it.ImageIndex = 0;
                m_pErrors.Items.Add(it);
            }
        }

        #endregion
    }
}
