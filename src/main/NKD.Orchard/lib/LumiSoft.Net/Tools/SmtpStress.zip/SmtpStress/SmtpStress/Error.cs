using System;
using System.Diagnostics;
using System.Collections.Generic;

namespace SmtpStress
{
	/// <summary>
	/// Application error handler.
	/// </summary>
	public class Error
    {
        /// <summary>
        /// This event is raised when error happens.
        /// </summary>
        public static event EventHandler OnError = null;

        private static List<Exception> m_pErrors = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        static Error()
        {
            m_pErrors = new List<Exception>();
        }

        #region static method DumpError

        /// <summary>
        /// Dumps error.
        /// </summary>
        /// <param name="x"></param>
        public static void DumpError(Exception x)
		{
			DumpError(x,null);
		}

        /// <summary>
        /// Dumps error.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="s"></param>
		public static void DumpError(Exception x,StackTrace s)
		{
			m_pErrors.Add(x);

            if(OnError != null){
                OnError(null,new EventArgs());
            }
        }

        #endregion


        #region Properties Implementation

        /// <summary>
        /// Gets errors.
        /// </summary>
        public static Exception[] Errors
        {
            get{ return m_pErrors.ToArray(); }
        }

        #endregion
    }
}
