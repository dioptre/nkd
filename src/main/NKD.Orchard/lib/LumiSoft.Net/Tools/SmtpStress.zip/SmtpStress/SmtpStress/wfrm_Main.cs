using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Net;
using System.Threading;

using SmtpStress.Resources;
using LumiSoft.Net;
using LumiSoft.Net.SMTP.Server;
using LumiSoft.Net.Mime;

namespace SmtpStress
{
    /// <summary>
    /// Application main windows.
    /// </summary>
    public class wfrm_Main : Form
    {
        private TabControl m_pTab       = null;
        private LinkLabel  mt_Error     = null;
        private Button     m_pStartStop = null;
        private Button     m_Close      = null;
        private StatusBar  m_pStatusBar = null;
        //--- Stress tabpage
        private PictureBox    m_pIcon                         = null;
        private Label         m_pLabel                        = null;
        private GroupBox      m_pSeparator1                   = null;
        private Label         mt_Host                         = null;
        private TextBox       m_pHost                         = null;
        private NumericUpDown m_pPort                         = null;
        private CheckBox      m_pSsl                          = null;
        private Label         mt_User                         = null;
        private TextBox       m_pUser                         = null;
        private Label         mt_Password                     = null;
        private TextBox       m_pPassword                     = null;
        private Label         mt_From                         = null;
        private TextBox       m_pFrom                         = null;
        private Label         mt_To                           = null;
        private TextBox       m_pTo                           = null;
        private Label         mt_Connections                  = null;
        private NumericUpDown m_pConnections                  = null;
        private Label         mt_Count                        = null;
        private NumericUpDown m_pCount                        = null;
        private Label         mt_Type                         = null;
        private ComboBox      m_pType                         = null;
        private Label         mt_TypeGenMsg_Size              = null;
        private NumericUpDown m_pTypeGenMsg_Size              = null;
        private Label         mt_TypeWorkloadFolder_Folder    = null;
        private TextBox       m_pTypeWorkloadFolder_Folder    = null;
        private Button        m_pTypeWorkloadFolder_GetFolder = null;
        //--- Performance tabpage
        private Label      mt_MessgesInSecond      = null;
        private WLineGraph m_pMessgesInSecond      = null;
        private WLineGraph m_pBandwidth            = null;
        private Panel      m_pBandwidth_ReadColor  = null;
        private Label      mt_Bandwidth_Read       = null;
        private Panel      m_pBandwidth_WriteColor = null;
        private Label      mt_Bandwidth_Write      = null;
        //--- Embbed SMTP tabpage
        private Label         mt_SmtpServerIP         = null;
        private TextBox       m_pSmtpServerIP         = null;
        private NumericUpDown m_pSmtpServerPort       = null;
        private PictureBox    m_pSmtpServer_Icon      = null;
        private Button        m_pSmtpServer_StartStop = null;

        private int                        m_LoopCount         = 1;
        private int                        m_Type              = 0;
        private Relay_Server               m_pRelay            = null;
        private SMTP_Server                m_pSmtpServer       = null;
        private DateTime                   m_StartTime;
        private int                        m_LastSentCount     = 0;
        private System.Windows.Forms.Timer m_pPerformanceTimer = null;
                
        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Main()
        {
            InitUI();

            Error.OnError += new EventHandler(Error_OnError);

            m_pPerformanceTimer = new System.Windows.Forms.Timer();
            m_pPerformanceTimer.Enabled = false;
            m_pPerformanceTimer.Interval = 1000;
            m_pPerformanceTimer.Tick += new EventHandler(m_pPerformanceTimer_Tick);

            m_pType.SelectedIndex = 0;
        }
                                
        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(500,420);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "LumiSoft SMTP stress 1.0";
            this.Icon = ResManager.GetIcon("app.ico");
            this.FormClosed += new FormClosedEventHandler(wfrm_Main_FormClosed);

            #region Common UI

            m_pTab = new TabControl();
            m_pTab.Size = new Size(490,350);
            m_pTab.Location = new Point(5,5);
            m_pTab.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            m_pTab.TabPages.Add("Stress");
            m_pTab.TabPages.Add("Performance");
            m_pTab.TabPages.Add("Embbed SMTP server");
            m_pTab.TabPages[1].Size = new Size(482,324);

            mt_Error = new LinkLabel();
            mt_Error.Size = new Size(190,30);
            mt_Error.Location = new Point(10,365);
            mt_Error.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            mt_Error.Image = ResManager.GetIcon("error.ico").ToBitmap();
            mt_Error.ImageAlign = ContentAlignment.MiddleLeft;
            mt_Error.TextAlign = ContentAlignment.MiddleRight;
            mt_Error.Visible = false;
            mt_Error.LinkClicked += new LinkLabelLinkClickedEventHandler(mt_Error_LinkClicked);

            m_pStartStop = new Button();
            m_pStartStop.Size = new Size(70,20);
            m_pStartStop.Location = new Point(340,370);
            m_pStartStop.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            m_pStartStop.Text = "Start";
            m_pStartStop.Click += new EventHandler(m_pStartStop_Click);

            m_Close = new Button();
            m_Close.Size = new Size(70,20);
            m_Close.Location = new Point(425,370);
            m_Close.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            m_Close.Text = "Close";
            m_Close.Click += new EventHandler(m_Close_Click);

            m_pStatusBar = new StatusBar();
            m_pStatusBar.ShowPanels = true;
            StatusBarPanel panel = new StatusBarPanel();
            panel.AutoSize = StatusBarPanelAutoSize.Spring;
            m_pStatusBar.Panels.Add(panel);
            panel = new StatusBarPanel();
            panel.Width = 80;
            m_pStatusBar.Panels.Add(panel);
            panel = new StatusBarPanel();
            panel.Width = 100;
            m_pStatusBar.Panels.Add(panel);
            panel = new StatusBarPanel();
            panel.Width = 100;
            m_pStatusBar.Panels.Add(panel);

            this.Controls.Add(m_pTab);
            this.Controls.Add(mt_Error);
            this.Controls.Add(m_pStartStop);
            this.Controls.Add(m_Close);
            this.Controls.Add(m_pStatusBar);

            #endregion

            #region Stress tabpage

            m_pIcon = new PictureBox();
            m_pIcon.Size = new Size(36,36);
            m_pIcon.Location = new Point(10,10);
            m_pIcon.Image = ResManager.GetIcon("stress.ico").ToBitmap();

            m_pLabel = new Label();
            m_pLabel.Size = new Size(200,20);
            m_pLabel.Location = new Point(70,20);
            m_pLabel.Text = "SMTP stress tool";

            m_pSeparator1 = new GroupBox();
            m_pSeparator1.Size = new Size(490,3);
            m_pSeparator1.Location = new Point(5,50);

            mt_Host = new Label();
            mt_Host.Size = new Size(100,20);
            mt_Host.Location = new Point(0,75);
            mt_Host.TextAlign = ContentAlignment.MiddleRight;
            mt_Host.Text = "SMTP Host:";

            m_pHost = new TextBox();
            m_pHost.Size = new Size(200,20);
            m_pHost.Location = new Point(105,75);
            m_pHost.Text = "localhost";

            m_pPort = new NumericUpDown();
            m_pPort.Size = new Size(60,20);
            m_pPort.Location = new Point(310,75);
            m_pPort.Minimum = 1;
            m_pPort.Maximum = 99999;
            m_pPort.Value = 25;

            m_pSsl = new CheckBox();
            m_pSsl.Size = new Size(100,20);
            m_pSsl.Location = new Point(375,75);
            m_pSsl.Text = "Use SSL";

            mt_User = new Label();
            mt_User.Size = new Size(100,20);
            mt_User.Location = new Point(0,100);
            mt_User.TextAlign = ContentAlignment.MiddleRight;
            mt_User.Text = "User:";

            m_pUser = new TextBox();
            m_pUser.Size = new Size(150,20);
            m_pUser.Location = new Point(105,100);

            mt_Password = new Label();
            mt_Password.Size = new Size(100,20);
            mt_Password.Location = new Point(0,125);
            mt_Password.TextAlign = ContentAlignment.MiddleRight;
            mt_Password.Text = "Password:";

            m_pPassword = new TextBox();
            m_pPassword.Size = new Size(150,20);
            m_pPassword.Location = new Point(105,125);
            m_pPassword.PasswordChar = '*';

            mt_From = new Label();
            mt_From.Size = new Size(100,20);
            mt_From.Location = new Point(0,160);
            mt_From.TextAlign = ContentAlignment.MiddleRight;
            mt_From.Text = "From:";

            m_pFrom = new TextBox();
            m_pFrom.Size = new Size(150,20);
            m_pFrom.Location = new Point(105,160);

            mt_To = new Label();
            mt_To.Size = new Size(100,20);
            mt_To.Location = new Point(0,185);
            mt_To.TextAlign = ContentAlignment.MiddleRight;
            mt_To.Text = "To:";
                        
            m_pTo = new TextBox();
            m_pTo.Size = new Size(150,20);
            m_pTo.Location = new Point(105,185);

            mt_Connections = new Label();
            mt_Connections.Size = new Size(100,20);
            mt_Connections.Location = new Point(0,215);
            mt_Connections.TextAlign = ContentAlignment.MiddleRight;
            mt_Connections.Text = "Connections:";

            m_pConnections = new NumericUpDown();
            m_pConnections.Size = new Size(70,20);
            m_pConnections.Location = new Point(105,215);
            m_pConnections.Minimum = 1;
            m_pConnections.Maximum = 99999;
            m_pConnections.Value = 30;

            mt_Count = new Label();
            mt_Count.Size = new Size(100,20);
            mt_Count.Location = new Point(0,240);
            mt_Count.TextAlign = ContentAlignment.MiddleRight;
            mt_Count.Text = "Loop Count:";

            m_pCount = new NumericUpDown();
            m_pCount.Size = new Size(70,20);
            m_pCount.Location = new Point(105,240);
            m_pCount.Minimum = 1;
            m_pCount.Maximum = 99999;
            m_pCount.Value = 1;

            mt_Type = new Label();
            mt_Type.Size = new Size(100,20);
            mt_Type.Location = new Point(0,265);
            mt_Type.TextAlign = ContentAlignment.MiddleRight;
            mt_Type.Text = "Messages Source:";

            m_pType = new ComboBox();
            m_pType.Size = new Size(150,20);
            m_pType.Location = new Point(105,265);
            m_pType.DropDownStyle = ComboBoxStyle.DropDownList;
            m_pType.Items.Add("Generated Message");
            m_pType.Items.Add("Workload Folder");
            m_pType.SelectedIndexChanged += new EventHandler(m_pType_SelectedIndexChanged);

            //--- Type: Genrated Message
            mt_TypeGenMsg_Size = new Label();
            mt_TypeGenMsg_Size.Size = new Size(100,20);
            mt_TypeGenMsg_Size.Location = new Point(0,290);
            mt_TypeGenMsg_Size.TextAlign = ContentAlignment.MiddleRight;
            mt_TypeGenMsg_Size.Text = "Message Size(kb):";
            mt_TypeGenMsg_Size.Visible = false;

            m_pTypeGenMsg_Size = new NumericUpDown();
            m_pTypeGenMsg_Size.Size = new Size(70,20);
            m_pTypeGenMsg_Size.Location = new Point(105,290);
            m_pTypeGenMsg_Size.Minimum = 1;
            m_pTypeGenMsg_Size.Value = 1;
            m_pTypeGenMsg_Size.Visible = false;

            //--- Type: Workload Folder
            mt_TypeWorkloadFolder_Folder = new Label();
            mt_TypeWorkloadFolder_Folder.Size = new Size(100,20);
            mt_TypeWorkloadFolder_Folder.Location = new Point(0,290);
            mt_TypeWorkloadFolder_Folder.TextAlign = ContentAlignment.MiddleRight;
            mt_TypeWorkloadFolder_Folder.Text = "Folder:";
            mt_TypeWorkloadFolder_Folder.Visible = false;

            m_pTypeWorkloadFolder_Folder = new TextBox();
            m_pTypeWorkloadFolder_Folder.Size = new Size(270,20);
            m_pTypeWorkloadFolder_Folder.Location = new Point(105,290);
            m_pTypeWorkloadFolder_Folder.Visible = false;

            m_pTypeWorkloadFolder_GetFolder = new Button();
            m_pTypeWorkloadFolder_GetFolder.Size = new Size(24,20);
            m_pTypeWorkloadFolder_GetFolder.Location = new Point(380,290);
            m_pTypeWorkloadFolder_GetFolder.Text = "...";
            m_pTypeWorkloadFolder_GetFolder.Visible = false;
            m_pTypeWorkloadFolder_GetFolder.Click += new EventHandler(m_pTypeWorkloadFolder_GetFolder_Click);


            m_pTab.TabPages[0].Controls.Add(m_pIcon);
            m_pTab.TabPages[0].Controls.Add(m_pLabel);
            m_pTab.TabPages[0].Controls.Add(m_pSeparator1);
            m_pTab.TabPages[0].Controls.Add(mt_Host);
            m_pTab.TabPages[0].Controls.Add(m_pHost);
            m_pTab.TabPages[0].Controls.Add(m_pPort);
            m_pTab.TabPages[0].Controls.Add(m_pSsl);
            m_pTab.TabPages[0].Controls.Add(mt_User);
            m_pTab.TabPages[0].Controls.Add(m_pUser);
            m_pTab.TabPages[0].Controls.Add(mt_Password);
            m_pTab.TabPages[0].Controls.Add(m_pPassword);
            m_pTab.TabPages[0].Controls.Add(mt_From);
            m_pTab.TabPages[0].Controls.Add(m_pFrom);
            m_pTab.TabPages[0].Controls.Add(mt_To);
            m_pTab.TabPages[0].Controls.Add(m_pTo);
            m_pTab.TabPages[0].Controls.Add(mt_Connections);
            m_pTab.TabPages[0].Controls.Add(m_pConnections);
            m_pTab.TabPages[0].Controls.Add(mt_Count);
            m_pTab.TabPages[0].Controls.Add(m_pCount);
            m_pTab.TabPages[0].Controls.Add(mt_Type);
            m_pTab.TabPages[0].Controls.Add(m_pType);
            m_pTab.TabPages[0].Controls.Add(mt_TypeGenMsg_Size);
            m_pTab.TabPages[0].Controls.Add(m_pTypeGenMsg_Size);
            m_pTab.TabPages[0].Controls.Add(mt_TypeWorkloadFolder_Folder);
            m_pTab.TabPages[0].Controls.Add(m_pTypeWorkloadFolder_Folder);
            m_pTab.TabPages[0].Controls.Add(m_pTypeWorkloadFolder_GetFolder);

            #endregion

            #region Performance tabpage

            mt_MessgesInSecond = new Label();
            mt_MessgesInSecond.Size = new Size(200,20);
            mt_MessgesInSecond.Location = new Point(10,10);
            mt_MessgesInSecond.TextAlign = ContentAlignment.MiddleLeft;
            mt_MessgesInSecond.Text = "0 msgs/sec";
            
            m_pMessgesInSecond = new WLineGraph();
            m_pMessgesInSecond.Size = new Size(460,130);
            m_pMessgesInSecond.Location = new Point(10,30);
            m_pMessgesInSecond.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            m_pMessgesInSecond.AutoMaxValue = true;
            m_pMessgesInSecond.AddLine(Color.LightGreen);

            m_pBandwidth = new WLineGraph();
            m_pBandwidth.Size = new Size(460,110);
            m_pBandwidth.Location = new Point(10,180);
            m_pBandwidth.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            m_pBandwidth.AutoMaxValue = true;
            m_pBandwidth.AddLine(Color.LightGreen);
            m_pBandwidth.AddLine(Color.Red);

            m_pBandwidth_ReadColor = new Panel();
            m_pBandwidth_ReadColor.Size = new Size(16,16);
            m_pBandwidth_ReadColor.Location = new Point(10,300);
            m_pBandwidth_ReadColor.BorderStyle = BorderStyle.FixedSingle;
            m_pBandwidth_ReadColor.BackColor = Color.LightGreen;

            mt_Bandwidth_Read = new Label();
            mt_Bandwidth_Read.Size = new Size(130,20);
            mt_Bandwidth_Read.Location = new Point(30,300);
            mt_Bandwidth_Read.TextAlign = ContentAlignment.MiddleLeft;
            mt_Bandwidth_Read.Text = "Read 0 (kb/sec)";

            m_pBandwidth_WriteColor = new Panel();
            m_pBandwidth_WriteColor.Size = new Size(16,16);
            m_pBandwidth_WriteColor.Location = new Point(170,300);
            m_pBandwidth_WriteColor.BorderStyle = BorderStyle.FixedSingle;
            m_pBandwidth_WriteColor.BackColor = Color.Red;

            mt_Bandwidth_Write = new Label();
            mt_Bandwidth_Write.Size = new Size(130,20);
            mt_Bandwidth_Write.Location = new Point(190,300);
            mt_Bandwidth_Write.TextAlign = ContentAlignment.MiddleLeft;
            mt_Bandwidth_Write.Text = "Write 0 (kb/sec)";

            m_pTab.TabPages[1].Controls.Add(mt_MessgesInSecond);
            m_pTab.TabPages[1].Controls.Add(m_pMessgesInSecond);
            m_pTab.TabPages[1].Controls.Add(m_pBandwidth);
            m_pTab.TabPages[1].Controls.Add(m_pBandwidth_ReadColor);
            m_pTab.TabPages[1].Controls.Add(mt_Bandwidth_Read);
            m_pTab.TabPages[1].Controls.Add(m_pBandwidth_WriteColor);
            m_pTab.TabPages[1].Controls.Add(mt_Bandwidth_Write);

            #endregion

            #region Embbed SMTP tabpage

            mt_SmtpServerIP = new Label();
            mt_SmtpServerIP.Size = new Size(100,20);
            mt_SmtpServerIP.Location = new Point(0,75);
            mt_SmtpServerIP.TextAlign = ContentAlignment.MiddleRight;
            mt_SmtpServerIP.Text = "Listen:";

            m_pSmtpServerIP = new TextBox();
            m_pSmtpServerIP.Size = new Size(200,20);
            m_pSmtpServerIP.Location = new Point(105,75);
            m_pSmtpServerIP.Text = "127.0.0.1";

            m_pSmtpServerPort = new NumericUpDown();
            m_pSmtpServerPort.Size = new Size(60,20);
            m_pSmtpServerPort.Location = new Point(310,75);
            m_pSmtpServerPort.Minimum = 1;
            m_pSmtpServerPort.Value = 25;

            m_pSmtpServer_Icon = new PictureBox();
            m_pSmtpServer_Icon.Size = new Size(36,36);
            m_pSmtpServer_Icon.Location = new Point(100,110);
            m_pSmtpServer_Icon.Image = ResManager.GetIcon("stopped.ico").ToBitmap();

            m_pSmtpServer_StartStop = new Button();
            m_pSmtpServer_StartStop.Size = new Size(70,20);
            m_pSmtpServer_StartStop.Location = new Point(160,110);
            m_pSmtpServer_StartStop.Text = "Start";
            m_pSmtpServer_StartStop.Click += new EventHandler(m_pSmtpServer_StartStop_Click);

            m_pTab.TabPages[2].Controls.Add(mt_SmtpServerIP);
            m_pTab.TabPages[2].Controls.Add(m_pSmtpServerIP);
            m_pTab.TabPages[2].Controls.Add(m_pSmtpServerPort);
            m_pTab.TabPages[2].Controls.Add(m_pSmtpServer_Icon);
            m_pTab.TabPages[2].Controls.Add(m_pSmtpServer_StartStop);

            #endregion

        }
                                                                                                                
        #endregion


        #region Events Handling

        #region method Error_OnError

        /// <summary>
        /// This event is called when error happens. NOTE: this isn't called on UI thread !
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Error_OnError(object sender,EventArgs e)
        {
            this.Invoke(new MethodInvoker(this.Error_OnError));
        }

        /// <summary>
        /// This methd is called when error happens, this method is called from UI thread.
        /// </summary>
        private void Error_OnError()
        {
            mt_Error.Visible = true;
            mt_Error.Text = Error.Errors.Length.ToString() + " errors, click here to see details.";
        }

        #endregion


        #region method m_pPerformanceTimer_Tick
                
        private void m_pPerformanceTimer_Tick(object sender,EventArgs e)
        {       
            try{   
                Relay_Session[] sessions = m_pRelay.Sessions;
                
                long readedCountStart  = 0;
                long writtenCountStart = 0;
                foreach(Relay_Session session in sessions){
                    try{
                        readedCountStart  += session.ReadedCount;
                        writtenCountStart += session.WrittenCount;
                    }
                    catch{
                    }
                }

                Thread.Sleep(100);

                long readedCountEnd  = 0;
                long writtenCountEnd = 0;
                foreach(Relay_Session session in sessions){
                    try{
                        readedCountEnd  += session.ReadedCount;
                        writtenCountEnd += session.WrittenCount;
                    }
                    catch{
                    }
                }
                                
                decimal readKbSec  = (readedCountEnd - readedCountStart) / (decimal)100;
                decimal writeKbSec = (writtenCountEnd - writtenCountStart) / (decimal)100;
                                 
                m_pBandwidth.AddValue(new int[]{Math.Max(1,(int)readKbSec),Math.Max(1,(int)writeKbSec)});

                mt_Bandwidth_Read.Text = "Read " + readKbSec.ToString("f2") + " (kb/sec)";
                mt_Bandwidth_Write.Text = "Write " + writeKbSec.ToString("f2") + " (kb/sec)";

                m_pStatusBar.Panels[2].Text = "R kb/sec: " + readKbSec.ToString();
                m_pStatusBar.Panels[3].Text = "W kb/sec: " + writeKbSec.ToString();


                //--- Messages / sec -------------------------------------------------
                int sent = (int)m_pRelay.Sent;
                decimal messagesSec =sent - m_LastSentCount;
                m_LastSentCount = sent;

                mt_MessgesInSecond.Text = messagesSec.ToString("f2") + " msgs/sec";
                m_pMessgesInSecond.AddValue(new int[]{(int)messagesSec});

                m_pStatusBar.Panels[1].Text = "Msgs/sec: " + messagesSec.ToString();
            }
            catch{
            }
        }

        #endregion

        #region method wfrm_Main_FormClosed

        private void wfrm_Main_FormClosed(object sender,FormClosedEventArgs e)
        {
            if(m_pRelay != null){
                m_pRelay.Dispose();
                m_pRelay = null;
            }

            if(m_pSmtpServer != null){
                m_pSmtpServer.Dispose();
                m_pSmtpServer = null;
            }
        }

        #endregion

        #region method mt_Error_LinkClicked

        private void mt_Error_LinkClicked(object sender,LinkLabelLinkClickedEventArgs e)
        {
            wfrm_Errors frm = new wfrm_Errors();
            frm.ShowDialog(this);
        }

        #endregion

        #region method m_pStartStop_Click

        private void m_pStartStop_Click(object sender,EventArgs e)
        {
            if(m_pStartStop.Text == "Start"){
                if(m_pHost.Text == ""){
                    MessageBox.Show(this,"Please fill Host !","Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                if(m_pTo.Text == ""){
                    MessageBox.Show(this,"Please fill To !","Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }

                mt_Error.Visible = false;

                m_LoopCount = (int)m_pCount.Value;
                m_Type = m_pType.SelectedIndex;
                m_LastSentCount = 0;

                // Generate message
                if(m_Type == 0){
                    Mime m = new Mime();
                    AddressList from = new AddressList();
                    from.Parse(m_pFrom.Text);
                    m.MainEntity.From = from;
                    AddressList to = new AddressList();
                    to.Parse(m_pTo.Text);
                    m.MainEntity.To = to;
                    m.MainEntity.ContentType = MediaType_enum.Text_plain;            
                    m.MainEntity.ContentTransferEncoding = ContentTransferEncoding_enum._7bit;
                    m.MainEntity.ContentType_CharSet = "utf-8";
                    m.MainEntity.Subject = "test";

                    int size = m.ToByteData().Length;
                    // Fill text 
                    string text = "This is test !\r\n";
                    while(((int)m_pTypeGenMsg_Size.Value * 1000) > size){
                        text += "This is test !\r\n";
                        size += "This is test !\r\n".Length;
                    }
                    m.MainEntity.DataText = text;
                    
                    File.WriteAllBytes(Application.StartupPath + "/test.eml",m.ToByteData());
                }

                m_StartTime = DateTime.Now;
                                
                m_pPerformanceTimer.Enabled = true;

                m_pRelay = new Relay_Server();
                m_pRelay.MaximumConnections = (int)m_pConnections.Value;
                m_pRelay.RelayInterval = 0;
                m_pRelay.UseSmartHost = true;
                m_pRelay.SmartHost = m_pHost.Text;
                m_pRelay.SmartHostPort = (int)m_pPort.Value;
                m_pRelay.SmartHostUserName = m_pUser.Text;
                m_pRelay.SmartHostPassword = m_pPassword.Text;
                m_pRelay.SmartHostUseSSL = m_pSsl.Checked;
                m_pRelay.From = m_pFrom.Text;
                m_pRelay.To = m_pTo.Text;
                m_pRelay.Start();

                Thread tr = new Thread(this.Start);
                tr.Start();

                m_pStartStop.Text = "Stop";
                m_pStatusBar.Panels[0].Text = "Sending";
            }
            else{
                if(m_pRelay != null){
                    m_pRelay.Dispose();
                    m_pRelay = null;
                }

                m_pStartStop.Text = "Start";
            }
        }

        #endregion

        #region method m_Close_Click

        private void m_Close_Click(object sender,EventArgs e)
        {
            this.Close();
        }

        #endregion


        #region Stress

        #region method m_pType_SelectedIndexChanged

        private void m_pType_SelectedIndexChanged(object sender,EventArgs e)
        {
            if(m_pType.SelectedIndex == 0){
                mt_TypeGenMsg_Size.Visible = true;
                m_pTypeGenMsg_Size.Visible = true;
                mt_TypeWorkloadFolder_Folder.Visible = false;
                m_pTypeWorkloadFolder_Folder.Visible = false;
                m_pTypeWorkloadFolder_GetFolder.Visible = false;
            }
            else if(m_pType.SelectedIndex == 1){
                mt_TypeGenMsg_Size.Visible = false;
                m_pTypeGenMsg_Size.Visible = false;
                mt_TypeWorkloadFolder_Folder.Visible = true;
                m_pTypeWorkloadFolder_Folder.Visible = true;
                m_pTypeWorkloadFolder_GetFolder.Visible = true;
            }
        }

        #endregion

        #region method m_pTypeWorkloadFolder_GetFolder_Click

        private void m_pTypeWorkloadFolder_GetFolder_Click(object sender,EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            if(dlg.ShowDialog(this) == DialogResult.OK){
                m_pTypeWorkloadFolder_Folder.Text = dlg.SelectedPath;
            }
        }

        #endregion

        #endregion

        #region Embbed SMTP server

        #region method m_pSmtpServer_StartStop_Click

        private void m_pSmtpServer_StartStop_Click(object sender,EventArgs e)
        {
            if(m_pSmtpServer_StartStop.Text == "Start"){
                IPAddress ip = null;
                try{
                    ip = IPAddress.Parse(m_pSmtpServerIP.Text);
                }
                catch{
                    MessageBox.Show(this,"Invalid IP address !","Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                                
                m_pSmtpServer = new SMTP_Server();
                m_pSmtpServer.MaxConnectionsPerIP = 0;
                m_pSmtpServer.MaxConnections = 10000;
                m_pSmtpServer.BindInfo = new BindInfo[]{new BindInfo(ip,(int)m_pSmtpServerPort.Value,false,null)};
                m_pSmtpServer.SysError += new LumiSoft.Net.ErrorEventHandler(m_pSmtpServer_SysError);
                m_pSmtpServer.StartServer();
                                
                m_pSmtpServerIP.Enabled = false;
                m_pSmtpServerPort.Enabled = false;
                m_pSmtpServer_Icon.Image = ResManager.GetIcon("running.ico").ToBitmap();
                
                m_pSmtpServer_StartStop.Text = "Stop";
            }
            else{
                m_pSmtpServer.Dispose();
                m_pSmtpServer = null;

                m_pSmtpServerIP.Enabled = true;
                m_pSmtpServerPort.Enabled = true;
                m_pSmtpServer_Icon.Image = ResManager.GetIcon("stopped.ico").ToBitmap();

                m_pSmtpServer_StartStop.Text = "Start";
            }
        }
                
        #endregion

        #region method m_pSmtpServer_SysError

        private void m_pSmtpServer_SysError(object sender,Error_EventArgs e)
        {
            Error.DumpError(e.Exception);
            this.Invoke(new MethodInvoker(this.Error_OnError));
        }

        #endregion

        #endregion

        #endregion


        #region method Start

        /// <summary>
        /// Starts sending.
        /// </summary>
        private void Start()
        {        
            try{
                for(int i=0;i<m_LoopCount;i++){
                    // Generate message
                    if(m_Type == 0){
                        m_pRelay.QueueRelayJob(Application.StartupPath + "/test.eml");
                    }
                    // Workload folder
                    else{
                        if(Directory.Exists(m_pTypeWorkloadFolder_Folder.Text)){
                            foreach(string messageFile in Directory.GetFiles(m_pTypeWorkloadFolder_Folder.Text,"*.eml")){                    
                                m_pRelay.QueueRelayJob(messageFile);
                            }
                        }
                    }
                }

                m_pRelay.WaitToComplete();

                // Call completed in UI thread.
                this.Invoke(new ThreadStart(this.Completed));
            }
            catch{
                // Skip disposing/closing errors
            }
        }

        #endregion

        #region method Completed

        /// <summary>
        /// Is called when sending has completed.
        /// </summary>
        private void Completed()
        {
            m_pPerformanceTimer.Enabled = false;

            if(m_pRelay != null){
                m_pRelay.Dispose();
                m_pRelay = null;
            }

            m_pStartStop.Text = "Start";

            m_pStatusBar.Panels[0].Text = "Completed !";
        }

        #endregion

    }
}
