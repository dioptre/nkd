﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

using LumiSoft.Net;
using LumiSoft.Net.WebDav;
using LumiSoft.Net.WebDav.Client;
using WebDavClient.Resources;

namespace WebDavClient
{
    /// <summary>
    /// Application main UI.
    /// </summary>
    public class wfrm_Main : Form
    {
        #region class FileSystemItemInfo

        /// <summary>
        /// This class holds list view item file system item info.
        /// </summary>
        private class FileSystemItemInfo
        {
            private bool   m_IsDirectory = false;
            private string m_Name        = null;
            private string m_HRef        = null;

            /// <summary>
            /// Default constructor.
            /// </summary>
            /// <param name="isDirectory">Specifies if this item is directory or file.</param>
            /// <param name="name">Item name.</param>
            /// <param name="href">Item href.</param>
            public FileSystemItemInfo(bool isDirectory,string name,string href)
            {
                m_IsDirectory = isDirectory;
                m_Name        = name;
                m_HRef        = href;
            }


            #region Properties implementation

            /// <summary>
            /// Gets if this file system item is directory.
            /// </summary>
            public bool IsDirectory
            {
                get{ return m_IsDirectory; }
            }

            /// <summary>
            /// Gets item name.
            /// </summary>
            public string Name
            {
                get{ return m_Name; }
            }

            /// <summary>
            /// Gets 
            /// </summary>
            public string HRef
            {
                get{ return m_HRef; }
            }

            #endregion
        }

        #endregion

        #region class FileUploader

        /// <summary>
        /// This class implements asynchronous file uploader.
        /// </summary>
        private class FileUploader
        {
            private ListView                   m_pListView = null;
            private ListViewItem               m_pItem     = null;
            private WebDav_Client              m_pDav      = null;
            private string                     m_TargetUri = null;
            private Stream                     m_pStream   = null;
            private System.Windows.Forms.Timer m_pTimer    = null;
            private DateTime                   m_StartTime;
            private long                       m_SentCount = 0;

            /// <summary>
            /// Default constructor.
            /// </summary>
            /// <param name="listView">Owner list view.</param>
            /// <param name="item">ListView item.</param>
            /// <param name="dav">WebDav client.</param>
            /// <param name="targetUri">Target URI.</param>
            /// <param name="stream">Stream what is uploaded.</param>
            /// <exception cref="ArgumentNullException">Is raised when <b>listView</b>, <b>item</b>, <b>dav</b>, <b>targetUri</b> or <b>stream</b> is null reference.</exception>
            public FileUploader(ListView listView,ListViewItem item,WebDav_Client dav,string targetUri,Stream stream)
            {
                if(listView == null){
                    throw new ArgumentNullException("listView");
                }
                if(item == null){
                    throw new ArgumentNullException("item");
                }
                if(dav == null){
                    throw new ArgumentNullException("dav");
                }
                if(targetUri == null){
                    throw new ArgumentNullException("targetUri");
                }
                if(stream == null){
                    throw new ArgumentNullException("stream");
                }

                m_pListView = listView;
                m_pItem     = item;
                m_pDav      = dav;
                m_TargetUri = targetUri;
                m_pStream   = stream;
                m_StartTime = DateTime.Now;

                m_pTimer = new System.Windows.Forms.Timer();
                m_pTimer.Interval = 1000;
                m_pTimer.Tick += new EventHandler(delegate(object s,EventArgs e){
                    m_pListView.Invoke(new MethodInvoker(delegate(){
                        if(m_pStream.Length > 0){
                            m_pItem.SubItems["%"].Text = Convert.ToInt32((m_pStream.Position * 100) / m_pStream.Length).ToString();
                        }
                        m_pItem.SubItems["mbsec"].Text   = ((m_pStream.Position - m_SentCount) / (decimal)1000000).ToString("f2");
                        m_pItem.SubItems["elapsed"].Text = ((TimeSpan)(DateTime.Now - m_StartTime)).ToString().Split('.')[0];
                    }));

                    m_SentCount = m_pStream.Position;
                });
                m_pTimer.Start();

                ThreadPool.QueueUserWorkItem(new WaitCallback(delegate(object state){
                    Run();
                }));
            }

            #region method Dispose

            /// <summary>
            /// Cleans up any resources being used.
            /// </summary>
            private void Dispose()
            {
                m_pTimer.Dispose();
                m_pStream.Dispose();

                m_pItem   = null;
                m_pDav    = null;
                m_pStream = null;
            }

            #endregion


            #region method Run

            private void Run()
            {
                try{
                    m_pDav.Put(m_TargetUri,m_pStream);

                    m_pListView.Invoke(new MethodInvoker(delegate(){
                        m_pItem.SubItems["%"].Text      = "100";
                        m_pItem.SubItems["mbsec"].Text  = "0";
                        m_pItem.SubItems["status"].Text = "Done";
                    }));
                }
                catch(Exception x){
                    m_pListView.Invoke(new MethodInvoker(delegate(){
                        m_pItem.SubItems["status"].Text = "Error";
                        m_pItem.SubItems["status"].Font = new Font(m_pItem.SubItems[4].Font,FontStyle.Underline);
                        m_pItem.SubItems["status"].ForeColor = Color.Red;
                        m_pItem.SubItems["status"].Tag = x;
                    }));
                }

                // We are done, cleanup.
                Dispose();
            }

            #endregion
        }

        #endregion

        #region method FileDownloader

        /// <summary>
        /// This class implements asynchronous file downloader.
        /// </summary>
        private class FileDownloader
        {
            private ListView                   m_pListView   = null;
            private ListViewItem               m_pItem       = null;
            private WebDav_Client              m_pDav        = null;
            private string                     m_TargetUri   = null;
            private Stream                     m_pStream     = null;
            private System.Windows.Forms.Timer m_pTimer      = null;
            private DateTime                   m_StartTime;
            private long                       m_ContentSize = 0;
            private long                       m_Received    = 0;

            /// <summary>
            /// Default constructor.
            /// </summary>
            /// <param name="listView">Owner list view.</param>
            /// <param name="item">ListView item.</param>
            /// <param name="dav">WebDav client.</param>
            /// <param name="targetUri">Target URI.</param>
            /// <param name="stream">Stream where to download file.</param>
            /// <exception cref="ArgumentNullException">Is raised when <b>listView</b>, <b>item</b>, <b>dav</b>, <b>targetUri</b> or <b>stream</b> is null reference.</exception>
            public FileDownloader(ListView listView,ListViewItem item,WebDav_Client dav,string targetUri,Stream stream)
            {
                if(listView == null){
                    throw new ArgumentNullException("listView");
                }
                if(item == null){
                    throw new ArgumentNullException("item");
                }
                if(dav == null){
                    throw new ArgumentNullException("dav");
                }
                if(targetUri == null){
                    throw new ArgumentNullException("targetUri");
                }
                if(stream == null){
                    throw new ArgumentNullException("stream");
                }

                m_pListView = listView;
                m_pItem     = item;
                m_pDav      = dav;
                m_TargetUri = targetUri;
                m_pStream   = stream;
                m_StartTime = DateTime.Now;

                m_pTimer = new System.Windows.Forms.Timer();
                m_pTimer.Interval = 1000;
                m_pTimer.Tick += new EventHandler(delegate(object s,EventArgs e){
                    m_pListView.Invoke(new MethodInvoker(delegate(){
                        if(m_ContentSize > 0){
                            m_pItem.SubItems["%"].Text = Convert.ToInt32((m_pStream.Position * 100) / m_ContentSize).ToString();
                        }
                        m_pItem.SubItems["mbsec"].Text   = ((m_pStream.Position - m_Received) / (decimal)1000000).ToString("f2");
                        m_pItem.SubItems["elapsed"].Text = ((TimeSpan)(DateTime.Now - m_StartTime)).ToString().Split('.')[0];
                    }));

                    m_Received = m_pStream.Position;
                });
                m_pTimer.Start();

                ThreadPool.QueueUserWorkItem(new WaitCallback(delegate(object state){
                    Run();
                }));
            }

            #region method Dispose

            /// <summary>
            /// Cleans up any resources being used.
            /// </summary>
            private void Dispose()
            {
                m_pTimer.Dispose();
                m_pStream.Dispose();

                m_pItem   = null;
                m_pDav    = null;
                m_pStream = null;
            }

            #endregion


            #region method Run

            private void Run()
            {
                try{
                    using(Stream stream = m_pDav.Get(m_TargetUri,out m_ContentSize)){
                        Net_Utils.StreamCopy(stream,m_pStream,32000);
                    }
                    
                    m_pListView.Invoke(new MethodInvoker(delegate(){
                        m_pItem.SubItems["%"].Text      = "100";
                        m_pItem.SubItems["mbsec"].Text  = "0";
                        m_pItem.SubItems["status"].Text = "Done";
                    }));
                }
                catch(Exception x){
                    m_pListView.Invoke(new MethodInvoker(delegate(){
                        m_pItem.SubItems["status"].Text = "Error";
                        m_pItem.SubItems["status"].Font = new Font(m_pItem.SubItems[4].Font,FontStyle.Underline);
                        m_pItem.SubItems["status"].ForeColor = Color.Red;
                        m_pItem.SubItems["status"].Tag = x;
                    }));
                }

                // We are done, cleanup.
                Dispose();
            }

            #endregion
        }

        #endregion

        private ImageList m_pFileImages   = null;
        private ListView  m_pList         = null;
        private ImageList m_pStatusImages = null;
        private ListView  m_pStatus       = null;

        private WebDav_Client m_pDav        = null;
        private string        m_RootHRef    = "";
        private string        m_CurrentHRef = "";
        private bool          m_IsConnected = false;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Main()
        {
            InitUI();
   
            m_pDav = new WebDav_Client();            
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(800,600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "LS WebDav Explorer";
            this.Icon = ResManager.GetIcon("app.ico");

            MenuStrip mainMenu = new MenuStrip();
            mainMenu.Dock = DockStyle.Top;            
            ToolStripMenuItem mainMenuFile = new ToolStripMenuItem("File");
            mainMenuFile.DropDownItems.Add(new ToolStripMenuItem("Connect",null,this.MainMenu_ItemClicked));
            mainMenuFile.DropDownItems.Add(new ToolStripMenuItem("Exit",null,this.MainMenu_ItemClicked));
            mainMenu.Items.Add(mainMenuFile);
            this.MainMenuStrip = mainMenu;

            m_pFileImages = new ImageList();
            m_pFileImages.ColorDepth = ColorDepth.Depth32Bit;
            m_pFileImages.ImageSize = new Size(16,16);
            m_pFileImages.Images.Add("folder",ResManager.GetIcon("folder.ico"));
            m_pFileImages.Images.Add("folderup",ResManager.GetIcon("folderup.ico"));

            m_pList = new ListView();
            m_pList.Size = new Size(800,400);
            m_pList.Location = new Point(0,25);
            m_pList.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            m_pList.BorderStyle = BorderStyle.None;
            m_pList.HideSelection = false;
            m_pList.FullRowSelect = true;
            m_pList.View = View.Details;
            m_pList.SmallImageList = m_pFileImages;
            m_pList.Columns.Add("Name",200);
            m_pList.Columns.Add("Size",100,HorizontalAlignment.Right);
            m_pList.Columns.Add("Date Modified",120,HorizontalAlignment.Right);
            m_pList.DoubleClick += new EventHandler(m_pList_DoubleClick);
            m_pList.MouseUp += new MouseEventHandler(m_pList_MouseUp);
            m_pList.KeyPress += new KeyPressEventHandler(m_pList_KeyPress);

            m_pStatusImages = new ImageList();
            m_pStatusImages.ColorDepth = ColorDepth.Depth32Bit;
            m_pStatusImages.ImageSize = new Size(16,16);
            m_pStatusImages.Images.Add("upload",ResManager.GetIcon("upload.ico"));
            m_pStatusImages.Images.Add("upload",ResManager.GetIcon("download.ico"));

            m_pStatus = new ListView();     
            m_pStatus.Size = new Size(800,170);
            m_pStatus.Location = new Point(0,430);
            m_pStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            m_pStatus.BorderStyle = BorderStyle.None;
            m_pStatus.HideSelection = false;
            m_pStatus.FullRowSelect = true;
            m_pStatus.View = View.Details;
            m_pStatus.SmallImageList = m_pStatusImages;
            m_pStatus.Columns.Add("source","Source",250);
            m_pStatus.Columns.Add("target","Target",250);
            m_pStatus.Columns.Add("%","%",50,HorizontalAlignment.Right,-1);
            m_pStatus.Columns.Add("mbsec","MB/S",50,HorizontalAlignment.Right,-1);
            m_pStatus.Columns.Add("elapsed","Elapsed",80,HorizontalAlignment.Right,-1);
            m_pStatus.Columns.Add("status","Status",100,HorizontalAlignment.Right,-1);
            m_pStatus.DoubleClick += new EventHandler(m_pStatus_DoubleClick);

            this.Controls.Add(m_pList);
            this.Controls.Add(m_pStatus);
            this.Controls.Add(mainMenu);
        }
                                                                                                
        #endregion


        #region Events handling

        #region method MainMenu_ItemClicked

        /// <summary>
        /// This method is called when some main menu item clicked.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void MainMenu_ItemClicked(object sender,EventArgs e)
        {
            try{
                ToolStripMenuItem item = (ToolStripMenuItem)sender;

                if(item.Text == "Connect"){
                    wfrm_Connect frm = new wfrm_Connect();
                    if(frm.ShowDialog(this) == DialogResult.OK){
                        if(frm.UserName == ""){
                            m_pDav.Credentials = null;
                        }
                        else{
                            m_pDav.Credentials = new System.Net.NetworkCredential(frm.UserName,frm.Password);
                        }
               
                        m_CurrentHRef = frm.Url;
                        if(!m_CurrentHRef.EndsWith("/")){
                            m_CurrentHRef += "/";
                        }
                        m_RootHRef = m_CurrentHRef;

                        FillList(m_CurrentHRef);

                        m_IsConnected = true;
                    }
                }
                else if(item.Text == "Exit"){
                    Application.Exit();
                }
            }
            catch(Exception x){
                MessageBox.Show(this,"Errors:\r\n" + x.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion


        #region method m_pList_KeyPress

        /// <summary>
        /// This method is called when listview has got keypress.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void m_pList_KeyPress(object sender,KeyPressEventArgs e)
        {
            m_pList_DoubleClick(sender,e);
        }

        #endregion

        #region method m_pList_DoubleClick

        /// <summary>
        /// This method is called when listview item has double clicked.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void m_pList_DoubleClick(object sender,EventArgs e)
        {
            if(m_pList.SelectedItems.Count > 0 && m_pList.SelectedItems[0].ImageKey.StartsWith("folder")){
                FileSystemItemInfo tag = (FileSystemItemInfo)m_pList.SelectedItems[0].Tag;

                FillList(tag.HRef);
                m_CurrentHRef = tag.HRef;
            }
        }

        #endregion

        #region method m_pList_MouseUp

        /// <summary>
        /// Is called when mouse button is released on items list view.
        /// </summary>
        /// <param name="sender">Seder.</param>
        /// <param name="e">Event data.</param>
        private void m_pList_MouseUp(object sender,MouseEventArgs e)
        {
            if(!m_IsConnected || e.Button != MouseButtons.Right){
                return;
            }

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add(new ToolStripMenuItem("New Folder",null,this.m_pList_MenuItemClicked));            
            menu.Items.Add(new ToolStripMenuItem("Upload File(s)",null,this.m_pList_MenuItemClicked));
            if(m_pList.SelectedItems.Count > 0){
                menu.Items.Add(new ToolStripMenuItem("Download File(s)",null,this.m_pList_MenuItemClicked));
                menu.Items.Add(new ToolStripMenuItem("Rename",null,this.m_pList_MenuItemClicked));
                menu.Items.Add(new ToolStripMenuItem("Delete",null,this.m_pList_MenuItemClicked));
            }
            menu.Show(Control.MousePosition);
        }

        #endregion

        #region method m_pList_MenuItemClicked

        /// <summary>
        /// This method is called when some list view menu item clicked.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void m_pList_MenuItemClicked(object sender,EventArgs e)
        {
            try{
                ToolStripMenuItem item = (ToolStripMenuItem)sender;

                if(item.Text == "New Folder"){
                    wfrm_Folder frm = new wfrm_Folder();
                    if(frm.ShowDialog(this) == DialogResult.OK){
                        m_pDav.MkCol(EndPath(m_CurrentHRef) + frm.FolderName);

                        FillList(m_CurrentHRef);
                    }
                }
                else if(item.Text == "Upload File(s)"){
                    OpenFileDialog dlg = new OpenFileDialog();
                    dlg.Multiselect = true;
                    if(dlg.ShowDialog(this) == DialogResult.OK){
                        foreach(string file in dlg.FileNames){
                            ListViewItem it = new ListViewItem(file);
                            it.SubItems.Add(m_CurrentHRef + Path.GetFileName(file)).Name = "target";
                            it.SubItems.Add("0").Name = "%";
                            it.SubItems.Add("0").Name = "mbsec";
                            it.SubItems.Add("00:00:00").Name = "elapsed";
                            it.SubItems.Add("Uploading").Name = "status";
                            it.UseItemStyleForSubItems = false;
                            it.ImageKey = "upload";
                            m_pStatus.Items.Add(it);

                            new FileUploader(m_pStatus,it,m_pDav,EndPath(m_CurrentHRef) + Path.GetFileName(file),File.OpenRead(file));
                        }
                    }
                }
                else if(item.Text == "Download File(s)"){
                    FolderBrowserDialog dlg = new FolderBrowserDialog();
                    if(dlg.ShowDialog(this) == DialogResult.OK){
                        foreach(ListViewItem it in m_pList.SelectedItems){
                            FileSystemItemInfo tag = (FileSystemItemInfo)it.Tag;

                            if(!tag.IsDirectory){
                                ListViewItem statusItem = new ListViewItem(tag.HRef);
                                statusItem.SubItems.Add(dlg.SelectedPath + "/" + Path.GetFileName(tag.HRef)).Name = "target";
                                statusItem.SubItems.Add("0").Name = "%";
                                statusItem.SubItems.Add("0").Name = "mbsec";
                                statusItem.SubItems.Add("00:00:00").Name = "elapsed";
                                statusItem.SubItems.Add("Downloading").Name = "status";
                                statusItem.UseItemStyleForSubItems = false;
                                statusItem.ImageKey = "download";
                                m_pStatus.Items.Add(statusItem);

                                new FileDownloader(m_pStatus,statusItem,m_pDav,tag.HRef,File.Create(dlg.SelectedPath + "/" + Path.GetFileName(tag.HRef)));
                            }
                        }
                    }
                }
                else if(item.Text == "Rename"){
                    FileSystemItemInfo tag = (FileSystemItemInfo)m_pList.SelectedItems[0].Tag;
                    string itemName = PathGetName(tag.HRef);

                    wfrm_Rename frm = new wfrm_Rename(itemName);
                    if(frm.ShowDialog(this) == DialogResult.OK){
                        m_pDav.Move(tag.HRef,PathMoveLeft(tag.HRef) + frm.ItemName,-1,false);

                        m_pList.SelectedItems[0].Text = frm.ItemName;
                    }                                 
                }
                else if(item.Text == "Delete"){
                    while(m_pList.SelectedItems.Count > 0){
                        FileSystemItemInfo tag = (FileSystemItemInfo)m_pList.SelectedItems[0].Tag;

                        m_pDav.Delete(tag.HRef);

                        m_pList.SelectedItems[0].Remove();
                    }             
                }
            }
            catch(Exception x){
                MessageBox.Show(this,"Errors:\r\n" + x.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        #region method m_pStatus_DoubleClick

        /// <summary>
        /// This method is called when status listview item has double clicked.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void m_pStatus_DoubleClick(object sender,EventArgs e)
        {
            if(m_pStatus.SelectedItems.Count > 0 && m_pStatus.SelectedItems[0].SubItems["status"].Text == "Error"){
                Exception x = (Exception)m_pStatus.SelectedItems[m_pStatus.Columns["status"].Index].SubItems[4].Tag;
                MessageBox.Show(this,"Errors:\r\n" + x.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        #endregion


        #region method FillList

        /// <summary>
        /// Fills list view with the specified href info.
        /// </summary>
        /// <param name="href">HRef location. For example: http://xxx/webdav/ .</param>
        private void FillList(string href)
        {
            m_pList.Items.Clear();
            
            // We are in child folder, show folder-up icon.
            if(m_RootHRef != href){
                ListViewItem item = new ListViewItem("...");
                item.Tag = new FileSystemItemInfo(false,"...",PathMoveLeft(href));
                item.ImageKey = "folderup";
                m_pList.Items.Add(item);
            }
            
            WebDav_MultiStatus responses = m_pDav.PropFind(href,new string[]{"displayname","getcontentlength","creationdate","resourcetype"},1);
                           
            foreach(WebDav_Response response in responses.Responses){
                // Skip root collection.
                if(string.Equals(href,response.HRef)){
                    continue;
                }

                StringBuilder errors = new StringBuilder();
                foreach(WebDav_PropStat propStat in response.PropStats){
                    if(propStat.Status.Split(' ')[1].StartsWith("2")){
                        ListViewItem item = new ListViewItem(propStat.Prop.Properties[0].Value);
                        item.SubItems.Add(SizeToString(Convert.ToInt64(propStat.Prop.Properties[1].Value)));
                        item.SubItems.Add(DateTime.Parse(propStat.Prop.Properties[2].Value).ToString());                        
                        WebDav_p_ResourceType resourceType = propStat.Prop.Prop_ResourceType;
                        if(resourceType.Contains(WebDav_ResourceTypes.collection)){
                            item.Tag = new FileSystemItemInfo(true,propStat.Prop.Properties[0].Value,response.HRef);
                            item.ImageKey = "folder";
                        }
                        else{
                            item.Tag = new FileSystemItemInfo(false,propStat.Prop.Properties[0].Value,response.HRef);
                            if(!m_pFileImages.Images.ContainsKey(Path.GetExtension(response.HRef))){
                                m_pFileImages.Images.Add(Path.GetExtension(response.HRef),GetFileIcon(response.HRef));
                            }
                            item.ImageKey = Path.GetExtension(response.HRef);
                        }       
                        m_pList.Items.Add(item);
                    }
                    // Error:
                    else{
                        errors.AppendLine("Href: " + response.HRef + "  " + propStat.Status + "\r\n");
                    }
                }

                // If there are errors, show them.
                if(errors.Length > 0){
                    MessageBox.Show(this,"Errors:\r\n" + errors.ToString(),"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                
                //foreach(WebDav_Property property in response.PropStats[0].Prop.Properties){
                //    Console.WriteLine(property.Name + ":" + property.Value);
                //}
            }

            m_pList.Focus();
            m_pList.Items[0].Selected = true;
        }

        #endregion

        #region method SizeToString

        private string SizeToString(long size)
        {
            if(size < 1000){
                return size.ToString() + " bytes";
            }
            else if(size < 1000000){
                return (size / 1000).ToString() + " KB";
            }
            else if(size < 1000000000){
                return (size / 1000000).ToString() + " MB";
            }
            else if(size < 1000000000000){
                return (size / 1000000000).ToString() + " TB";
            }
            else{
                return size.ToString();
            }
        }

        #endregion

        #region method GetFileIcon

        /// <summary>
		/// Returns an icon for a given file - indicated by the name parameter.
		/// </summary>
		/// <param name="name">Pathname for file.</param>
		/// <returns>System.Drawing.Icon</returns>
		private Icon GetFileIcon(string name)
		{
            try{
			    Shell32.SHFILEINFO shfi = new Shell32.SHFILEINFO();
			    uint flags = Shell32.SHGFI_ICON | Shell32.SHGFI_USEFILEATTRIBUTES | Shell32.SHGFI_SMALLICON;

			    Shell32.SHGetFileInfo(
                    name, 
				    Shell32.FILE_ATTRIBUTE_NORMAL, 
				    ref shfi, 
				    (uint) System.Runtime.InteropServices.Marshal.SizeOf(shfi), 
				    flags
                );

			    // Copy (clone) the returned icon to a new object, thus allowing us to clean-up properly
			    System.Drawing.Icon icon = (System.Drawing.Icon)System.Drawing.Icon.FromHandle(shfi.hIcon).Clone();
			    User32.DestroyIcon(shfi.hIcon);		// Cleanup

			    return icon;
            }
            catch{
                // return ResManager.GetIcon("attach");
                return null;
            }
		}

        private class Shell32  
	    {
    		
		    public const int 	MAX_PATH = 256;
		    [StructLayout(LayoutKind.Sequential)]
			    public struct SHITEMID
		    {
			    public ushort cb;
			    [MarshalAs(UnmanagedType.LPArray)]
			    public byte[] abID;
		    }

		    [StructLayout(LayoutKind.Sequential)]
			    public struct ITEMIDLIST
		    {
			    public SHITEMID mkid;
		    }

		    [StructLayout(LayoutKind.Sequential)]
			    public struct BROWSEINFO 
		    { 
			    public IntPtr		hwndOwner; 
			    public IntPtr		pidlRoot; 
			    public IntPtr 		pszDisplayName;
			    [MarshalAs(UnmanagedType.LPTStr)] 
			    public string 		lpszTitle; 
			    public uint 		ulFlags; 
			    public IntPtr		lpfn; 
			    public int			lParam; 
			    public IntPtr 		iImage; 
		    } 

		    // Browsing for directory.
		    public const uint BIF_RETURNONLYFSDIRS   =	0x0001;
		    public const uint BIF_DONTGOBELOWDOMAIN  =	0x0002;
		    public const uint BIF_STATUSTEXT         =	0x0004;
		    public const uint BIF_RETURNFSANCESTORS  =	0x0008;
		    public const uint BIF_EDITBOX            =	0x0010;
		    public const uint BIF_VALIDATE           =	0x0020;
		    public const uint BIF_NEWDIALOGSTYLE     =	0x0040;
		    public const uint BIF_USENEWUI           =	(BIF_NEWDIALOGSTYLE | BIF_EDITBOX);
		    public const uint BIF_BROWSEINCLUDEURLS  =	0x0080;
		    public const uint BIF_BROWSEFORCOMPUTER  =	0x1000;
		    public const uint BIF_BROWSEFORPRINTER   =	0x2000;
		    public const uint BIF_BROWSEINCLUDEFILES =	0x4000;
		    public const uint BIF_SHAREABLE          =	0x8000;

		    [StructLayout(LayoutKind.Sequential)]
			    public struct SHFILEINFO
		    { 
			    public const int NAMESIZE = 80;
			    public IntPtr	hIcon; 
			    public int		iIcon; 
			    public uint	dwAttributes; 
			    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=MAX_PATH)]
			    public string szDisplayName; 
			    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=NAMESIZE)]
			    public string szTypeName; 
		    };

		    public const uint SHGFI_ICON				= 0x000000100;     // get icon
		    public const uint SHGFI_DISPLAYNAME			= 0x000000200;     // get display name
		    public const uint SHGFI_TYPENAME          	= 0x000000400;     // get type name
		    public const uint SHGFI_ATTRIBUTES        	= 0x000000800;     // get attributes
		    public const uint SHGFI_ICONLOCATION      	= 0x000001000;     // get icon location
		    public const uint SHGFI_EXETYPE           	= 0x000002000;     // return exe type
		    public const uint SHGFI_SYSICONINDEX      	= 0x000004000;     // get system icon index
		    public const uint SHGFI_LINKOVERLAY       	= 0x000008000;     // put a link overlay on icon
		    public const uint SHGFI_SELECTED          	= 0x000010000;     // show icon in selected state
		    public const uint SHGFI_ATTR_SPECIFIED    	= 0x000020000;     // get only specified attributes
		    public const uint SHGFI_LARGEICON         	= 0x000000000;     // get large icon
		    public const uint SHGFI_SMALLICON         	= 0x000000001;     // get small icon
		    public const uint SHGFI_OPENICON          	= 0x000000002;     // get open icon
		    public const uint SHGFI_SHELLICONSIZE     	= 0x000000004;     // get shell size icon
		    public const uint SHGFI_PIDL              	= 0x000000008;     // pszPath is a pidl
		    public const uint SHGFI_USEFILEATTRIBUTES 	= 0x000000010;     // use passed dwFileAttribute
		    public const uint SHGFI_ADDOVERLAYS       	= 0x000000020;     // apply the appropriate overlays
		    public const uint SHGFI_OVERLAYINDEX      	= 0x000000040;     // Get the index of the overlay

		    public const uint FILE_ATTRIBUTE_DIRECTORY  = 0x00000010;  
		    public const uint FILE_ATTRIBUTE_NORMAL     = 0x00000080;  

		    [DllImport("Shell32.dll")]
		    public static extern IntPtr SHGetFileInfo(
			    string pszPath,
			    uint dwFileAttributes,
			    ref SHFILEINFO psfi,
			    uint cbFileInfo,
			    uint uFlags
			    );
	    }

	    /// <summary>
	    /// Wraps necessary functions imported from User32.dll. Code courtesy of MSDN Cold Rooster Consulting example.
	    /// </summary>
	    private class User32
	    {
		    /// <summary>
		    /// Provides access to function required to delete handle. This method is used internally
		    /// and is not required to be called separately.
		    /// </summary>
		    /// <param name="hIcon">Pointer to icon handle.</param>
		    /// <returns>N/A</returns>
		    [DllImport("User32.dll")]
		    public static extern int DestroyIcon( IntPtr hIcon );
        }

        #endregion

        #region method PathMoveLeft

        /// <summary>
        /// Moves one step left in the path.
        /// </summary>
        /// <param name="path">Path.</param>
        /// <returns>Returns ptah with one level left from original path.</returns>
        /// <exception cref="ArgumentNullException">Is raised when <b>path</b> is null reference.</exception>
        private string PathMoveLeft(string path)
        {
            if(path == null){
                throw new ArgumentNullException(path);
            }

            if(path.EndsWith("/")){
                path = path.Substring(0,path.Length - 1);
            }

            if(path.LastIndexOf("/") > -1){
                return path.Substring(0,path.LastIndexOf("/") + 1);
            }
            else{
                return path;
            }
        }

        #endregion

        #region method PathGetName

        /// <summary>
        /// Gets folder or file name from path.
        /// </summary>
        /// <param name="path">Path.</param>
        /// <returns>Returns folder or file name from path.</returns>
        /// <exception cref="ArgumentNullException">Is raised when when <b>path</b> is null reference.</exception>
        private string PathGetName(string path)
        {
            if(path == null){
                throw new ArgumentNullException("path");
            }

            if(path.EndsWith("/")){
                path = path.Substring(0,path.Length - 1);

                return path.Substring(path.LastIndexOf('/') + 1);
            }
            else{
                return path.Substring(path.LastIndexOf('/') + 1);
            }
        }

        #endregion

        #region method EndPath

        /// <summary>
        /// Ensures that path ends with '/'.
        /// </summary>
        /// <param name="path">Path.</param>
        /// <returns>Retruns path.</returns>
        private string EndPath(string path)
        {
            if(path.EndsWith("/")){
                return path;
            }
            else{
                return path + "/";
            }
        }

        #endregion
    }
}
