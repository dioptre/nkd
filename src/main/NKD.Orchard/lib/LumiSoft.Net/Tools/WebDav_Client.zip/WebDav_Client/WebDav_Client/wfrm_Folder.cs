﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using WebDavClient.Resources;

namespace WebDavClient
{
    /// <summary>
    /// Add/Rename folder window.
    /// </summary>
    public class wfrm_Folder : Form
    {
        private TextBox m_pFolder = null;
        private Button  m_pOk     = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Folder()
        {
            InitUI();
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="folderName">Folder name.</param>
        public wfrm_Folder(string folderName)
        {
            InitUI();

            m_pFolder.Text = folderName;
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(300,50);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Text = "Specify folder name.";
            this.Icon = ResManager.GetIcon("app.ico");

            m_pFolder = new TextBox();
            m_pFolder.Size = new Size(200,20);
            m_pFolder.Location = new Point(10,10);

            m_pOk = new Button();
            m_pOk.Size = new Size(70,20);
            m_pOk.Location = new Point(220,10);
            m_pOk.Text = "OK";
            m_pOk.Click += new EventHandler(m_pOk_Click);

            this.Controls.Add(m_pFolder);
            this.Controls.Add(m_pOk);
        }
                
        #endregion


        #region Events handling

        #region method m_pOk_Click

        private void m_pOk_Click(object sender,EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        #endregion

        #endregion


        #region Properties implementation

        /// <summary>
        /// Gets folder name.
        /// </summary>
        public string FolderName
        {
            get{ return m_pFolder.Text; }
        }

        #endregion
    }
}
