﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using WebDavClient.Resources;

namespace WebDavClient
{
    /// <summary>
    /// Connect window.
    /// </summary>
    public class wfrm_Connect : Form
    {
        private Label   mt_Url      = null;
        private TextBox m_pUrl      = null;
        private Label   mt_User     = null;
        private TextBox m_pUser     = null;
        private Label   mt_Password = null;
        private TextBox m_pPassword = null;
        private Button  m_pOk       = null;
        private Button  m_pCancel   = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Connect()
        {
            InitUI();
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(400,100);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Connect WebDav server";
            this.Icon = ResManager.GetIcon("app.ico");

            mt_Url = new Label();
            mt_Url.Size = new Size(100,20);
            mt_Url.Location = new Point(0,10);
            mt_Url.TextAlign = ContentAlignment.MiddleRight;
            mt_Url.Text = "URL:";

            m_pUrl = new TextBox();
            m_pUrl.Size = new Size(285,20);
            m_pUrl.Location = new Point(105,10);
            m_pUrl.Text = "http://server/";

            mt_User = new Label();
            mt_User.Size = new Size(100,20);
            mt_User.Location = new Point(0,35);
            mt_User.TextAlign = ContentAlignment.MiddleRight;
            mt_User.Text = "User:";

            m_pUser = new TextBox();
            m_pUser.Size = new Size(100,20);
            m_pUser.Location = new Point(105,35);
            m_pUser.Text = "Administrator";

            mt_Password = new Label();
            mt_Password.Size = new Size(100,20);
            mt_Password.Location = new Point(0,60);
            mt_Password.TextAlign = ContentAlignment.MiddleRight;
            mt_Password.Text = "User:";

            m_pPassword = new TextBox();
            m_pPassword.Size = new Size(100,20);
            m_pPassword.Location = new Point(105,60);
            m_pPassword.PasswordChar = '*';

            m_pOk = new Button();
            m_pOk.Size = new Size(70,20);
            m_pOk.Location = new Point(245,60);
            m_pOk.Text = "Ok";
            m_pOk.Click += new EventHandler(m_pOk_Click);

            m_pCancel = new Button();
            m_pCancel.Size = new Size(70,20);
            m_pCancel.Location = new Point(320,60);
            m_pCancel.Text = "Cancel";
            m_pCancel.Click += new EventHandler(m_pCancel_Click);

            this.Controls.Add(mt_Url);
            this.Controls.Add(m_pUrl);
            this.Controls.Add(mt_User);
            this.Controls.Add(m_pUser);
            this.Controls.Add(mt_Password);
            this.Controls.Add(m_pPassword);
            this.Controls.Add(m_pOk);
            this.Controls.Add(m_pCancel);
        }
                                
        #endregion


        #region Events handling

        #region method m_pOk_Click

        /// <summary>
        /// This method is called when Ok button has pressed.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void m_pOk_Click(object sender,EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        #endregion

        #region method m_pCancel_Click

        /// <summary>
        /// This method is called when Cancel button has pressed.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event data.</param>
        private void m_pCancel_Click(object sender,EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        #endregion

        #endregion


        #region Properties implementation

        /// <summary>
        /// Gets WebDav URL.
        /// </summary>
        public string Url
        {
            get{ return m_pUrl.Text; }
        }

        /// <summary>
        /// Gets user name.
        /// </summary>
        public string UserName
        {
            get{ return m_pUser.Text; }
        }

        /// <summary>
        /// Gets password.
        /// </summary>
        public string Password
        {
            get{ return m_pPassword.Text; }
        }

        #endregion
    }
}
