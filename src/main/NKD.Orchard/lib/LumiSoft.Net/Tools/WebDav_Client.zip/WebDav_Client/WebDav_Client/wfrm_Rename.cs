﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using WebDavClient.Resources;

namespace WebDavClient
{
    /// <summary>
    /// Rename item window.
    /// </summary>
    public class wfrm_Rename : Form
    {
        private TextBox m_pItemName = null;
        private Button  m_pOk       = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="itemName">Item name.</param>
        public wfrm_Rename(string itemName)
        {
            InitUI();

            m_pItemName.Text = itemName;
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(300,50);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Text = "Rename item.";
            this.Icon = ResManager.GetIcon("app.ico");

            m_pItemName = new TextBox();
            m_pItemName.Size = new Size(200,20);
            m_pItemName.Location = new Point(10,10);

            m_pOk = new Button();
            m_pOk.Size = new Size(70,20);
            m_pOk.Location = new Point(220,10);
            m_pOk.Text = "OK";
            m_pOk.Click += new EventHandler(m_pOk_Click);

            this.Controls.Add(m_pItemName);
            this.Controls.Add(m_pOk);
        }

        #endregion


        #region Events handling

        #region method m_pOk_Click

        private void m_pOk_Click(object sender,EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        #endregion

        #endregion


        #region Properties implementation

        /// <summary>
        /// Gets item name.
        /// </summary>
        public string ItemName
        {
            get{ return m_pItemName.Text; }
        }

        #endregion
    }
}
