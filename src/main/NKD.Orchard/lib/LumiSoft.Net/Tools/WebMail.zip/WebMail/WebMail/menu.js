function onMouseOver(object)
{
	if(object.className == "menu"){
		object.style.border="1px solid #C0C0C0";
		object.style.backgroundColor="#FAFFFA";
	}
	if(object.className == "menu2"){
		object.style.border="1px solid #C0C0C0";
		object.style.backgroundColor="#FAFFFA";
	}
}

function onMouseOut(object)
{
	if(object.className == "menu"){
        	object.style.border="1px solid #F0FFF0";
		object.style.backgroundColor="";
	}
	if(object.className == "menu2"){
		object.style.border="1px solid #FCFFFC";
		object.style.backgroundColor="";
	}
}

function onMouseDown(object)
{
	if(object.className == "menu"){
		object.style.border="1px solid #808080";
		object.style.backgroundColor="#FAFFFA";
	}
	if(object.className == "menu2"){
		object.style.border="1px solid #808080";
		object.style.backgroundColor="#FAFFFA";
	}
}

function onMouseUp(object)
{
	if(object.className == "menu"){
		object.style.border="1px solid #C0C0C0";
		object.style.backgroundColor="#FAFFFA";
	}
	if(object.className == "menu2"){
		object.style.border="1px solid #C0C0C0";
		object.style.backgroundColor="#FAFFFA";
	}

	onMenuButtonClick(object);
}
