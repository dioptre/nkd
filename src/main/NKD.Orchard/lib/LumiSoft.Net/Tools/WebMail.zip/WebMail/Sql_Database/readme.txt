


NOTE: you may use mailserver database for webmmail too, just run scripts to mailserver database !!!
