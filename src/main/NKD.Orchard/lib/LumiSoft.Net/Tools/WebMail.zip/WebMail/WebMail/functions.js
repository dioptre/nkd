function CheckEmailFormat(text)
{
	// Search for NOT Allowed Characters
	if(text.search(/[^A-Za-z0-9_.@-]/) != -1){
		return false;
	}
	
	var split_text = text.split("@");
	if(split_text.length != 2 || split_text[0].length < 1 || split_text[1].length < 1){
		return false;
	}
	
	var split_domain = split_text[1].split(".");
	for(var i=0;i<split_domain.length - 1;i++){
		if(split_domain[i].length < 1){
			return false;
		}
		if(split_domain[i].search(/[^A-Za-z0-9-]/) != -1){
			return false;
		}
	}

	if(split_domain.length < 2 || split_domain[split_domain.length - 1].length < 2 || split_domain[split_domain.length - 1].length > 4){
		return false;
	}
	
	if(split_domain[split_domain.length - 1].search(/[^A-Za-z0-9]/) != -1){
		return false;
	}
	
	return true;
}

