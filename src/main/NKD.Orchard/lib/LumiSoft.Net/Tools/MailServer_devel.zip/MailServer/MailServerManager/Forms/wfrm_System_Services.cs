using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace LumiSoft.MailServer.UI
{
    /// <summary>
    /// System Services window.
    /// </summary>
    public class wfrm_System_Services : Form
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_System_Services()
        {
            InitUI();
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes window UI.
        /// </summary>
        private void InitUI()
        {
        }

        #endregion
    }
}
