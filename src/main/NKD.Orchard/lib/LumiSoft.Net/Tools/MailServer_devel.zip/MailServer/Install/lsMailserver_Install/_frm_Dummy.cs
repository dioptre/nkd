using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace lsMailserver_Install
{
    public partial class _frm_Dummy : Form
    {
        public _frm_Dummy()
        {
            InitializeComponent();
        }
    }
}