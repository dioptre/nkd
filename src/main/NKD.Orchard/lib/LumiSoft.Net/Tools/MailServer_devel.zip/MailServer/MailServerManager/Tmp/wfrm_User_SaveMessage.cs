using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace LumiSoft.MailServer.UI.Forms
{
    /* TODO: See if can make this window more universal, 
     *       so that can be used other stream transfer operations too.
    */ 

    /// <summary>
    /// Save user message progress window.
    /// </summary>
    public class wfrm_User_SaveMessage : Form
    {
        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_User_SaveMessage()
        {
            InitUI();
        }        
        
        #region method InitUI

        /// <summary>
        /// Creates and initializes window UI.
        /// </summary>
        private void InitUI()
        {
        }

        #endregion
    }
}
