using System;
using System.Windows.Forms;

namespace IMAP_sync
{
	/// <summary>
	/// Application main class.
	/// </summary>
	public class MainX
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
			Application.Run(new wfrm_utils_MessagesTransferer());
		}

        /// <summary>
        /// Unhandled exception handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        static void Application_ThreadException(object sender,System.Threading.ThreadExceptionEventArgs e)
        {
            MessageBox.Show("Error:" + e.Exception.ToString(),"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }
	}
}
