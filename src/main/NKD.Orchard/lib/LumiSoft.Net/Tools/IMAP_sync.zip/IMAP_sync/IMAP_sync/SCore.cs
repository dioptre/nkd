using System;
using System.IO;

namespace IMAP_sync
{
	/// <summary>
	/// Utility functions.
	/// </summary>
	internal class SCore
	{
        #region static method StreamCopy

        /// <summary>
        /// Copies all data from source stream to destination stream.
        /// Copy starts from source stream current position and will be copied to the end of source stream.
        /// </summary>
        /// <param name="source">Source stream.</param>
        /// <param name="destination">Destination stream.</param>
        public static void StreamCopy(Stream source,Stream destination)
        {
            byte[] buffer = new byte[8000];
            int readedCount = source.Read(buffer,0,buffer.Length);
            while(readedCount > 0){
                destination.Write(buffer,0,readedCount);

                readedCount = source.Read(buffer,0,buffer.Length);
            }
        }

        #endregion
    }
}
