using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using LumiSoft.Net.Mime.vCard;

namespace vCardViewer
{
    /// <summary>
    /// Application main window.
    /// </summary>
    public class wfrm_Main : Form
    {
        //--- Common UI -------------------
        private TabControl m_pTab   = null;
        private Button     m_pLoad  = null;
        private Button     m_pSave  = null;
        private Button     m_pClose = null;
        //--- Tabpage Summary UI ------------------------------
        private PictureBox m_pTab_Summary_Image         = null;
        private Label      mt_Tab_Summary_Label         = null;
        private GroupBox   m_pTab_Summary_Groupbox      = null;
        private PictureBox m_pTab_Summary_Photo         = null;
        private ToolStrip  m_pTab_Summary_PhotoToolbar  = null; 
        private Label      mt_Tab_Summary_Name          = null;
        private Label      m_pTab_Summary_Name          = null;
        private Label      mt_Tab_Summary_Email         = null;
        private LinkLabel  m_pTab_Summary_Email         = null;
        private Label      mt_Tab_Summry_HomePhone      = null;
        private Label      m_pTab_Summry_HomePhone      = null;
        private Label      mt_Tab_Summary_Pager         = null;
        private Label      m_pTab_Summary_Pager         = null;
        private Label      mt_Tab_Summary_Mobile        = null;
        private Label      m_pTab_Summary_Mobile        = null;
        private Label      mt_Tab_Summary_PersonalWWW   = null;
        private LinkLabel  m_pTab_Summary_PersonalWWW   = null;
        private Label      mt_Tab_Summary_BusinessPhone = null;
        private Label      m_pTab_Summary_BusinessPhone = null;
        private Label      mt_Tab_Summary_BusinessFax   = null;
        private Label      m_pTab_Summary_BusinessFax   = null;
        private Label      mt_Tab_Summary_JobTitle      = null;
        private Label      m_pTab_Summary_JobTitle      = null;
        private Label      mt_Tab_Summary_Department    = null;
        private Label      m_pTab_Summary_Department    = null;
        private Label      mt_Tab_Summary_Office        = null;
        private Label      m_pTab_Summary_Office        = null;
        private Label      mt_Tab_Summary_Company       = null;
        private Label      m_pTab_Summary_Company       = null;
        private Label      mt_Tab_Summary_BusinessWWW   = null;
        private LinkLabel  m_pTab_Summary_BusinessWWW   = null;
        //--- Tabpage personal -----------------------------------         
        private PictureBox     m_pTab_Personal_Image       = null;
        private Label          mt_Tab_Personal_Label       = null;
        private GroupBox       m_pTab_Personal_Groupbox    = null;
        private Label          mt_Tab_Personal_FirstName   = null;
        private TextBox        m_pTab_Personal_FirstName   = null;
        private Label          mt_Tab_Personal_MiddleName  = null;
        private TextBox        m_pTab_Personal_MiddleName  = null;
        private Label          mt_Tab_Personal_LastName    = null;
        private TextBox        m_pTab_Personal_LastName    = null;
        private Label          mt_Tab_Personal_Title       = null;
        private TextBox        m_pTab_Personal_Title       = null;
        private Label          mt_Tab_Personal_DisplayName = null;
        private ComboBox       m_pTab_Personal_DisplayName = null;
        private Label          mt_Tab_Personal_Nickname    = null;
        private TextBox        m_pTab_Personal_Nickname    = null;
        private Label          mt_Tab_Personal_BirthDay    = null;
        private DateTimePicker m_pTab_Personal_BirthDay    = null;
        private Label          mt_Tab_Personal_Email       = null;
        private TextBox        m_pTab_Personal_Email       = null;
        private ListView       m_pTab_Personal_Emails      = null;
        private Button         m_pTab_Personal_Add         = null;
        private Button         m_pTab_Personal_Remove      = null;
        private Button         m_pTab_Personal_SetDefault  = null;
        //--- Tabpage Home UI ------------------------
        private PictureBox m_pTab_Home_Image    = null;
        private Label      mt_Tab_Home_Label    = null;
        private GroupBox   m_pTab_Home_Groupbox = null;
        private Label      mt_Tab_Home_Street   = null;
        private TextBox    m_pTab_Home_Street   = null;
        private Label      mt_Tab_Home_Phone    = null;
        private TextBox    m_pTab_Home_Phone    = null;
        private Label      mt_Tab_Home_Fax      = null;
        private TextBox    m_pTab_Home_Fax      = null;
        private Label      mt_Tab_Home_City     = null;
        private TextBox    m_pTab_Home_City     = null;
        private Label      mt_Tab_Home_Mobile   = null;
        private TextBox    m_pTab_Home_Mobile   = null;
        private Label      mt_Tab_Home_Province = null;
        private TextBox    m_pTab_Home_Province = null;        
        private Label      mt_Tab_Home_ZipCode  = null;
        private TextBox    m_pTab_Home_ZipCode  = null;        
        private Label      mt_Tab_Home_Country  = null;
        private TextBox    m_pTab_Home_Country  = null;
        private Label      mt_Tab_Home_WWW      = null;
        private TextBox    m_pTab_Home_WWW      = null;
        //--- Tabpage Business UI --------------------------
        private PictureBox m_pTab_Business_Image      = null;
        private Label      mt_Tab_Business_Label      = null;
        private GroupBox   m_pTab_Business_Groupbox   = null;
        private Label      mt_Tab_Business_Company    = null;
        private TextBox    m_pTab_Business_Company    = null;        
        private Label      mt_Tab_Business_JobTitle   = null;
        private TextBox    m_pTab_Business_JobTitle   = null;        
        private Label      mt_Tab_Business_Street     = null;
        private TextBox    m_pTab_Business_Street     = null;
        private Label      mt_Tab_Business_Department = null;
        private TextBox    m_pTab_Business_Department = null;
        private Label      mt_Tab_Business_Office     = null;
        private TextBox    m_pTab_Business_Office     = null;
        private Label      mt_Tab_Business_City       = null;
        private TextBox    m_pTab_Business_City       = null;
        private Label      mt_Tab_Business_Phone      = null;
        private TextBox    m_pTab_Business_Phone      = null;
        private Label      mt_Tab_Business_Province   = null;
        private TextBox    m_pTab_Business_Province   = null;
        private Label      mt_Tab_Business_Fax        = null;
        private TextBox    m_pTab_Business_Fax        = null;
        private Label      mt_Tab_Business_ZipCode    = null;
        private TextBox    m_pTab_Business_ZipCode    = null;
        private Label      mt_Tab_Business_Pager      = null;
        private TextBox    m_pTab_Business_Pager      = null;
        private Label      mt_Tab_Business_Country    = null;
        private TextBox    m_pTab_Business_Country    = null;
        private Label      mt_Tab_Business_WWW        = null;
        private TextBox    m_pTab_Business_WWW        = null;
        //--- Tabpage Notes UI -------------------------
        private PictureBox m_pTab_Notes_Image    = null;
        private Label      mt_Tab_Notes_Label    = null;
        private GroupBox   m_pTab_Notes_Groupbox = null;
        private Label      mt_Tab_Notes_Notes    = null;
        private TextBox    m_pTab_Notes_Notes    = null;

        private vCard m_pvCard = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Main()
        {
            InitUI();

            ClearUIData();

            m_pvCard = new vCard();
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes window UI.
        /// </summary>
        private void InitUI()
        {
            this.Size = new Size(503,420);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.Icon = ResManager.GetIcon("main.ico");
            this.MaximizeBox = false;
            this.Text = "vCard:";

            #region Common UI

            //--- Common UI ------------------------------------------------------------------//
            m_pTab = new TabControl();
            m_pTab.Size = new Size(485,350);
            m_pTab.Location = new Point(5,5);
            m_pTab.TabPages.Add("Summary");
            m_pTab.TabPages.Add("Personal");
            m_pTab.TabPages.Add("Home");
            m_pTab.TabPages.Add("Business");
            m_pTab.TabPages.Add("Notes");
            m_pTab.SelectedIndexChanged += new EventHandler(m_pTab_SelectedIndexChanged);

            m_pLoad = new Button();
            m_pLoad.Size = new Size(70,20);
            m_pLoad.Location = new Point(265,370);
            m_pLoad.Text = "Load";
            m_pLoad.Click += new EventHandler(m_pLoad_Click);

            m_pSave = new Button();
            m_pSave.Size = new Size(70,20);
            m_pSave.Location = new Point(340,370);
            m_pSave.Text = "Save";
            m_pSave.Click += new EventHandler(m_pSave_Click);

            m_pClose = new Button();
            m_pClose.Size = new Size(70,20);
            m_pClose.Location = new Point(420,370);
            m_pClose.Text = "Close";
            m_pClose.Click += new EventHandler(m_pClose_Click);

            this.Controls.Add(m_pTab);
            this.Controls.Add(m_pLoad);
            this.Controls.Add(m_pSave);
            this.Controls.Add(m_pClose);
            //--------------------------------------------------------------------------------//

            #endregion

            #region Summary UI

            //--- Tabpage Summary UI ---------------------------------------------------------//            
            m_pTab_Summary_Image = new PictureBox();
            m_pTab_Summary_Image.Size = new Size(32,32);
            m_pTab_Summary_Image.Location = new Point(10,10);
            m_pTab_Summary_Image.Image = ResManager.GetIcon("summary.ico").ToBitmap();
                        
            mt_Tab_Summary_Label = new Label();
            mt_Tab_Summary_Label.Size = new Size(300,32);
            mt_Tab_Summary_Label.Location = new Point(45,10);
            mt_Tab_Summary_Label.TextAlign = ContentAlignment.MiddleLeft;
            mt_Tab_Summary_Label.Text = "Summary of information about this contact.";

            m_pTab_Summary_Groupbox = new GroupBox();
            m_pTab_Summary_Groupbox.Size = new Size(465,3);
            m_pTab_Summary_Groupbox.Location = new Point(5,50);

            m_pTab_Summary_Photo = new PictureBox();
            m_pTab_Summary_Photo.Size = new Size(100,120);
            m_pTab_Summary_Photo.Location = new Point(365,60);
            m_pTab_Summary_Photo.SizeMode = PictureBoxSizeMode.StretchImage;
            //m_pTab_Summary_Photo.BorderStyle = BorderStyle.FixedSingle;

            m_pTab_Summary_PhotoToolbar = new ToolStrip();
            m_pTab_Summary_PhotoToolbar.Size = new Size(100,20);
            m_pTab_Summary_PhotoToolbar.Location = new Point(365,180);
            m_pTab_Summary_PhotoToolbar.Dock = DockStyle.None;
            m_pTab_Summary_PhotoToolbar.BackColor = this.BackColor;
            m_pTab_Summary_PhotoToolbar.GripStyle = ToolStripGripStyle.Hidden;
            m_pTab_Summary_PhotoToolbar.RenderMode = ToolStripRenderMode.Professional;
            m_pTab_Summary_PhotoToolbar.Renderer = new ToolBarRendererEx();
            m_pTab_Summary_PhotoToolbar.Items.Add(new ToolStripButton("",ResManager.GetIcon("add.ico").ToBitmap(),null,"add"));
            m_pTab_Summary_PhotoToolbar.Items.Add(new ToolStripButton("",ResManager.GetIcon("remove.ico").ToBitmap(),null,"remove"));
            m_pTab_Summary_PhotoToolbar.ItemClicked += new ToolStripItemClickedEventHandler(m_pTab_Summary_PhotoToolbar_ItemClicked);
            
            mt_Tab_Summary_Name = new Label();
            mt_Tab_Summary_Name.Size = new Size(150,20);
            mt_Tab_Summary_Name.Location = new Point(0,60);
            mt_Tab_Summary_Name.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Name.Text = "Name:";

            m_pTab_Summary_Name = new Label();
            m_pTab_Summary_Name.Size = new Size(300,20);
            m_pTab_Summary_Name.Location = new Point(155,60);
            m_pTab_Summary_Name.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_Email = new Label();
            mt_Tab_Summary_Email.Size = new Size(150,20);
            mt_Tab_Summary_Email.Location = new Point(0,80);
            mt_Tab_Summary_Email.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Email.Text = "E-Mail Address:";

            m_pTab_Summary_Email = new LinkLabel();
            m_pTab_Summary_Email.Size = new Size(300,20);
            m_pTab_Summary_Email.Location = new Point(155,80);
            m_pTab_Summary_Email.TextAlign = ContentAlignment.MiddleLeft;
            m_pTab_Summary_Email.LinkClicked += new LinkLabelLinkClickedEventHandler(m_pTab_Summary_Email_LinkClicked);

            mt_Tab_Summry_HomePhone = new Label();
            mt_Tab_Summry_HomePhone.Size = new Size(150,20);
            mt_Tab_Summry_HomePhone.Location = new Point(0,100);
            mt_Tab_Summry_HomePhone.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summry_HomePhone.Text = "Home Phone:";

            m_pTab_Summry_HomePhone = new Label();
            m_pTab_Summry_HomePhone.Size = new Size(300,20);
            m_pTab_Summry_HomePhone.Location = new Point(155,100);
            m_pTab_Summry_HomePhone.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_Pager = new Label();
            mt_Tab_Summary_Pager.Size = new Size(150,20);
            mt_Tab_Summary_Pager.Location = new Point(0,120);
            mt_Tab_Summary_Pager.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Pager.Text = "Pager:";

            m_pTab_Summary_Pager = new Label();
            m_pTab_Summary_Pager.Size = new Size(300,20);
            m_pTab_Summary_Pager.Location = new Point(155,120);
            m_pTab_Summary_Pager.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_Mobile = new Label();
            mt_Tab_Summary_Mobile.Size = new Size(150,20);
            mt_Tab_Summary_Mobile.Location = new Point(0,140);
            mt_Tab_Summary_Mobile.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Mobile.Text = "Mobile:";

            m_pTab_Summary_Mobile = new Label();
            m_pTab_Summary_Mobile.Size = new Size(300,20);
            m_pTab_Summary_Mobile.Location = new Point(155,140);
            m_pTab_Summary_Mobile.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_PersonalWWW = new Label();
            mt_Tab_Summary_PersonalWWW.Size = new Size(150,20);
            mt_Tab_Summary_PersonalWWW.Location = new Point(0,160);
            mt_Tab_Summary_PersonalWWW.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_PersonalWWW.Text = "Personal Web Page:";

            m_pTab_Summary_PersonalWWW = new LinkLabel();
            m_pTab_Summary_PersonalWWW.Size = new Size(300,20);
            m_pTab_Summary_PersonalWWW.Location = new Point(155,160);
            m_pTab_Summary_PersonalWWW.TextAlign = ContentAlignment.MiddleLeft;
            m_pTab_Summary_PersonalWWW.LinkClicked += new LinkLabelLinkClickedEventHandler(m_pTab_Summary_Http_LinkClicked);

            mt_Tab_Summary_BusinessPhone = new Label();
            mt_Tab_Summary_BusinessPhone.Size = new Size(150,20);
            mt_Tab_Summary_BusinessPhone.Location = new Point(0,180);
            mt_Tab_Summary_BusinessPhone.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_BusinessPhone.Text = "Business Phone:";

            m_pTab_Summary_BusinessPhone = new Label();
            m_pTab_Summary_BusinessPhone.Size = new Size(300,20);
            m_pTab_Summary_BusinessPhone.Location = new Point(155,180);
            m_pTab_Summary_BusinessPhone.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_BusinessFax = new Label();
            mt_Tab_Summary_BusinessFax.Size = new Size(150,20);
            mt_Tab_Summary_BusinessFax.Location = new Point(0,200);
            mt_Tab_Summary_BusinessFax.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_BusinessFax.Text = "Business Fax:";

            m_pTab_Summary_BusinessFax = new Label();
            m_pTab_Summary_BusinessFax.Size = new Size(300,20);
            m_pTab_Summary_BusinessFax.Location = new Point(155,200);
            m_pTab_Summary_BusinessFax.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_JobTitle = new Label();
            mt_Tab_Summary_JobTitle.Size = new Size(150,20);
            mt_Tab_Summary_JobTitle.Location = new Point(0,220);
            mt_Tab_Summary_JobTitle.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_JobTitle.Text = "Job Title:";

            m_pTab_Summary_JobTitle = new Label();
            m_pTab_Summary_JobTitle.Size = new Size(300,20);
            m_pTab_Summary_JobTitle.Location = new Point(155,220);
            m_pTab_Summary_JobTitle.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_Department = new Label();
            mt_Tab_Summary_Department.Size = new Size(150,20);
            mt_Tab_Summary_Department.Location = new Point(0,240);
            mt_Tab_Summary_Department.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Department.Text = "Department:";

            m_pTab_Summary_Department = new Label();
            m_pTab_Summary_Department.Size = new Size(300,20);
            m_pTab_Summary_Department.Location = new Point(155,240);
            m_pTab_Summary_Department.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_Office = new Label();
            mt_Tab_Summary_Office.Size = new Size(150,20);
            mt_Tab_Summary_Office.Location = new Point(0,260);
            mt_Tab_Summary_Office.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Office.Text = "Office:";

            m_pTab_Summary_Office = new Label();
            m_pTab_Summary_Office.Size = new Size(300,20);
            m_pTab_Summary_Office.Location = new Point(155,260);
            m_pTab_Summary_Office.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_Company = new Label();
            mt_Tab_Summary_Company.Size = new Size(150,20);
            mt_Tab_Summary_Company.Location = new Point(0,280);
            mt_Tab_Summary_Company.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_Company.Text = "Company Name:";

            m_pTab_Summary_Company = new Label();
            m_pTab_Summary_Company.Size = new Size(300,20);
            m_pTab_Summary_Company.Location = new Point(155,280);
            m_pTab_Summary_Company.TextAlign = ContentAlignment.MiddleLeft;

            mt_Tab_Summary_BusinessWWW = new Label();
            mt_Tab_Summary_BusinessWWW.Size = new Size(150,20);
            mt_Tab_Summary_BusinessWWW.Location = new Point(0,300);
            mt_Tab_Summary_BusinessWWW.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Summary_BusinessWWW.Text = "Business Web Page:";

            m_pTab_Summary_BusinessWWW = new LinkLabel();
            m_pTab_Summary_BusinessWWW.Size = new Size(300,20);
            m_pTab_Summary_BusinessWWW.Location = new Point(155,300);
            m_pTab_Summary_BusinessWWW.TextAlign = ContentAlignment.MiddleLeft;
            m_pTab_Summary_BusinessWWW.LinkClicked += new LinkLabelLinkClickedEventHandler(m_pTab_Summary_Http_LinkClicked);
            
            //--- Tabpage Summary UI -----------
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Image);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Label);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Groupbox);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Photo);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_PhotoToolbar);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Name);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Name);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Email);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Email);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summry_HomePhone);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summry_HomePhone);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Pager);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Pager);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Mobile);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Mobile);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_PersonalWWW);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_PersonalWWW);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_BusinessPhone);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_BusinessPhone);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_BusinessFax);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_BusinessFax);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_JobTitle);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_JobTitle);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Department);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Department);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Office);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Office);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_Company);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_Company);
            m_pTab.TabPages[0].Controls.Add(mt_Tab_Summary_BusinessWWW);
            m_pTab.TabPages[0].Controls.Add(m_pTab_Summary_BusinessWWW);
            //--------------------------------------------------------------------------------//

            #endregion

            #region Personal UI

            //--- Tabpage Personal UI --------------------------------------------------------//
            m_pTab_Personal_Image = new PictureBox();
            m_pTab_Personal_Image.Size = new Size(32,32);
            m_pTab_Personal_Image.Location = new Point(10,10);
            m_pTab_Personal_Image.Image = ResManager.GetIcon("personal.ico").ToBitmap();

            mt_Tab_Personal_Label = new Label();
            mt_Tab_Personal_Label.Size = new Size(300,32);
            mt_Tab_Personal_Label.Location = new Point(45,10);
            mt_Tab_Personal_Label.TextAlign = ContentAlignment.MiddleLeft;
            mt_Tab_Personal_Label.Text = "Personal information about this contact.";

            m_pTab_Personal_Groupbox = new GroupBox();
            m_pTab_Personal_Groupbox.Size = new Size(465,3);
            m_pTab_Personal_Groupbox.Location = new Point(5,50);

            mt_Tab_Personal_FirstName = new Label();
            mt_Tab_Personal_FirstName.Size = new Size(70,20);
            mt_Tab_Personal_FirstName.Location = new Point(0,60);
            mt_Tab_Personal_FirstName.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_FirstName.Text = "First:";

            m_pTab_Personal_FirstName = new TextBox();
            m_pTab_Personal_FirstName.Size = new Size(70,20);
            m_pTab_Personal_FirstName.Location = new Point(75,60);
            m_pTab_Personal_FirstName.TextChanged += new EventHandler(m_pTab_Personal_NameChanged);

            mt_Tab_Personal_MiddleName = new Label();
            mt_Tab_Personal_MiddleName.Size = new Size(70,20);
            mt_Tab_Personal_MiddleName.Location = new Point(150,60);
            mt_Tab_Personal_MiddleName.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_MiddleName.Text = "Middle:";

            m_pTab_Personal_MiddleName = new TextBox();
            m_pTab_Personal_MiddleName.Size = new Size(70,20);
            m_pTab_Personal_MiddleName.Location = new Point(225,60);
            m_pTab_Personal_MiddleName.TextChanged += new EventHandler(m_pTab_Personal_NameChanged);

            mt_Tab_Personal_LastName = new Label();
            mt_Tab_Personal_LastName.Size = new Size(70,20);
            mt_Tab_Personal_LastName.Location = new Point(300,60);
            mt_Tab_Personal_LastName.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_LastName.Text = "Last:";

            m_pTab_Personal_LastName = new TextBox();
            m_pTab_Personal_LastName.Size = new Size(90,20);
            m_pTab_Personal_LastName.Location = new Point(375,60);
            m_pTab_Personal_LastName.TextChanged += new EventHandler(m_pTab_Personal_NameChanged);

            mt_Tab_Personal_Title = new Label();
            mt_Tab_Personal_Title.Size = new Size(70,20);
            mt_Tab_Personal_Title.Location = new Point(0,85);
            mt_Tab_Personal_Title.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_Title.Text = "Title:";

            m_pTab_Personal_Title = new TextBox();
            m_pTab_Personal_Title.Size = new Size(70,20);
            m_pTab_Personal_Title.Location = new Point(75,85);

            mt_Tab_Personal_DisplayName = new Label();
            mt_Tab_Personal_DisplayName.Size = new Size(70,20);
            mt_Tab_Personal_DisplayName.Location = new Point(150,85);
            mt_Tab_Personal_DisplayName.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_DisplayName.Text = "Display:";

            m_pTab_Personal_DisplayName = new ComboBox();
            m_pTab_Personal_DisplayName.Size = new Size(240,20);
            m_pTab_Personal_DisplayName.Location = new Point(225,85);

            mt_Tab_Personal_Nickname = new Label();
            mt_Tab_Personal_Nickname.Size = new Size(70,20);
            mt_Tab_Personal_Nickname.Location = new Point(0,110);
            mt_Tab_Personal_Nickname.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_Nickname.Text = "Nickname:";

            m_pTab_Personal_Nickname = new TextBox();
            m_pTab_Personal_Nickname.Size = new Size(70,20);
            m_pTab_Personal_Nickname.Location = new Point(75,110);

            mt_Tab_Personal_BirthDay = new Label();
            mt_Tab_Personal_BirthDay.Size = new Size(70,20);
            mt_Tab_Personal_BirthDay.Location = new Point(0,135);
            mt_Tab_Personal_BirthDay.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_BirthDay.Text = "Birthday:";

            m_pTab_Personal_BirthDay = new DateTimePicker();
            m_pTab_Personal_BirthDay.Size = new Size(100,20);
            m_pTab_Personal_BirthDay.Location = new Point(75,135);
            m_pTab_Personal_BirthDay.Format = DateTimePickerFormat.Short;
            m_pTab_Personal_BirthDay.ShowCheckBox = true;
            m_pTab_Personal_BirthDay.Checked = false;

            mt_Tab_Personal_Email = new Label();
            mt_Tab_Personal_Email.Size = new Size(70,20);
            mt_Tab_Personal_Email.Location = new Point(0,165);
            mt_Tab_Personal_Email.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Personal_Email.Text = "Email:";

            m_pTab_Personal_Email = new TextBox();
            m_pTab_Personal_Email.Size = new Size(300,20);
            m_pTab_Personal_Email.Location = new Point(75,165);

            ImageList tab_Personal_Emails = new ImageList();
            tab_Personal_Emails.Images.Add(ResManager.GetIcon("email.ico"));
            m_pTab_Personal_Emails = new ListView();
            m_pTab_Personal_Emails.Size = new Size(300,100);
            m_pTab_Personal_Emails.Location = new Point(75,190);
            m_pTab_Personal_Emails.View = View.SmallIcon;
            m_pTab_Personal_Emails.HideSelection = false;
            m_pTab_Personal_Emails.FullRowSelect = true;
            m_pTab_Personal_Emails.SmallImageList = tab_Personal_Emails;
            m_pTab_Personal_Emails.Font = new Font(m_pTab_Personal_Emails.Font,FontStyle.Bold);
            m_pTab_Personal_Emails.Columns.Add("Email",280);
            m_pTab_Personal_Emails.SelectedIndexChanged += new EventHandler(m_pTab_Personal_Emails_SelectedIndexChanged);

            m_pTab_Personal_Add = new Button();
            m_pTab_Personal_Add.Size = new Size(90,20);
            m_pTab_Personal_Add.Location = new Point(385,165);
            m_pTab_Personal_Add.Text = "Add";
            m_pTab_Personal_Add.Click += new EventHandler(m_pTab_Personal_Add_Click);

            m_pTab_Personal_Remove = new Button();
            m_pTab_Personal_Remove.Size = new Size(90,20);
            m_pTab_Personal_Remove.Location = new Point(385,190);
            m_pTab_Personal_Remove.Enabled = false;
            m_pTab_Personal_Remove.Text = "Remove";
            m_pTab_Personal_Remove.Click += new EventHandler(m_pTab_Personal_Remove_Click);

            m_pTab_Personal_SetDefault = new Button();
            m_pTab_Personal_SetDefault.Size = new Size(90,20);
            m_pTab_Personal_SetDefault.Location = new Point(385,215);
            m_pTab_Personal_SetDefault.Enabled = false;
            m_pTab_Personal_SetDefault.Text = "Set as Default";
            m_pTab_Personal_SetDefault.Click += new EventHandler(m_pTab_Personal_SetDefault_Click);
            
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Image);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_Label);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Groupbox);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_FirstName);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_FirstName);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_MiddleName);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_MiddleName);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_LastName);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_LastName);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_Title);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Title);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_DisplayName);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_DisplayName);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_Nickname);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Nickname);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_BirthDay);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_BirthDay);
            m_pTab.TabPages[1].Controls.Add(mt_Tab_Personal_Email);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Email);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Emails);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Add);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_Remove);
            m_pTab.TabPages[1].Controls.Add(m_pTab_Personal_SetDefault);
            //--------------------------------------------------------------------------------//

            #endregion

            #region Home UI

            //--- Tabpage Home UI -----------------------------------------------------------//
            m_pTab_Home_Image = new PictureBox();
            m_pTab_Home_Image.Size = new Size(32,32);
            m_pTab_Home_Image.Location = new Point(10,10);
            m_pTab_Home_Image.Image = ResManager.GetIcon("home.ico").ToBitmap();

            mt_Tab_Home_Label = new Label();
            mt_Tab_Home_Label.Size = new Size(300,32);
            mt_Tab_Home_Label.Location = new Point(45,10);
            mt_Tab_Home_Label.TextAlign = ContentAlignment.MiddleLeft;
            mt_Tab_Home_Label.Text = "Home-related info about this contact.";

            m_pTab_Home_Groupbox = new GroupBox();
            m_pTab_Home_Groupbox.Size = new Size(465,3);
            m_pTab_Home_Groupbox.Location = new Point(5,50);

            mt_Tab_Home_Street = new Label();
            mt_Tab_Home_Street.Size = new Size(100,20);
            mt_Tab_Home_Street.Location = new Point(0,60);
            mt_Tab_Home_Street.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_Street.Text = "Street Address:";

            m_pTab_Home_Street = new TextBox();
            m_pTab_Home_Street.Size = new Size(130,50);
            m_pTab_Home_Street.Location = new Point(105,60);
            m_pTab_Home_Street.Multiline = true;

            mt_Tab_Home_Phone = new Label();
            mt_Tab_Home_Phone.Size = new Size(70,20);
            mt_Tab_Home_Phone.Location = new Point(240,60);
            mt_Tab_Home_Phone.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_Phone.Text = "Phone:";

            m_pTab_Home_Phone = new TextBox();
            m_pTab_Home_Phone.Size = new Size(150,20);
            m_pTab_Home_Phone.Location = new Point(315,60);

            mt_Tab_Home_Fax = new Label();
            mt_Tab_Home_Fax.Size = new Size(70,20);
            mt_Tab_Home_Fax.Location = new Point(240,85);
            mt_Tab_Home_Fax.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_Fax.Text = "Fax:";

            m_pTab_Home_Fax = new TextBox();
            m_pTab_Home_Fax.Size = new Size(150,20);
            m_pTab_Home_Fax.Location = new Point(315,85);

            mt_Tab_Home_City = new Label();
            mt_Tab_Home_City.Size = new Size(100,20);
            mt_Tab_Home_City.Location = new Point(0,115);
            mt_Tab_Home_City.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_City.Text = "City:";

            m_pTab_Home_City = new TextBox();
            m_pTab_Home_City.Size = new Size(130,20);
            m_pTab_Home_City.Location = new Point(105,115);

            mt_Tab_Home_Mobile = new Label();
            mt_Tab_Home_Mobile.Size = new Size(70,20);
            mt_Tab_Home_Mobile.Location = new Point(240,115);
            mt_Tab_Home_Mobile.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_Mobile.Text = "Mobile:";

            m_pTab_Home_Mobile = new TextBox();
            m_pTab_Home_Mobile.Size = new Size(150,20);
            m_pTab_Home_Mobile.Location = new Point(315,115);

            mt_Tab_Home_Province = new Label();
            mt_Tab_Home_Province.Size = new Size(100,20);
            mt_Tab_Home_Province.Location = new Point(0,140);
            mt_Tab_Home_Province.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_Province.Text = "State/Province:";

            m_pTab_Home_Province = new TextBox();
            m_pTab_Home_Province.Size = new Size(130,20);
            m_pTab_Home_Province.Location = new Point(105,140);

            mt_Tab_Home_ZipCode = new Label();
            mt_Tab_Home_ZipCode.Size = new Size(100,20);
            mt_Tab_Home_ZipCode.Location = new Point(0,165);
            mt_Tab_Home_ZipCode.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_ZipCode.Text = "Zip Code:";

            m_pTab_Home_ZipCode = new TextBox();
            m_pTab_Home_ZipCode.Size = new Size(130,20);
            m_pTab_Home_ZipCode.Location = new Point(105,165);

            mt_Tab_Home_Country = new Label();
            mt_Tab_Home_Country.Size = new Size(100,20);
            mt_Tab_Home_Country.Location = new Point(0,190);
            mt_Tab_Home_Country.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_Country.Text = "Country/Region:";

            m_pTab_Home_Country = new TextBox();
            m_pTab_Home_Country.Size = new Size(130,20);
            m_pTab_Home_Country.Location = new Point(105,190);

            mt_Tab_Home_WWW = new Label();
            mt_Tab_Home_WWW.Size = new Size(100,20);
            mt_Tab_Home_WWW.Location = new Point(0,225);
            mt_Tab_Home_WWW.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Home_WWW.Text = "Web Page:";

            m_pTab_Home_WWW = new TextBox();
            m_pTab_Home_WWW.Size = new Size(360,20);
            m_pTab_Home_WWW.Location = new Point(105,225);          
            
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Image);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Label);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Groupbox);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Street);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Street);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Phone);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Phone);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Fax);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Fax);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_City);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_City);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Mobile);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Mobile);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Province);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Province);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_ZipCode);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_ZipCode);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_Country);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_Country);
            m_pTab.TabPages[2].Controls.Add(mt_Tab_Home_WWW);
            m_pTab.TabPages[2].Controls.Add(m_pTab_Home_WWW);
            //--------------------------------------------------------------------------------//

            #endregion

            #region Business UI

            //--- Tabpage Business UI  -------------------------------------------------------//
            m_pTab_Business_Image = new PictureBox();
            m_pTab_Business_Image.Size = new Size(32,32);
            m_pTab_Business_Image.Location = new Point(10,10);
            m_pTab_Business_Image.Image = ResManager.GetIcon("business.ico").ToBitmap();

            mt_Tab_Business_Label = new Label();
            mt_Tab_Business_Label.Size = new Size(300,32);
            mt_Tab_Business_Label.Location = new Point(45,10);
            mt_Tab_Business_Label.TextAlign = ContentAlignment.MiddleLeft;
            mt_Tab_Business_Label.Text = "Business-related information about this contact.";

            m_pTab_Business_Groupbox = new GroupBox();
            m_pTab_Business_Groupbox.Size = new Size(465,3);
            m_pTab_Business_Groupbox.Location = new Point(5,50);

            mt_Tab_Business_Company = new Label();
            mt_Tab_Business_Company.Size = new Size(100,20);
            mt_Tab_Business_Company.Location = new Point(0,60);
            mt_Tab_Business_Company.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Company.Text = "Company:";

            m_pTab_Business_Company = new TextBox();
            m_pTab_Business_Company.Size = new Size(130,20);
            m_pTab_Business_Company.Location = new Point(105,60);

            mt_Tab_Business_JobTitle = new Label();
            mt_Tab_Business_JobTitle.Size = new Size(70,20);
            mt_Tab_Business_JobTitle.Location = new Point(240,60);
            mt_Tab_Business_JobTitle.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_JobTitle.Text = "Job Title:";

            m_pTab_Business_JobTitle = new TextBox();
            m_pTab_Business_JobTitle.Size = new Size(130,20);
            m_pTab_Business_JobTitle.Location = new Point(331,60);

            mt_Tab_Business_Street = new Label();
            mt_Tab_Business_Street.Size = new Size(100,20);
            mt_Tab_Business_Street.Location = new Point(0,85);
            mt_Tab_Business_Street.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Street.Text = "Street Address:";

            m_pTab_Business_Street = new TextBox();
            m_pTab_Business_Street.Size = new Size(130,50);
            m_pTab_Business_Street.Location = new Point(105,85);
            m_pTab_Business_Street.Multiline = true;

            mt_Tab_Business_Department = new Label();
            mt_Tab_Business_Department.Size = new Size(70,20);
            mt_Tab_Business_Department.Location = new Point(240,85);
            mt_Tab_Business_Department.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Department.Text = "Department:";

            m_pTab_Business_Department = new TextBox();
            m_pTab_Business_Department.Size = new Size(130,20);
            m_pTab_Business_Department.Location = new Point(331,85);

            mt_Tab_Business_Office = new Label();
            mt_Tab_Business_Office.Size = new Size(70,20);
            mt_Tab_Business_Office.Location = new Point(240,110);
            mt_Tab_Business_Office.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Office.Text = "Office:";

            m_pTab_Business_Office = new TextBox();
            m_pTab_Business_Office.Size = new Size(130,20);
            m_pTab_Business_Office.Location = new Point(331,110);

            mt_Tab_Business_City = new Label();
            mt_Tab_Business_City.Size = new Size(100,20);
            mt_Tab_Business_City.Location = new Point(0,140);
            mt_Tab_Business_City.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_City.Text = "City:";

            m_pTab_Business_City = new TextBox();
            m_pTab_Business_City.Size = new Size(130,20);
            m_pTab_Business_City.Location = new Point(105,140);

            mt_Tab_Business_Phone = new Label();
            mt_Tab_Business_Phone.Size = new Size(70,20);
            mt_Tab_Business_Phone.Location = new Point(240,140);
            mt_Tab_Business_Phone.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Phone.Text = "Phone:";

            m_pTab_Business_Phone = new TextBox();
            m_pTab_Business_Phone.Size = new Size(130,20);
            m_pTab_Business_Phone.Location = new Point(331,140);

            mt_Tab_Business_Province = new Label();
            mt_Tab_Business_Province.Size = new Size(100,20);
            mt_Tab_Business_Province.Location = new Point(0,165);
            mt_Tab_Business_Province.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Province.Text = "State/Province:";

            m_pTab_Business_Province = new TextBox();
            m_pTab_Business_Province.Size = new Size(130,20);
            m_pTab_Business_Province.Location = new Point(105,165);

            mt_Tab_Business_Fax = new Label();
            mt_Tab_Business_Fax.Size = new Size(70,20);
            mt_Tab_Business_Fax.Location = new Point(240,165);
            mt_Tab_Business_Fax.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Fax.Text = "Fax:";

            m_pTab_Business_Fax = new TextBox();
            m_pTab_Business_Fax.Size = new Size(130,20);
            m_pTab_Business_Fax.Location = new Point(331,165);

            mt_Tab_Business_ZipCode = new Label();
            mt_Tab_Business_ZipCode.Size = new Size(100,20);
            mt_Tab_Business_ZipCode.Location = new Point(0,190);
            mt_Tab_Business_ZipCode.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_ZipCode.Text = "Zip Code:";

            m_pTab_Business_ZipCode = new TextBox();
            m_pTab_Business_ZipCode.Size = new Size(130,20);
            m_pTab_Business_ZipCode.Location = new Point(105,190);

            mt_Tab_Business_Pager = new Label();
            mt_Tab_Business_Pager.Size = new Size(70,20);
            mt_Tab_Business_Pager.Location = new Point(240,190);
            mt_Tab_Business_Pager.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Pager.Text = "Pager:";

            m_pTab_Business_Pager = new TextBox();
            m_pTab_Business_Pager.Size = new Size(130,20);
            m_pTab_Business_Pager.Location = new Point(331,190);

            mt_Tab_Business_Country = new Label();
            mt_Tab_Business_Country.Size = new Size(100,20);
            mt_Tab_Business_Country.Location = new Point(0,215);
            mt_Tab_Business_Country.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_Country.Text = "Country/Region:";

            m_pTab_Business_Country = new TextBox();
            m_pTab_Business_Country.Size = new Size(130,20);
            m_pTab_Business_Country.Location = new Point(105,215);

            mt_Tab_Business_WWW = new Label();
            mt_Tab_Business_WWW.Size = new Size(100,20);
            mt_Tab_Business_WWW.Location = new Point(0,250);
            mt_Tab_Business_WWW.TextAlign = ContentAlignment.MiddleRight;
            mt_Tab_Business_WWW.Text = "Web Page:";

            m_pTab_Business_WWW = new TextBox();
            m_pTab_Business_WWW.Size = new Size(355,20);
            m_pTab_Business_WWW.Location = new Point(105,250);
            
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Image);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Label);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Groupbox);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Company);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Company);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_JobTitle);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_JobTitle);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Street);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Street);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Department);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Department);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Office);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Office);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_City);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_City);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Phone);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Phone);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Province);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Province);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Fax);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Fax);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_ZipCode);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_ZipCode);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Pager);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Pager);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_Country);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_Country);
            m_pTab.TabPages[3].Controls.Add(mt_Tab_Business_WWW);
            m_pTab.TabPages[3].Controls.Add(m_pTab_Business_WWW);
            //-------------------------------------------------------------------------------//

            #endregion

            #region Notes UI

            //--- Tabpage Notes UI -----------------------------------------------------------//
            m_pTab_Notes_Image = new PictureBox();
            m_pTab_Notes_Image.Size = new Size(32,32);
            m_pTab_Notes_Image.Location = new Point(10,10);
            m_pTab_Notes_Image.Image = ResManager.GetIcon("notes.ico").ToBitmap();

            mt_Tab_Notes_Label = new Label();
            mt_Tab_Notes_Label.Size = new Size(300,32);
            mt_Tab_Notes_Label.Location = new Point(45,10);
            mt_Tab_Notes_Label.TextAlign = ContentAlignment.MiddleLeft;
            mt_Tab_Notes_Label.Text = "Additional information about this contact.";

            m_pTab_Notes_Groupbox = new GroupBox();
            m_pTab_Notes_Groupbox.Size = new Size(465,3);
            m_pTab_Notes_Groupbox.Location = new Point(5,50);

            mt_Tab_Notes_Notes = new Label();
            mt_Tab_Notes_Notes.Size = new Size(150,20);
            mt_Tab_Notes_Notes.Location = new Point(2,60);
            mt_Tab_Notes_Notes.TextAlign = ContentAlignment.MiddleLeft;
            mt_Tab_Notes_Notes.Text = "Notes:";

            m_pTab_Notes_Notes = new TextBox();
            m_pTab_Notes_Notes.Size = new Size(465,220);
            m_pTab_Notes_Notes.Location = new Point(5,80);
            m_pTab_Notes_Notes.Multiline = true;
            
            m_pTab.TabPages[4].Controls.Add(m_pTab_Notes_Image);
            m_pTab.TabPages[4].Controls.Add(mt_Tab_Notes_Label);
            m_pTab.TabPages[4].Controls.Add(m_pTab_Notes_Groupbox);
            m_pTab.TabPages[4].Controls.Add(mt_Tab_Notes_Notes);
            m_pTab.TabPages[4].Controls.Add(m_pTab_Notes_Notes);
            //--------------------------------------------------------------------------------//

            #endregion
        }
                                                                
        #endregion


        #region Events Handling

        #region method m_pTab_SelectedIndexChanged

        private void m_pTab_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Refresh edited data on Summary tab
            if(m_pTab.SelectedTab.Text == "Summary"){                
                //--- Summary tab -------------------------------------------------------------//                                
                m_pTab_Summary_Name.Text = m_pTab_Personal_DisplayName.Text;
                m_pTab_Summary_Email.Text = "";
                if(m_pTab_Personal_Emails.Items.Count > 0){
                    m_pTab_Summary_Email.Text = ((EmailAddress)m_pTab_Personal_Emails.Items[0].Tag).Email;
                    foreach(ListViewItem item in m_pTab_Personal_Emails.Items){
                        EmailAddress email = (EmailAddress)item.Tag;
                        if((email.EmailType & EmailAddressType_enum.Preferred) != 0){
                            m_pTab_Summary_Email.Text = email.Email;
                        }
                    }
                }
                m_pTab_Summry_HomePhone.Text = m_pTab_Home_Phone.Text;
                m_pTab_Summary_Pager.Text = m_pTab_Business_Pager.Text;            
                m_pTab_Summary_Mobile.Text = m_pTab_Home_Mobile.Text;                
                m_pTab_Summary_PersonalWWW.Text = m_pTab_Home_WWW.Text;
                m_pTab_Summary_BusinessPhone.Text = m_pTab_Business_Phone.Text;
                m_pTab_Summary_BusinessFax.Text = m_pTab_Business_Fax.Text;
                m_pTab_Summary_JobTitle.Text =  m_pTab_Business_JobTitle.Text;
                m_pTab_Summary_Department.Text = m_pTab_Business_Department.Text;
                m_pTab_Summary_Office.Text = m_pTab_Business_Office.Text;
                m_pTab_Summary_Company.Text = m_pTab_Business_Company.Text;
                m_pTab_Summary_BusinessWWW.Text = m_pTab_Business_WWW.Text;
            }
        }

        #endregion


        #region method m_pTab_Summary_Email_LinkClicked

        private void m_pTab_Summary_Email_LinkClicked(object sender,LinkLabelLinkClickedEventArgs e)
        {            
            System.Diagnostics.Process.Start("mailto:" + ((LinkLabel)sender).Text);
        }

        #endregion

        #region method m_pTab_Summary_Http_LinkClicked

        private void m_pTab_Summary_Http_LinkClicked(object sender,LinkLabelLinkClickedEventArgs e)
        {            
            System.Diagnostics.Process.Start(((LinkLabel)sender).Text);
        }

        #endregion

        #region method m_pTab_Summary_PhotoToolbar_ItemClicked

        private void m_pTab_Summary_PhotoToolbar_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if(e.ClickedItem.Name == "add"){
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "Image files | *.gif;*.jpg";
                if(dlg.ShowDialog(this) == DialogResult.OK){
                    m_pTab_Summary_Photo.Image = Image.FromFile(dlg.FileName);
                }
            }
            else if(e.ClickedItem.Name == "remove"){
                Image noPhotoImage = ResManager.GetImage("nophoto.gif");
                noPhotoImage.Tag = "noimage";
                m_pTab_Summary_Photo.Image = noPhotoImage;
            }
        }

        #endregion


        #region method m_pTab_Personal_NameChanged

        private void m_pTab_Personal_NameChanged(object sender, EventArgs e)
        {
            m_pTab_Personal_DisplayName.Items.Clear();
            m_pTab_Personal_DisplayName.Items.Add(m_pTab_Personal_FirstName.Text + " " + m_pTab_Personal_MiddleName.Text + " " + m_pTab_Personal_LastName.Text);
            m_pTab_Personal_DisplayName.Items.Add(m_pTab_Personal_LastName.Text + " " + m_pTab_Personal_FirstName.Text + " " + m_pTab_Personal_MiddleName.Text);
            m_pTab_Personal_DisplayName.Items.Add(m_pTab_Personal_Nickname.Text);
            m_pTab_Personal_DisplayName.SelectedIndex = 0;
        }

        #endregion

        #region method m_pTab_Personal_Emails_SelectedIndexChanged

        private void m_pTab_Personal_Emails_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(m_pTab_Personal_Emails.SelectedItems.Count > 0){                
                m_pTab_Personal_Remove.Enabled = true;
                m_pTab_Personal_SetDefault.Enabled = true;
            }
            else{
                m_pTab_Personal_Remove.Enabled = false;
                m_pTab_Personal_SetDefault.Enabled = false;
            }
        }

        #endregion

        #region method m_pTab_Personal_Add_Click

        private void m_pTab_Personal_Add_Click(object sender, EventArgs e)
        {
            if(m_pTab_Personal_Email.Text == ""){
                return;
            }
            
            EmailAddress email = m_pvCard.EmailAddresses.Add(EmailAddressType_enum.Internet,m_pTab_Personal_Email.Text);

            ListViewItem item = new ListViewItem(m_pTab_Personal_Email.Text);
            item.ImageIndex = 0;
            item.Tag = email;
            m_pTab_Personal_Emails.Items.Add(item);
        }

        #endregion

        #region method m_pTab_Personal_Remove_Click

        private void m_pTab_Personal_Remove_Click(object sender, EventArgs e)
        {
            if(m_pTab_Personal_Emails.SelectedItems.Count > 0){
                EmailAddress email = (EmailAddress)m_pTab_Personal_Emails.SelectedItems[0].Tag;
                m_pvCard.EmailAddresses.Remove(email);
                m_pTab_Personal_Emails.SelectedItems[0].Remove();
            }
        }

        #endregion

        #region method m_pTab_Personal_SetDefault_Click

        private void m_pTab_Personal_SetDefault_Click(object sender, EventArgs e)
        {
            if(m_pTab_Personal_Emails.SelectedItems.Count > 0){
                // Clear pervious preferred flag
                foreach(ListViewItem item in m_pTab_Personal_Emails.Items){
                    EmailAddress email = (EmailAddress)item.Tag;
                    email.EmailType &= ~EmailAddressType_enum.Preferred;
                    item.Text = email.Email;
                }

                ((EmailAddress)m_pTab_Personal_Emails.SelectedItems[0].Tag).EmailType |= EmailAddressType_enum.Preferred;
                m_pTab_Personal_Emails.SelectedItems[0].Text += " (Default)";
            }
        }

        #endregion


        #region method m_pLoad_Click

        private void m_pLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "vCard files (.vcf) | *.vcf";
            if(dlg.ShowDialog(this) == DialogResult.OK){
                m_pvCard = new vCard();
                m_pvCard.Parse(dlg.FileName);

                LoadCard(m_pvCard);

                if(m_pvCard.FormattedName != null){
                    this.Text = "vCard: " + m_pvCard.FormattedName;
                }                
            }           
        }

        #endregion

        #region method m_pSave_Click

        private void m_pSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "vCard files (.vcf) | *.vcf";
            if(dlg.ShowDialog(this) == DialogResult.OK){
                UIDataToCard();

                m_pvCard.ToFile(dlg.FileName);
            }
        }

        #endregion

        #region method m_pClose_Click

        private void m_pClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #endregion


        #region method LoadCard

        /// <summary>
        /// Loads specified vCard info to UI.
        /// </summary>
        /// <param name="vcard"></param>
        private void LoadCard(vCard vcard)
        {
            ClearUIData();

            #region Summary

            //--- Summary tab -------------------------------------------------------------//
            if(vcard.Photo != null){
                m_pTab_Summary_Photo.Image = vcard.Photo;
            }
            if(vcard.FormattedName != null){
                m_pTab_Summary_Name.Text = vcard.FormattedName;
            }
            if(vcard.EmailAddresses.Count > 0){
                string emailAddress = vcard.EmailAddresses[0].Email;
                // Try to get first preferred address
                foreach(EmailAddress email in vcard.EmailAddresses){
                    if((email.EmailType & EmailAddressType_enum.Preferred) != 0){
                        emailAddress = email.Email;
                        break;
                    }
                }
                m_pTab_Summary_Email.Text = emailAddress; 
            }
            m_pTab_Summry_HomePhone.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Home | PhoneNumberType_enum.Voice);
            m_pTab_Summary_Pager.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Pager);            
            m_pTab_Summary_Mobile.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Cellular);
            if(vcard.HomeURL != null){
                m_pTab_Summary_PersonalWWW.Text = vcard.HomeURL; 
            }
            m_pTab_Summary_BusinessPhone.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Work | PhoneNumberType_enum.Voice);
            m_pTab_Summary_BusinessFax.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Work | PhoneNumberType_enum.Fax);
            if(vcard.Title != null){
                m_pTab_Summary_JobTitle.Text = vcard.Title;
            }
            if(vcard.Organization != null){
                string[] company_department_office = vcard.Organization.Split(';');
                if(company_department_office.Length >= 2){
                    m_pTab_Summary_Department.Text = company_department_office[1]; 
                }
                if(company_department_office.Length >= 3){
                    m_pTab_Summary_Office.Text = company_department_office[2]; 
                }
                if(company_department_office.Length >= 1){
                    m_pTab_Summary_Company.Text = company_department_office[0];
                }
            }
            if(vcard.WorkURL != null){
                m_pTab_Summary_BusinessWWW.Text = vcard.WorkURL;
            }

            #endregion

            #region Personal

            //--- Personal Tab -------------------------------------------------//
            if(vcard.Name != null){
                m_pTab_Personal_FirstName.Text   = vcard.Name.FirstName;
                m_pTab_Personal_MiddleName.Text  = vcard.Name.AdditionalNames;
                m_pTab_Personal_LastName.Text    = vcard.Name.LastName;
                m_pTab_Personal_Title.Text       = vcard.Name.HonorificPerfix;
                m_pTab_Personal_DisplayName.Text = vcard.FormattedName;                
            }
            if(vcard.NickName != null){
                m_pTab_Personal_Nickname.Text = vcard.NickName;
            }
            if(vcard.BirthDate != DateTime.MinValue){
                m_pTab_Personal_BirthDay.Value = vcard.BirthDate;
                m_pTab_Personal_BirthDay.Checked = true;
            }
            foreach(EmailAddress email in vcard.EmailAddresses){
                ListViewItem it = new ListViewItem(email.Email);
                it.ImageIndex = 0;
                it.Tag = email;
                if((email.EmailType & EmailAddressType_enum.Preferred) != 0){
                    it.Text += " (Default)";
                }
                m_pTab_Personal_Emails.Items.Add(it);
            }

            #endregion

            #region Home

            //--- Home Tab --------------------------------------------------//
            DeliveryAddress homeAddress = GetAddress(vcard.Addresses,DeliveryAddressType_enum.Home);
            if(homeAddress != null){
                m_pTab_Home_Street.Text = homeAddress.Street; 
            }
            m_pTab_Home_Phone.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Home | PhoneNumberType_enum.Voice);
            m_pTab_Home_Fax.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Home | PhoneNumberType_enum.Fax);
            if(homeAddress != null){
                m_pTab_Home_City.Text = homeAddress.Locality;
            }
            m_pTab_Home_Mobile.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Cellular);
            if(homeAddress != null){
                m_pTab_Home_Province.Text = homeAddress.Region;
            }
            if(homeAddress != null){
                m_pTab_Home_ZipCode.Text = homeAddress.PostalCode;
            }
            if(homeAddress != null){
                m_pTab_Home_Country.Text = homeAddress.Country;
            }
            if(vcard.HomeURL != null){
                m_pTab_Home_WWW.Text = vcard.HomeURL;
            }

            #endregion

            #region Business

            //--- Business Tab ----------------------------------------------//
            DeliveryAddress businessAddress = GetAddress(vcard.Addresses,DeliveryAddressType_enum.Work);
            if(vcard.Organization != null){
                m_pTab_Business_Company.Text = vcard.Organization.Split(';')[0];
            }
            if(vcard.Title != null){
                m_pTab_Business_JobTitle.Text = vcard.Title;
            }
            if(businessAddress != null){
                m_pTab_Business_Street.Text = businessAddress.Street;
            }
            if(vcard.Organization != null && vcard.Organization.Split(';').Length >= 2){
                m_pTab_Business_Department.Text = vcard.Organization.Split(';')[1];
            }
            if(vcard.Organization != null && vcard.Organization.Split(';').Length >= 3){
                m_pTab_Business_Office.Text = vcard.Organization.Split(';')[2];
            }
            if(businessAddress != null){
                m_pTab_Business_City.Text = businessAddress.Locality;
            }
            m_pTab_Business_Phone.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Work | PhoneNumberType_enum.Voice);
            if(businessAddress != null){
                m_pTab_Business_Province.Text = businessAddress.Region;
            }
            m_pTab_Business_Fax.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Work | PhoneNumberType_enum.Fax);
            if(businessAddress != null){
                m_pTab_Business_ZipCode.Text = businessAddress.PostalCode;
            }
            m_pTab_Business_Pager.Text = GetPhone(vcard.PhoneNumbers,PhoneNumberType_enum.Pager);
            if(businessAddress != null){
                m_pTab_Business_Country.Text = businessAddress.Country;
            }
            if(vcard.WorkURL != null){
                m_pTab_Business_WWW.Text = vcard.WorkURL;
            }

            #endregion

            #region Notes

            //--- Notes Tab -------------------------------------------------//
            if(vcard.NoteText != null){
                m_pTab_Notes_Notes.Text = vcard.NoteText;
            }

            #endregion                       

            m_pTab_Personal_Emails_SelectedIndexChanged(null,null);
        }

        #endregion

        #region method UIDataToCard

        /// <summary>
        /// Sets active UI data to active vCard.
        /// </summary>
        private void UIDataToCard()
        {            
            #region Personal

            //--- Personal Tab -------------------------------------------------//
            m_pvCard.Name = new Name(
                m_pTab_Personal_LastName.Text,
                m_pTab_Personal_FirstName.Text,
                m_pTab_Personal_MiddleName.Text,
                m_pTab_Personal_Title.Text,
                ""
            );
            m_pvCard.FormattedName = m_pTab_Personal_DisplayName.Text;
            if(m_pTab_Personal_Nickname.Text != ""){
                m_pvCard.NickName = m_pTab_Personal_Nickname.Text;
            }
            else{
                m_pvCard.NickName = null;
            }
            if(m_pTab_Personal_BirthDay.Checked){
                m_pvCard.BirthDate = m_pTab_Personal_BirthDay.Value;
            }

            #endregion

            #region Home

            //--- Home Tab --------------------------------------------------//
            DeliveryAddress homeAddress = GetAddress(m_pvCard.Addresses,DeliveryAddressType_enum.Home);            
            if(homeAddress != null){
                homeAddress.Street       = m_pTab_Home_Street.Text;
                homeAddress.Locality     = m_pTab_Home_City.Text;
                homeAddress.Region       = m_pTab_Home_Province.Text;
                homeAddress.PostalCode   = m_pTab_Home_ZipCode.Text;
                homeAddress.Country      = m_pTab_Home_Country.Text;
            }
            else{
                m_pvCard.Addresses.Add(
                    DeliveryAddressType_enum.Home,
                    "",
                    "",
                    m_pTab_Home_Street.Text,
                    m_pTab_Home_City.Text,
                    m_pTab_Home_Province.Text,
                    m_pTab_Home_ZipCode.Text,
                    m_pTab_Home_Country.Text
                );
            }
            PhoneNumber homePhone = GetPhoneEx(m_pvCard.PhoneNumbers,PhoneNumberType_enum.Home | PhoneNumberType_enum.Voice);
            if(homePhone != null){
                homePhone.Number = m_pTab_Home_Phone.Text;
            }
            else{
                m_pvCard.PhoneNumbers.Add(
                    PhoneNumberType_enum.Home | PhoneNumberType_enum.Voice,
                    m_pTab_Home_Phone.Text
                );
            }
            PhoneNumber homeFax = GetPhoneEx(m_pvCard.PhoneNumbers,PhoneNumberType_enum.Home | PhoneNumberType_enum.Fax);
            if(homeFax != null){
                homeFax.Number = m_pTab_Home_Fax.Text;
            }
            else{
                m_pvCard.PhoneNumbers.Add(
                    PhoneNumberType_enum.Home | PhoneNumberType_enum.Voice,
                    m_pTab_Home_Fax.Text
                );
            }
            PhoneNumber cellular = GetPhoneEx(m_pvCard.PhoneNumbers,PhoneNumberType_enum.Cellular);
            if(cellular != null){
                cellular.Number = m_pTab_Home_Phone.Text;
            }
            else{
                m_pvCard.PhoneNumbers.Add(
                    PhoneNumberType_enum.Cellular,
                    m_pTab_Home_Mobile.Text
                );
            }
            if(m_pTab_Home_WWW.Text != ""){
                m_pvCard.HomeURL = m_pTab_Home_WWW.Text;
            }
            else{
                m_pvCard.HomeURL = null;
            }

            #endregion

            #region Business

            //--- Business Tab ----------------------------------------------//
            DeliveryAddress businessAddress = GetAddress(m_pvCard.Addresses,DeliveryAddressType_enum.Work);
            if(businessAddress != null){
                businessAddress.Street       = m_pTab_Business_Street.Text;
                businessAddress.Locality     = m_pTab_Business_City.Text;
                businessAddress.Region       = m_pTab_Business_Province.Text;
                businessAddress.PostalCode   = m_pTab_Business_ZipCode.Text;
                businessAddress.Country      = m_pTab_Business_Country.Text;
            }
            else{
                m_pvCard.Addresses.Add(
                    DeliveryAddressType_enum.Work,
                    "",
                    "",
                    m_pTab_Business_Street.Text,
                    m_pTab_Business_City.Text,
                    m_pTab_Business_Province.Text,
                    m_pTab_Business_ZipCode.Text,
                    m_pTab_Business_Country.Text
                );
            }            
            if(m_pTab_Business_Company.Text != ""){
                m_pvCard.Organization = m_pTab_Business_Company.Text + ";" + m_pTab_Business_Department.Text + ";" + m_pTab_Business_Office.Text;
            }
            else{
                m_pvCard.Organization = null;
            }
            if(m_pTab_Business_JobTitle.Text != ""){
                m_pvCard.Title = m_pTab_Business_JobTitle.Text;
            }
            else{
                m_pvCard.Title = null;
            }

            PhoneNumber businessPhone = GetPhoneEx(m_pvCard.PhoneNumbers,PhoneNumberType_enum.Work | PhoneNumberType_enum.Voice);
            if(businessPhone != null){
                businessPhone.Number = m_pTab_Business_Phone.Text;
            }
            else{
                m_pvCard.PhoneNumbers.Add(
                    PhoneNumberType_enum.Work | PhoneNumberType_enum.Voice,
                    m_pTab_Business_Phone.Text
                );
            }
            PhoneNumber businessFax = GetPhoneEx(m_pvCard.PhoneNumbers,PhoneNumberType_enum.Work | PhoneNumberType_enum.Fax);
            if(businessFax != null){
                businessFax.Number = m_pTab_Business_Fax.Text;
            }
            else{
                m_pvCard.PhoneNumbers.Add(
                    PhoneNumberType_enum.Work | PhoneNumberType_enum.Fax,
                    m_pTab_Business_Fax.Text
                );
            }
            PhoneNumber pager = GetPhoneEx(m_pvCard.PhoneNumbers,PhoneNumberType_enum.Pager);
            if(pager != null){
                pager.Number = m_pTab_Business_Pager.Text;
            }
            else{
                m_pvCard.PhoneNumbers.Add(
                    PhoneNumberType_enum.Pager,
                    m_pTab_Business_Pager.Text
                );
            }
            if(m_pTab_Business_WWW.Text != ""){
                m_pvCard.WorkURL = m_pTab_Business_WWW.Text;
            }
            else{
                m_pvCard.WorkURL = null;
            }

            #endregion

            #region Notes

            //--- Notes Tab -------------------------------------------------//
            if(m_pTab_Notes_Notes.Text != ""){
                m_pvCard.NoteText = m_pTab_Notes_Notes.Text;
            }
            else{
                m_pvCard.NoteText = null;
            }

            #endregion

            #region Summary

            //--- Summary tab -------------------------------------------------------------//
            if(m_pTab_Summary_Photo.Image != null && m_pTab_Summary_Photo.Image.Tag == null){
                m_pvCard.Photo = m_pTab_Summary_Photo.Image;
            }
            else{
                m_pvCard.Photo = null;
            }

            #endregion
        }

        #endregion

        #region mehtod ClearUIData

        /// <summary>
        /// Clears all active values on UI editable controls.
        /// </summary>
        private void ClearUIData()
        {            
            //--- Tabpage Summary ---------------
            Image noPhotoImage = ResManager.GetImage("nophoto.gif");
            noPhotoImage.Tag = "noimage";
            m_pTab_Summary_Photo.Image = noPhotoImage;
            m_pTab_Summary_Name.Text = "";
            m_pTab_Summary_Email.Text = "";
            m_pTab_Summry_HomePhone.Text = "";
            m_pTab_Summary_Pager.Text = "";
            m_pTab_Summary_Mobile.Text = "";
            m_pTab_Summary_PersonalWWW.Text = "";
            m_pTab_Summary_BusinessPhone.Text = "";
            m_pTab_Summary_BusinessFax.Text = "";
            m_pTab_Summary_JobTitle.Text = "";
            m_pTab_Summary_Department.Text = "";
            m_pTab_Summary_Office.Text = "";
            m_pTab_Summary_Company.Text = "";
            m_pTab_Summary_BusinessWWW.Text = "";
            //--- Tabpage personal --------------- 
            m_pTab_Personal_FirstName.Text = "";
            m_pTab_Personal_MiddleName.Text = "";
            m_pTab_Personal_LastName.Text = "";
            m_pTab_Personal_Title.Text = "";
            m_pTab_Personal_DisplayName.Text = "";
            m_pTab_Personal_Nickname.Text = "";
            m_pTab_Personal_BirthDay.Value = DateTime.Today;
            m_pTab_Personal_BirthDay.Checked = false;
            m_pTab_Personal_Email.Text = "";
            m_pTab_Personal_Emails.Items.Clear();
            //--- Tabpage Home UI ----------------
            m_pTab_Home_Street.Text = "";
            m_pTab_Home_Phone.Text = "";
            m_pTab_Home_Fax.Text = "";
            m_pTab_Home_City.Text = "";
            m_pTab_Home_Mobile.Text = "";
            m_pTab_Home_Province.Text = ""; 
            m_pTab_Home_ZipCode.Text = ""; 
            m_pTab_Home_Country.Text = "";
            m_pTab_Home_WWW.Text = "";
            //--- Tabpage Business UI -------------
            m_pTab_Business_Company.Text = "";
            m_pTab_Business_JobTitle.Text = ""; 
            m_pTab_Business_Street.Text = "";
            m_pTab_Business_Department.Text = "";
            m_pTab_Business_Office.Text = "";
            m_pTab_Business_City.Text = "";
            m_pTab_Business_Phone.Text = "";
            m_pTab_Business_Province.Text = "";
            m_pTab_Business_Fax.Text = "";
            m_pTab_Business_ZipCode.Text = "";
            m_pTab_Business_Pager.Text = "";
            m_pTab_Business_Country.Text = "";
            m_pTab_Business_WWW.Text = "";
            //--- Tabpage Notes UI -----------------
            m_pTab_Notes_Notes.Text = "";
        }

        #endregion


        #region method GetPhone

        /// <summary>
        /// Gets first specified type phone. If there is preferred phone, then it will be returned.
        /// </summary>
        /// <param name="phones">Phone numbers collection to filter.</param>
        /// <param name="type">Phone type to get.</param>
        /// <returns>Returns requested phone or "" if no such phone.</returns>
        private string GetPhone(PhoneNumberCollection phones,PhoneNumberType_enum type)
        {
            PhoneNumber phone = GetPhoneEx(phones,type);
            if(phone != null){
                return phone.Number;
            }
            else{
                return "";
            }
        }

        /// <summary>
        /// Gets first specified type phone. If there is preferred phone, then it will be returned.
        /// </summary>
        /// <param name="phones"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        private PhoneNumber GetPhoneEx(PhoneNumberCollection phones,PhoneNumberType_enum type)
        {
            PhoneNumber retVal = null;
            foreach(PhoneNumber phone in phones){
                // Requested type phone
                if((phone.NumberType & type) == type){
                    // We have preferred requested type address, don't look others any more
                    if((phone.NumberType & PhoneNumberType_enum.Preferred) != 0){
                        return phone;
                    }
                    else{
                        retVal = phone;
                    }
                }
            }

            return retVal;
        }

        #endregion

        #region method GetAddress

        /// <summary>
        /// Gets first specified type address. If there is preferred address, then it will be returned.
        /// Returns null if no address.
        /// </summary>
        /// <param name="addresses"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        private DeliveryAddress GetAddress(DeliveryAddressCollection addresses,DeliveryAddressType_enum type)
        {
            DeliveryAddress retVal = null;
            foreach(DeliveryAddress address in addresses){
                // Requested type address
                if((address.AddressType & type) != 0){
                    // We have preferred requested type address, don't look others any more
                    if((address.AddressType & DeliveryAddressType_enum.Preferred) != 0){
                        return address;
                    }
                    else{
                        retVal = address;
                    }
                }
            }

            return retVal;
        }

       #endregion
        
    }
}
