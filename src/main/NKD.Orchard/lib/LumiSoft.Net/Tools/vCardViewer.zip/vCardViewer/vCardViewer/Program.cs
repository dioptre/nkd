using System;
using System.Collections.Generic;
using System.Windows.Forms;

using LumiSoft.Net.Mime.vCard;

namespace vCardViewer
{
    /// <summary>
    /// Application main class.
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {                        
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new wfrm_Main());
        }
    }
}