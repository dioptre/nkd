﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using System.Xml;
using System.Xml.XPath;

using LumiSoft.Net.UPnP;
using LumiSoft.Net.UPnP.Client;
using LumiSoft.Examples.UPnPClient.Resources;

namespace LumiSoft.Examples.UPnPClient
{
    /// <summary>
    /// Application main UI.
    /// </summary>
    public class wfrm_Main : Form
    {
        private Button   m_pSearch   = null;
        private ListView m_pListView = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Main()
        {
            InitUI(); 
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(500,300);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Text = "UPnP client demo";

            m_pSearch = new Button();
            m_pSearch.Size = new Size(70,20);
            m_pSearch.Location = new Point(420,10);
            m_pSearch.Text = "Search";
            m_pSearch.Click += new EventHandler(m_pSearch_Click);

            ImageList imageList = new ImageList();
            imageList.ImageSize = new Size(48,48);
            imageList.ColorDepth = ColorDepth.Depth32Bit;
            imageList.Images.Add("printer",ResManager.GetIcon("printer.ico",new Size(48,48)));
            imageList.Images.Add("router",ResManager.GetIcon("router.ico",new Size(48,48)));
            imageList.Images.Add("scanner",ResManager.GetIcon("scanner.ico",new Size(48,48)));

            m_pListView = new ListView();
            m_pListView.Size = new Size(500,260);
            m_pListView.Location = new Point(0,40);
            m_pListView.View = View.LargeIcon;
            m_pListView.ShowItemToolTips = true;
            m_pListView.LargeImageList = imageList;
            m_pListView.MouseUp += new MouseEventHandler(m_pListView_MouseUp);

            this.Controls.Add(m_pSearch);
            this.Controls.Add(m_pListView);
        }
                                
        #endregion


        #region Events handling

        #region method m_pSearch_Click

        private void m_pSearch_Click(object sender,EventArgs e)
        {
            m_pListView.Items.Clear();

           UPnP_Client uPnP = new UPnP_Client();
           foreach(UPnP_Device device in uPnP.Search(2)){
               ListViewItem it = new ListViewItem(device.FriendlyName);
               if(device.DeviceType.ToLower().IndexOf("printer") > -1){
                   it.ImageKey = "printer";
               }
               else if(device.DeviceType.ToLower().IndexOf("internetgatewaydevice") > -1){
                   it.ImageKey = "router";
               }
               else{
                   it.ImageKey = "scanner";
               }
               it.ToolTipText = device.ModelDescription;
               it.Tag = device;
               m_pListView.Items.Add(it);
           }
        }

        #endregion

        #region method m_pListView_MouseUp

        private void m_pListView_MouseUp(object sender,MouseEventArgs e)
        {
            if(e.Button != MouseButtons.Right){
                return;
            }
                        
            ContextMenuStrip menu = new ContextMenuStrip();
            // Properties menu item.
            ToolStripMenuItem properties = new ToolStripMenuItem("Properties");
            properties.Click += new EventHandler(delegate(object s1,EventArgs e1){
                Form frm = new Form();
                frm.ClientSize = new Size(600,300);
                frm.StartPosition = FormStartPosition.CenterScreen;
                frm.Text = "UPnP device '" + m_pListView.SelectedItems[0].Text + "' properties:";
                frm.Icon = ResManager.GetIcon("app.ico");

                PropertyGrid propertyGrid = new PropertyGrid();
                propertyGrid.Dock = DockStyle.Fill;
                propertyGrid.SelectedObject = m_pListView.SelectedItems[0].Tag;

                frm.Controls.Add(propertyGrid);

                frm.ShowDialog(this);
            });
            menu.Items.Add(properties);

            menu.Show(Control.MousePosition);
        }

        #endregion

        #endregion
    }
}
