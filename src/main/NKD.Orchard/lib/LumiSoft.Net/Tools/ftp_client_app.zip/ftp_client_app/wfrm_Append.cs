using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using LumiSoft.Net.FTP;
using LumiSoft.Net.FTP.Client;

namespace ftp_client_app
{
    /// <summary>
    /// Append to file window.
    /// </summary>
    public class wfrm_Append : Form
    {
        private Label       mt_Text        = null;
        private ProgressBar m_pProgressBar = null;
        private Button      m_pCancel      = null;
       
        private FTP_Client m_pFtp        = null;
        private string     m_FtpFile     = "";
        private FileStream m_pFileStream = null;
        private Timer      m_pTimer      = null;
        private string     m_Error       = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="ftp">FTP client to use for append.</param>
        /// <param name="ftpFile">File path where to append.</param>
        /// <param name="localFile">Full file path which to append.</param>
        public wfrm_Append(FTP_Client ftp,FTP_ListItem ftpFile,string localFile)
        {
            m_pFtp    = ftp;
            m_FtpFile = ftpFile.Name;

            InitUI();

            m_pFileStream = File.OpenRead(localFile);
            m_pProgressBar.Maximum = (int)m_pFileStream.Length;

            m_pTimer = new Timer();
            m_pTimer.Interval = 1000;
            m_pTimer.Tick += new EventHandler(m_pTimer_Tick);
            m_pTimer.Enabled = true;

            System.Threading.Thread tr = new System.Threading.Thread(new System.Threading.ThreadStart(this.UploadFile));
            tr.Start();
        }
                
        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(400,100);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Text = "Appneding to file '" + m_FtpFile + "'.";

            mt_Text = new Label();
            mt_Text.Size = new Size(380,40);
            mt_Text.Location = new Point(10,10);
            mt_Text.TextAlign = ContentAlignment.MiddleLeft;
            mt_Text.Text = "Appneding to file '" + m_FtpFile + "'.";

            m_pProgressBar = new ProgressBar();
            m_pProgressBar.Size = new Size(300,20);
            m_pProgressBar.Location = new Point(10,60);

            m_pCancel = new Button();
            m_pCancel.Size = new Size(70,20);
            m_pCancel.Location = new Point(320,60);
            m_pCancel.Text = "Cancel";
            m_pCancel.Click += new EventHandler(m_pCancel_Click);

            this.Controls.Add(mt_Text);
            this.Controls.Add(m_pProgressBar);
            this.Controls.Add(m_pCancel);
        }
                
        #endregion


        #region Events Handling

        #region method m_pTimer_Tick

        private void m_pTimer_Tick(object sender,EventArgs e)
        {
            try{
                m_pProgressBar.Value = (int)m_pFileStream.Position;
            }
            catch{
                m_pProgressBar.Value = m_pProgressBar.Maximum;
                m_pTimer.Dispose();
            }
        }

        #endregion

        #region method m_pCancel_Click

        private void m_pCancel_Click(object sender,EventArgs e)
        {
            try{
                m_pFtp.Abort();
            }
            catch(Exception x){
                MessageBox.Show(this,"Error:\n" + x.ToString(),"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        #endregion

        #endregion


        #region method UploadFile

        /// <summary>
        /// Uploads file
        /// </summary>
        private void UploadFile()
        {
            try{
                m_pFtp.AppendToFile(Path.GetFileName(m_FtpFile),m_pFileStream);                
            }
            catch(Exception x){
                m_Error = x.Message;                
            }
            finally{
                m_pFileStream.Close();
            }
            this.Invoke(new MethodInvoker(this.Complete));
        }

        #endregion

        #region method Complete

        /// <summary>
        /// This method is called when upload completes.
        /// </summary>
        private void Complete()
        {
            m_pTimer.Dispose();
            if(m_Error != null){
                MessageBox.Show(this,"Error: " + m_Error,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                this.DialogResult = DialogResult.None;
            }
            else{
                this.DialogResult = DialogResult.OK;
            }
            this.Close();
        }

        #endregion

    }
}
