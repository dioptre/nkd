using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace ftp_client_app
{
    /// <summary>
    /// Textbox window.
    /// </summary>
    public class wfrm_Input : Form
    {
        private TextBox m_Textbox = null;
        private Button  m_pCancel = null;
        private Button  m_pOk     = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="caption">Window caption text.</param>
        /// <param name="value">Textbox value.</param>
        public wfrm_Input(string caption,string value)
        {
            InitUI();

            this.Text      = caption;
            m_Textbox.Text = value;
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(300,80);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Text = "";

            m_Textbox = new TextBox();
            m_Textbox.Size = new Size(280,20);
            m_Textbox.Location = new Point(10,10);

            m_pCancel = new Button();
            m_pCancel.Size = new Size(70,20);
            m_pCancel.Location = new Point(145,40);
            m_pCancel.Text = "Cancel";
            m_pCancel.Click += new EventHandler(m_pCancel_Click);

            m_pOk = new Button();
            m_pOk.Size = new Size(70,20);
            m_pOk.Location = new Point(220,40);
            m_pOk.Text = "Ok";
            m_pOk.Click += new EventHandler(m_pOk_Click);

            this.Controls.Add(m_Textbox);
            this.Controls.Add(m_pCancel);
            this.Controls.Add(m_pOk);
        }
                
        #endregion


        #region Events Handling

        #region method m_pCancel_Click

        private void m_pCancel_Click(object sender,EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        #endregion

        #region method m_pOk_Click

        private void m_pOk_Click(object sender,EventArgs e)
        {
            if(m_Textbox.Text == ""){
                MessageBox.Show(this,"Plase fill name !","Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        #endregion

        #endregion


        #region Properties Implementation

        /// <summary>
        /// Gets textbox text.
        /// </summary>
        public string Value
        {
            get{ return m_Textbox.Text; }
        }

        #endregion


    }
}
