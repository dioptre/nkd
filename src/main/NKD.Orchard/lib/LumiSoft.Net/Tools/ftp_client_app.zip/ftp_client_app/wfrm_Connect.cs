using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using LumiSoft.Net;
using LumiSoft.Net.Log;
using LumiSoft.Net.FTP;
using LumiSoft.Net.FTP.Client;
using ftp_client_app.Resources;

namespace ftp_client_app
{
    /// <summary>
    /// Connecto to FTP server window.
    /// </summary>
    public class wfrm_Connect : Form
    {
        private PictureBox    m_pIcon         = null;
        private Label         mt_Info         = null;
        private GroupBox      m_pSeparator1   = null;
        private Label         mt_Server       = null;
        private TextBox       m_pServer       = null;
        private NumericUpDown m_pPort         = null;
        private Label         mt_SslMode      = null;
        private ComboBox      m_pSslMode      = null;
        private Label         mt_UserName     = null;
        private TextBox       m_pUserName     = null;
        private Label         mt_Password     = null;
        private TextBox       m_pPassword     = null;
        private Label         mt_TransferMode = null;
        private ComboBox      m_pTransferMode = null;
        private GroupBox      m_pSeparator2   = null;
        private Button        m_pCancel       = null;
        private Button        m_pOk           = null;

        private EventHandler<WriteLogEventArgs> m_pLogCallback = null;
        private FTP_Client                      m_pFtp         = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="logCallback">Log callback method.</param>
        public wfrm_Connect(EventHandler<WriteLogEventArgs> logCallback)
        {
            m_pLogCallback = logCallback;

            InitUI();
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(400,230);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Text = "Connecto FTP server.";

            m_pIcon = new PictureBox();
            m_pIcon.Size = new Size(32,32);
            m_pIcon.Location = new Point(10,10);
            m_pIcon.Image = ResManager.GetIcon("server.ico").ToBitmap();

            mt_Info = new Label();
            mt_Info.Size = new Size(200,32);
            mt_Info.Location = new Point(50,10);
            mt_Info.TextAlign = ContentAlignment.MiddleLeft;
            mt_Info.Text = "Specify FTP server information.";

            m_pSeparator1 = new GroupBox();
            m_pSeparator1.Size = new Size(385,3);
            m_pSeparator1.Location = new Point(10,50);

            mt_Server = new Label();
            mt_Server.Size = new Size(100,20);
            mt_Server.Location = new Point(0,70);
            mt_Server.TextAlign = ContentAlignment.MiddleRight;
            mt_Server.Text = "Host:";

            m_pServer = new TextBox();
            m_pServer.Size = new Size(200,20);
            m_pServer.Location = new Point(105,70);

            m_pPort = new NumericUpDown();
            m_pPort.Size = new Size(75,20);
            m_pPort.Location = new Point(310,70);
            m_pPort.Minimum = 1;
            m_pPort.Maximum = 99999;
            m_pPort.Value = WellKnownPorts.FTP_Control;

            mt_SslMode = new Label();
            mt_SslMode.Size = new Size(100,20);
            mt_SslMode.Location = new Point(0,95);
            mt_SslMode.TextAlign = ContentAlignment.MiddleRight;
            mt_SslMode.Text = "SSL Mode:";

            m_pSslMode = new ComboBox();
            m_pSslMode.Size = new Size(100,20);
            m_pSslMode.Location = new Point(105,95);
            m_pSslMode.DropDownStyle = ComboBoxStyle.DropDownList;
            m_pSslMode.SelectedIndexChanged += new EventHandler(m_pSslMode_SelectedIndexChanged);
            m_pSslMode.Items.Add("None");
            m_pSslMode.Items.Add("SSL");
            //m_pSslMode.Items.Add("TLS");
            m_pSslMode.SelectedIndex = 0;

            mt_UserName = new Label();
            mt_UserName.Size = new Size(100,20);
            mt_UserName.Location = new Point(0,120);
            mt_UserName.TextAlign = ContentAlignment.MiddleRight;
            mt_UserName.Text = "User Name:";

            m_pUserName = new TextBox();
            m_pUserName.Size = new Size(200,20);
            m_pUserName.Location = new Point(105,120);

            mt_Password = new Label();
            mt_Password.Size = new Size(100,20);
            mt_Password.Location = new Point(0,145);
            mt_Password.TextAlign = ContentAlignment.MiddleRight;
            mt_Password.Text = "Password:";

            m_pPassword = new TextBox();
            m_pPassword.Size = new Size(200,20);
            m_pPassword.Location = new Point(105,145);
            m_pPassword.PasswordChar = '*';

            mt_TransferMode = new Label();
            mt_TransferMode.Size = new Size(100,20);
            mt_TransferMode.Location = new Point(0,170);
            mt_TransferMode.TextAlign = ContentAlignment.MiddleRight;
            mt_TransferMode.Text = "Transfer mode:";

            m_pTransferMode = new ComboBox();
            m_pTransferMode.Size = new Size(100,20);
            m_pTransferMode.Location = new Point(105,170);
            m_pTransferMode.DropDownStyle = ComboBoxStyle.DropDownList;
            m_pTransferMode.Items.Add("Passive");
            m_pTransferMode.Items.Add("Active");
            m_pTransferMode.SelectedIndex = 0;

            m_pSeparator2 = new GroupBox();
            m_pSeparator2.Size = new Size(383,4);
            m_pSeparator2.Location = new Point(7,195);

            m_pCancel = new Button();
            m_pCancel.Size = new Size(70,20);
            m_pCancel.Location = new Point(240,205);
            m_pCancel.Text = "Cancel";
            m_pCancel.Click += new EventHandler(m_pCancel_Click);

            m_pOk = new Button();
            m_pOk.Size = new Size(70,20);
            m_pOk.Location = new Point(315,205);
            m_pOk.Text = "Ok";
            m_pOk.Click += new EventHandler(m_pOk_Click);

            this.Controls.Add(m_pIcon);
            this.Controls.Add(mt_Info);
            this.Controls.Add(m_pSeparator1);
            this.Controls.Add(mt_Server);
            this.Controls.Add(m_pServer);
            this.Controls.Add(m_pPort);
            this.Controls.Add(mt_SslMode);
            this.Controls.Add(m_pSslMode);
            this.Controls.Add(mt_UserName);
            this.Controls.Add(m_pUserName);
            this.Controls.Add(mt_Password);
            this.Controls.Add(m_pPassword);
            this.Controls.Add(mt_TransferMode);
            this.Controls.Add(m_pTransferMode);
            this.Controls.Add(m_pSeparator2);
            this.Controls.Add(m_pCancel);
            this.Controls.Add(m_pOk);
        }
                                
        #endregion


        #region Events Handling

        #region method m_pSslMode_SelectedIndexChanged

        private void m_pSslMode_SelectedIndexChanged(object sender,EventArgs e)
        {
            if(m_pSslMode.Text == "SSL"){
                m_pPort.Value = WellKnownPorts.FTP_Control_SSL;
            }
            else{
                m_pPort.Value = WellKnownPorts.FTP_Control;
            }
        }

        #endregion


        #region method m_pCancel_Click

        private void m_pCancel_Click(object sender,EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        #endregion

        #region method m_pOk_Click

        private void m_pOk_Click(object sender,EventArgs e)
        {
            if(m_pServer.Text.Trim() == ""){
                MessageBox.Show(this,"Please specify Host value !","Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            FTP_Client ftp = new FTP_Client();
            try{     
                ftp.Logger = new Logger();
                ftp.Logger.WriteLog += m_pLogCallback;
                ftp.Connect(m_pServer.Text,(int)m_pPort.Value,m_pSslMode.SelectedIndex == 1);
                ftp.Authenticate(m_pUserName.Text,m_pPassword.Text);
                if(m_pTransferMode.SelectedIndex == 0){
                    ftp.TransferMode = FTP_TransferMode.Passive;
                }
                else{
                    ftp.TransferMode = FTP_TransferMode.Active;
                }

                m_pFtp = ftp;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch(Exception x){
                MessageBox.Show(this,"Error: " + x.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
                ftp.Dispose();
            }
        }

        #endregion

        #endregion


        #region Properties Implementation

        /// <summary>
        /// Gets connected FTP client. Value null means no connected FTP client.
        /// </summary>
        public FTP_Client FTP
        {
            get{ return m_pFtp; }
        }

        /// <summary>
        /// Gets smart host name.
        /// </summary>
        public string Host
        {
            get{ return m_pServer.Text; }
        }

        /// <summary>
        /// Gets smart host port.
        /// </summary>
        public int Port
        {
            get{ return (int)m_pPort.Value; }
        }

        /// <summary>
        /// Gets smart host SSL mode.
        /// </summary>
        public SslMode SslMode
        {
            get{
                if(m_pSslMode.Text.ToLower() == "ssl"){
                    return SslMode.SSL;
                }
                else if(m_pSslMode.Text.ToLower() == "tls"){
                    return SslMode.TLS;
                }
                else{
                    return SslMode.None; 
                }
            }
        }

        /// <summary>
        /// Gets smart host user name.
        /// </summary>
        public string UserName
        {
            get{ return m_pUserName.Text; }
        }

        /// <summary>
        /// Gets smart host password.
        /// </summary>
        public string Password
        {
            get{ return m_pPassword.Text; }
        }

        #endregion

    }
}
