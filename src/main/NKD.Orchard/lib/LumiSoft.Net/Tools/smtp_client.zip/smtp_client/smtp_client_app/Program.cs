using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace smtp_client_app
{
    /// <summary>
    /// Application main class.
    /// </summary>
    public class Program
    {
        #region method Main

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new wfrm_Main());
        }

        #endregion
    }
}