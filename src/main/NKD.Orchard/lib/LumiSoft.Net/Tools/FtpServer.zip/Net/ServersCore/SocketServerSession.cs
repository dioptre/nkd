using System;

namespace LumiSoft.Net.ServersCore
{
	/// <summary>
	/// This is base class for SocketServer sessions.
	/// </summary>
	public class SocketServerSession
	{
		public SocketServerSession()
		{			
		}
	}
}
