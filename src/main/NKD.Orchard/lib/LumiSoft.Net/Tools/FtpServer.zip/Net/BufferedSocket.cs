using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace LumiSoft.Net
{
	/// <summary>
	/// Summary description for BufferedSocket.
	/// </summary>
	public class BufferedSocket
	{
		private Socket m_pSocket = null;
		private byte[] m_Buffer  = null;
		private long   m_BufPos  = 0;

		/// <summary>
		/// Default constructor.
		/// </summary>
		/// <param name="socket">Source socket which to buffer.</param>
		public BufferedSocket(Socket socket)
		{
			m_pSocket = socket;
			m_Buffer  = new byte[0];
		}


		#region method Receive

		/// <summary>
		/// 
		/// </summary>
		/// <param name="buffer"></param>
		/// <returns></returns>
		public int Receive(byte[] buffer)
		{
			// There isn't data in buffer
			if(m_Buffer.Length == 0){
				byte[] buf = new byte[50000];
				int countReaded = m_pSocket.Receive(buf);
				
				if(countReaded != buf.Length){
					m_Buffer = new byte[countReaded];
					Array.Copy(buf,0,m_Buffer,0,countReaded);
				}
				else{
					m_Buffer = buf;
				}

				m_BufPos = 0;
			}

			int bufLen = m_Buffer.Length - (int)m_BufPos;

			if(bufLen > buffer.Length){
				Array.Copy(m_Buffer,m_BufPos,buffer,0,buffer.Length);

				m_BufPos += buffer.Length;

				return buffer.Length;
			}
			else{
				Array.Copy(m_Buffer,m_BufPos,buffer,0,bufLen);

				// Reset buffer and pos, because we used all data from buffer
				m_Buffer = new byte[0];
				m_BufPos = 0;

				return bufLen;
			}
		}

		#endregion

		#region method Send

		/// <summary>
		/// 
		/// </summary>
		/// <param name="buffer"></param>
		/// <returns></returns>
		public int Send(byte[] buffer)
		{
			return m_pSocket.Send(buffer);
		}

		#endregion


		#region method SetSocketOption

		/// <summary>
		/// 
		/// </summary>
		/// <param name="otpionLevel"></param>
		/// <param name="optionName"></param>
		/// <param name="optionValue"></param>
		public void SetSocketOption(SocketOptionLevel otpionLevel,SocketOptionName optionName,int optionValue)
		{
			m_pSocket.SetSocketOption(otpionLevel,optionName,optionValue);
		}

		#endregion


		#region method Shutdown

		/// <summary>
		/// 
		/// </summary>
		/// <param name="how"></param>
		public void Shutdown(SocketShutdown how)
		{
			m_pSocket.Shutdown(how);
		}

		#endregion

		#region method Close

		/// <summary>
		/// 
		/// </summary>
		public void Close()
		{
			m_pSocket.Close();
			m_Buffer = new byte[0];
		}

		#endregion


		internal void AppendBuffer(byte[] data,int length)
		{
			if(m_Buffer.Length == 0){
				m_Buffer = new byte[length];
				Array.Copy(data,0,m_Buffer,0,length);
			}
			else{
				byte[] newBuff = new byte[m_Buffer.Length + length];
				Array.Copy(m_Buffer,0,newBuff,0,m_Buffer.Length);
				Array.Copy(data,0,newBuff,m_Buffer.Length,length);

				m_Buffer = newBuff;
			}
		}


		#region Properties Implementation

		internal Socket Socket
		{
			get{ return m_pSocket; }
		}

		internal byte[] Buffer
		{
			get{ return m_Buffer; }
		}

		/// <summary>
		/// 
		/// </summary>
		public int Available
		{
			get{ return (m_Buffer.Length - (int)m_BufPos) + m_pSocket.Available; }
		}

		/// <summary>
		/// 
		/// </summary>
		public bool Connected
		{
			get{ return m_pSocket.Connected; }
		}

		/// <summary>
		/// 
		/// </summary>
		public EndPoint LocalEndPoint
		{
			get{ return m_pSocket.LocalEndPoint; }
		}

		/// <summary>
		/// 
		/// </summary>
		public EndPoint RemoteEndPoint
		{
			get{ return m_pSocket.RemoteEndPoint; }
		}

		#endregion
	}
}
