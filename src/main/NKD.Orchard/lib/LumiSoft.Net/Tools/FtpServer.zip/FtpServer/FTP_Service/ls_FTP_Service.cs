using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using LumiSoft.Net.FTP.Server;

namespace LumiSoft.Net.FTP.Server
{
	public class ls_FTP_Service : System.ServiceProcess.ServiceBase
	{
		private System.ComponentModel.IContainer components;		
		private System.Timers.Timer timer1;

		private ArrayList m_pFtpServers  = null;
		private DateTime  m_SettingsDate;        // Holds server Settings.xml date.
		private string    m_SartUpPath   = "";	 // Path where (this)service relies.

		/// <summary>
		/// Default constructor.
		/// </summary>
		public ls_FTP_Service()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitComponent call

			m_pFtpServers = new ArrayList();
		}

		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = new System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new ls_FTP_Service() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}

		#region Designer Generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
			// 
			// timer1
			// 
			this.timer1.Interval = 15000;
			this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.timer1_Elapsed);
			// 
			// Service1
			// 
			this.ServiceName = "Service1";
			((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();

		}

		#endregion

		#region method Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion


		#region method OnStart

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			string filePath     = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
			m_SartUpPath        = filePath.Substring(0,filePath.LastIndexOf('\\')) + "\\";
			Error.ErrorFilePath = m_SartUpPath;
		
			timer1.Enabled = true;
			this.timer1_Elapsed(this,null);
		}

		#endregion

		#region method OnStop
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			timer1.Enabled    = false;
			
			// Stop all ftp servers
			foreach(ls_FTP_Server serv in m_pFtpServers){
				serv.EndServer();
			}
		}

		#endregion


		#region Events handling

		#region method timer1_Elapsed

		private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			try
			{	
				//------------ local settings --------------------------------------------------------------//
				DateTime dateSettings = File.GetLastWriteTime(m_SartUpPath + "\\Settings\\Settings.xml");

				if(DateTime.Compare(dateSettings,m_SettingsDate) != 0){
					m_SettingsDate = dateSettings;

					DataSet ds = new DataSet();
					ds.ReadXml(m_SartUpPath + "\\Settings\\Settings.xml");

					//---- Run servers --------------------------------------//
					foreach(DataRow dr in ds.Tables["Servers"].Rows){
						string ftpRoot = dr["FtpRoot"].ToString();
						if(ftpRoot.EndsWith("\\")){
							ftpRoot = ftpRoot.Substring(0,ftpRoot.Length - 1);
						}

						string ip   = dr["IP"].ToString();
						int    port = Convert.ToInt32(dr["Port"]);

						m_pFtpServers.Add(new ls_FTP_Server(ftpRoot,ip,port));
					}
					//--------------------------------------------------------//
				}				
			}
			catch(Exception x){
				Error.DumpError(x,new System.Diagnostics.StackTrace());
			}
		}

		#endregion

		#endregion

	}
}
