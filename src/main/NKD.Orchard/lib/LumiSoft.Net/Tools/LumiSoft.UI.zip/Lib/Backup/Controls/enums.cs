using System;

namespace LumiSoft.UI.Controls
{
	/// <summary>
	/// 
	/// </summary>
	public enum LeftRight
	{
		/// <summary>
		/// 
		/// </summary>
		Left  = 1,

		/// <summary>
		/// 
		/// </summary>
		Right = 2,
	}
}
