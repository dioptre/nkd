using System;

namespace LumiSoft.UI.Controls.Grid
{
	public enum WGridViewFooterType
	{
		Text = 1,
		Count = 2,
		Sum = 3,
	}
}
