using System;

namespace LumiSoft.UI.Controls
{
	/// <summary>
	/// 
	/// </summary>
	public enum WEditBox_Mask
	{
		/// <summary>
		/// 
		/// </summary>
		Text      = 0,

		/// <summary>
		/// 
		/// </summary>
		Numeric   = 1,


//		IpAddress = 2,

		/// <summary>
		/// 
		/// </summary>
		Date      = 3,
	}

	/// <summary>
	/// 
	/// </summary>
	public enum WEditBox_Style
	{
		/// <summary>
		/// 
		/// </summary>
		Fixed3D = 0,

		/// <summary>
		/// 
		/// </summary>
		Flat    = 1,
	}
}
