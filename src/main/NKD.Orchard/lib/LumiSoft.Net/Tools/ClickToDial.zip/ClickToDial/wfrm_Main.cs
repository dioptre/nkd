﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Threading;

using System.Net.Sockets;

using LumiSoft.Net;
using LumiSoft.Net.SDP;
using LumiSoft.Net.SIP.Message;
using LumiSoft.Net.SIP.Stack;
using LumiSoft.Net.SIP.UA;

namespace ClickToDial
{
    /// <summary>
    /// Application main window.
    /// </summary>
    public partial class wfrm_Main : Form
    {
        private SIP_Stack m_pStack = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Main()
        {
            InitializeComponent();

            m_pStack = new SIP_Stack();
            m_pStack.BindInfo = new IPBindInfo[]{new IPBindInfo("",BindInfoProtocol.UDP,IPAddress.Any,4060)};
            m_pStack.RequestReceived += new EventHandler<SIP_RequestReceivedEventArgs>(m_pStack_RequestReceived);
            m_pStack.Start(); 

            wfrm_Debug stackDebug = new wfrm_Debug(m_pStack);
            stackDebug.Visible = true;
        }
                

        #region Events handling

        #region method m_pStack_RequestReceived

        private void m_pStack_RequestReceived(object sender,SIP_RequestReceivedEventArgs e)
        {
            // We must accpet NOTIFY requests only.
            
            Console.WriteLine(e.ToString());

            if(e.Request.RequestLine.Method == SIP_Methods.NOTIFY){
                e.ServerTransaction.SendResponse(m_pStack.CreateResponse(SIP_ResponseCodes.x200_Ok,e.Request));
                //e.ServerTransaction.SendResponse(m_pStack.CreateResponse(SIP_ResponseCodes.x481_Call_Transaction_Does_Not_Exist,e.Request));
            }
            else if(e.Request.RequestLine.Method == SIP_Methods.BYE){
                e.ServerTransaction.SendResponse(m_pStack.CreateResponse(SIP_ResponseCodes.x200_Ok,e.Request));
                //e.ServerTransaction.SendResponse(m_pStack.CreateResponse(SIP_ResponseCodes.x481_Call_Transaction_Does_Not_Exist,e.Request));
            }
            else if(e.Request.RequestLine.Method == SIP_Methods.ACK){
            }
            else{
                e.ServerTransaction.SendResponse(m_pStack.CreateResponse(SIP_ResponseCodes.x501_Not_Implemented,e.Request));
            }
        }

        #endregion

        #region method referDialog_Notify

        private void referDialog_Notify(object sender,SIP_RequestReceivedEventArgs e)
        {
            e.ServerTransaction.SendResponse(m_pStack.CreateResponse(SIP_ResponseCodes.x200_Ok,e.Request));

            Console.WriteLine("NOTIFY: " + Encoding.UTF8.GetString(e.Request.Data));
        }

        #endregion

        #region method m_pDial_Click

        private void m_pDial_Click(object sender,EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            try{
                SIP_Request invite = m_pStack.CreateRequest(
                    SIP_Methods.INVITE,
                    new SIP_t_NameAddress(null,SIP_Uri.Parse(m_pTo.Text)),
                    new SIP_t_NameAddress(null,SIP_Uri.Parse(m_pFrom.Text))
                );
                invite.Route.Add("<" + m_pProxy.Text+ ";lr>");
                invite.ContentType = "application/sdp";
                
                SDP_Message sdpOffer = new SDP_Message();
                sdpOffer.Version = "0";
                sdpOffer.Origin = new SDP_Origin("-",sdpOffer.GetHashCode(),1,"IN","IP4","192.168.1.111");
                sdpOffer.SessionName = "SIP Call";
                sdpOffer.Connection = new SDP_Connection("IN","IP4","192.168.1.111");
                sdpOffer.Times.Add(new SDP_Time(0,0));
                // Add dummy media.
                SDP_MediaDescription media = new SDP_MediaDescription(SDP_MediaTypes.audio,10000,1,"RTP/AVP",new string[]{"0"});
                sdpOffer.MediaDescriptions.Add(media);

                invite.Data = sdpOffer.ToByte();
                
                SIP_RequestSender requestSender = m_pStack.CreateRequestSender(invite);
                if(m_pUserName.Text.Length > 0){
                    requestSender.Credentials.Add(new NetworkCredential(m_pUserName.Text,m_pPassword.Text,m_pDomain.Text));
                }

                bool   referAccepted = false;
                string errorText     = "";
                AutoResetEvent waitLock = new AutoResetEvent(false);
                requestSender.ResponseReceived += new EventHandler<SIP_ResponseReceivedEventArgs>(delegate(object s1,SIP_ResponseReceivedEventArgs e1){  
                    // REMOVE: Me
                    Console.WriteLine("INVITE: " + e1.Response.StatusCode_ReasonPhrase);

                    if(e1.Response.StatusCodeType == SIP_StatusCodeType.Provisional){
                    }
                    else if(e1.Response.StatusCodeType == SIP_StatusCodeType.Success){
                        SIP_Dialog dialog = (SIP_Dialog_Invite)m_pStack.TransactionLayer.GetOrCreateDialog(e1.ClientTransaction,e1.Response);
                        //dialog.req

                        // Create REFER request.
                        SIP_Request refer = dialog.CreateRequest(SIP_Methods.REFER);
                        refer.ReferTo = new SIP_t_AddressParam("<" + m_pReferTo.Text + ">");
                        
                        SIP_RequestSender referSender = dialog.CreateRequestSender(refer);
                        if(m_pUserName.Text.Length > 0){
                            referSender.Credentials.Add(new NetworkCredential(m_pUserName.Text,m_pPassword.Text,m_pDomain.Text));
                        }
                        referSender.ResponseReceived += new EventHandler<SIP_ResponseReceivedEventArgs>(delegate(object s2,SIP_ResponseReceivedEventArgs e2){
                            // REMOVE: Me
                            Console.WriteLine("REFER: " + e2.Response.StatusCode_ReasonPhrase);

                            if(e2.Response.StatusCodeType == SIP_StatusCodeType.Provisional){
                            }
                            else if(e2.Response.StatusCodeType == SIP_StatusCodeType.Success){
                                // Close inital INVITE.
                                dialog.Terminate();

                                referAccepted = true;
                                waitLock.Set();
                            }
                            else{
                                errorText = e2.Response.StatusCode_ReasonPhrase;
                                waitLock.Set();
                            }
                        });
                        referSender.Completed += new EventHandler(delegate(object s2,EventArgs e2){
                            waitLock.Set();
                        });

                        referSender.Start();
                    }
                    else{
                        errorText = e1.Response.StatusCode_ReasonPhrase;
                        waitLock.Set();
                    }
                });
                requestSender.Completed += new EventHandler(delegate(object s2,EventArgs e2){
                    //waitLock.Set();
                });

                requestSender.Start();
                waitLock.WaitOne();

                if(referAccepted){
                    MessageBox.Show("Refer accepted.");
                }
                else{
                    MessageBox.Show("Refer rejected: " + errorText);
                }
            }
            catch(Exception x){
                MessageBox.Show(this,"Error:" + x.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            this.Cursor = Cursors.Default;
        }
                
        #endregion

        #region method wfrm_Main_FormClosed

        private void wfrm_Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            m_pStack.Stop();
        }

        #endregion

        #endregion

    }
}
