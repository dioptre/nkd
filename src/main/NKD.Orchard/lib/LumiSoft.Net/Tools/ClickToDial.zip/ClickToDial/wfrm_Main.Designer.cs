﻿namespace ClickToDial
{
    partial class wfrm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_pDial = new System.Windows.Forms.Button();
            this.m_pTo = new System.Windows.Forms.TextBox();
            this.m_pFrom = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.m_pProxy = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.m_pReferTo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.m_pDomain = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.mt_UserName = new System.Windows.Forms.Label();
            this.m_pUserName = new System.Windows.Forms.TextBox();
            this.m_pPassword = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // m_pDial
            // 
            this.m_pDial.Location = new System.Drawing.Point(300, 8);
            this.m_pDial.Name = "m_pDial";
            this.m_pDial.Size = new System.Drawing.Size(75, 23);
            this.m_pDial.TabIndex = 0;
            this.m_pDial.Text = "Dial";
            this.m_pDial.UseVisualStyleBackColor = true;
            this.m_pDial.Click += new System.EventHandler(this.m_pDial_Click);
            // 
            // m_pTo
            // 
            this.m_pTo.Location = new System.Drawing.Point(64, 134);
            this.m_pTo.Name = "m_pTo";
            this.m_pTo.Size = new System.Drawing.Size(219, 20);
            this.m_pTo.TabIndex = 1;
            this.m_pTo.Text = "sip:to@domain.com";
            // 
            // m_pFrom
            // 
            this.m_pFrom.Location = new System.Drawing.Point(64, 110);
            this.m_pFrom.Name = "m_pFrom";
            this.m_pFrom.Size = new System.Drawing.Size(219, 20);
            this.m_pFrom.TabIndex = 2;
            this.m_pFrom.Text = "sip:from@domain.com";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "To:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Proxy:";
            // 
            // m_pProxy
            // 
            this.m_pProxy.Location = new System.Drawing.Point(64, 12);
            this.m_pProxy.Name = "m_pProxy";
            this.m_pProxy.Size = new System.Drawing.Size(219, 20);
            this.m_pProxy.TabIndex = 5;
            this.m_pProxy.Text = "sip:server:5060";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Refer To:";
            // 
            // m_pReferTo
            // 
            this.m_pReferTo.Location = new System.Drawing.Point(64, 160);
            this.m_pReferTo.Name = "m_pReferTo";
            this.m_pReferTo.Size = new System.Drawing.Size(219, 20);
            this.m_pReferTo.TabIndex = 7;
            this.m_pReferTo.Text = "sip:referto@domain.com";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Domain:";
            // 
            // m_pDomain
            // 
            this.m_pDomain.Location = new System.Drawing.Point(64, 82);
            this.m_pDomain.Name = "m_pDomain";
            this.m_pDomain.Size = new System.Drawing.Size(219, 20);
            this.m_pDomain.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Password:";
            // 
            // mt_UserName
            // 
            this.mt_UserName.AutoSize = true;
            this.mt_UserName.Location = new System.Drawing.Point(23, 40);
            this.mt_UserName.Name = "mt_UserName";
            this.mt_UserName.Size = new System.Drawing.Size(32, 13);
            this.mt_UserName.TabIndex = 11;
            this.mt_UserName.Text = "User:";
            // 
            // m_pUserName
            // 
            this.m_pUserName.Location = new System.Drawing.Point(64, 35);
            this.m_pUserName.Name = "m_pUserName";
            this.m_pUserName.Size = new System.Drawing.Size(219, 20);
            this.m_pUserName.TabIndex = 10;
            // 
            // m_pPassword
            // 
            this.m_pPassword.Location = new System.Drawing.Point(64, 59);
            this.m_pPassword.Name = "m_pPassword";
            this.m_pPassword.PasswordChar = '*';
            this.m_pPassword.Size = new System.Drawing.Size(219, 20);
            this.m_pPassword.TabIndex = 9;
            // 
            // wfrm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 190);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.m_pDomain);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.mt_UserName);
            this.Controls.Add(this.m_pUserName);
            this.Controls.Add(this.m_pPassword);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.m_pReferTo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.m_pProxy);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.m_pFrom);
            this.Controls.Add(this.m_pTo);
            this.Controls.Add(this.m_pDial);
            this.Name = "wfrm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Click To Dial";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.wfrm_Main_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_pDial;
        private System.Windows.Forms.TextBox m_pTo;
        private System.Windows.Forms.TextBox m_pFrom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox m_pProxy;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox m_pReferTo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox m_pDomain;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label mt_UserName;
        private System.Windows.Forms.TextBox m_pUserName;
        private System.Windows.Forms.TextBox m_pPassword;
    }
}

