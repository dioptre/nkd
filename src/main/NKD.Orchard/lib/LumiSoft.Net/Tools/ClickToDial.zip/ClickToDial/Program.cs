﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ClickToDial
{
    /// <summary>
    /// Application main entry point.
    /// </summary>
    public static class Program
    {
        #region static method Main

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new wfrm_Main());
        }

        #endregion

        #region static method Application_ThreadException

        private static void Application_ThreadException(object sender,System.Threading.ThreadExceptionEventArgs e)
        {
            MessageBox.Show(null,"Error:" + e.Exception.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }

        #endregion
    }
}
