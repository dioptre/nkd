﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using UPnP_NAT.Resources;
using LumiSoft.Net.UPnP.NAT;

namespace UPnP_NAT
{
    /// <summary>
    /// Application main window.
    /// </summary>
    public class wfrm_Main : Form
    {
        private ToolStrip m_pToolbar = null;
        private ListView  m_pList    = null;

        private UPnP_NAT_Client m_pUpnPNat = null;

        /// <summary>
        /// Default constructor.
        /// </summary>
        public wfrm_Main()
        {
            InitUI();

            m_pUpnPNat = new UPnP_NAT_Client();

            if(!m_pUpnPNat.IsSupported){
                m_pToolbar.Enabled = false;

                MessageBox.Show(this,"No UPnP NAT router found !","Info:",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

        #region method InitUI

        /// <summary>
        /// Creates and initializes UI.
        /// </summary>
        private void InitUI()
        {
            this.ClientSize = new Size(700,200);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "UPnP NAT.";
            this.Icon = ResManager.GetIcon("app.ico");

            m_pToolbar = new ToolStrip();            
            m_pToolbar.Dock = DockStyle.None;
            m_pToolbar.AutoSize = false;
            m_pToolbar.Location = new Point(5,5);
            m_pToolbar.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            m_pToolbar.GripStyle = ToolStripGripStyle.Hidden;
            m_pToolbar.BackColor = this.BackColor;
            m_pToolbar.Renderer = new ToolBarRendererEx();
            m_pToolbar.ItemClicked += new ToolStripItemClickedEventHandler(m_pToolbar_ItemClicked);
            // Refresh button
            ToolStripButton button_Refresh = new ToolStripButton();
            button_Refresh.Image = ResManager.GetIcon("refresh.ico").ToBitmap();
            button_Refresh.Name = "refresh";
            button_Refresh.Tag = "refresh";
            button_Refresh.ToolTipText  = "Refresh";
            m_pToolbar.Items.Add(button_Refresh);
            // Add button
            ToolStripButton button_Add = new ToolStripButton();
            button_Add.Image = ResManager.GetIcon("add.ico").ToBitmap();
            button_Add.Name = "add";
            button_Add.Tag = "add";
            button_Add.ToolTipText  = "Add";
            m_pToolbar.Items.Add(button_Add);
            // Delete button
            ToolStripButton button_Delete = new ToolStripButton();
            button_Delete.Enabled = false;
            button_Delete.Image = ResManager.GetIcon("delete.ico").ToBitmap();
            button_Delete.Name = "delete";
            button_Delete.Tag = "delete";
            button_Delete.ToolTipText  = "Delete";
            m_pToolbar.Items.Add(button_Delete);

            m_pList = new ListView();
            m_pList.Size = new Size(700,170);
            m_pList.Location = new Point(0,30);
            m_pList.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            m_pList.View = View.Details;
            m_pList.HideSelection = false;
            m_pList.FullRowSelect = true;
            m_pList.SelectedIndexChanged += new EventHandler(m_pList_SelectedIndexChanged);
            m_pList.Columns.Add("Enabled",60);
            m_pList.Columns.Add("Description",140);
            m_pList.Columns.Add("Proto",40);
            m_pList.Columns.Add("Remote Host",120);
            m_pList.Columns.Add("Remote Port",70);
            m_pList.Columns.Add("Local Host",120);
            m_pList.Columns.Add("Local Port",70);
            m_pList.Columns.Add("Expires",60);

            this.Controls.Add(m_pToolbar);
            this.Controls.Add(m_pList);
        }
                                
        #endregion


        #region Events handling

        #region method m_pToolbar_ItemClicked

        private void m_pToolbar_ItemClicked(object sender,ToolStripItemClickedEventArgs e)
        {
            if(e.ClickedItem.Name == null){
                return;
            }
            else if(e.ClickedItem.Name == "refresh"){
                RefreshList();
            }
            else if(e.ClickedItem.Name == "add"){
                wfrm_Add frm = new wfrm_Add(m_pUpnPNat);
                if(frm.ShowDialog(this) == DialogResult.OK){
                    RefreshList();
                }
            }
            else if(e.ClickedItem.Name == "delete"){
                if(m_pList.SelectedItems.Count > 0){
                    m_pUpnPNat.DeletePortMapping((UPnP_NAT_Map)m_pList.SelectedItems[0].Tag);
                    m_pList.SelectedItems[0].Remove();
                }
            }
        }

        #endregion

        #region method m_pList_SelectedIndexChanged

        private void m_pList_SelectedIndexChanged(object sender,EventArgs e)
        {
            if(m_pList.SelectedItems.Count > 0){
                m_pToolbar.Items["delete"].Enabled = true;
            }
            else{
                m_pToolbar.Items["delete"].Enabled = false;
            }
        }

        #endregion

        #endregion


        #region method RefreshList

        /// <summary>
        /// Refreshes NAT map entries.
        /// </summary>
        private void RefreshList()
        {
            m_pList.Items.Clear();
                m_pToolbar.Items["delete"].Enabled = false;

                foreach(UPnP_NAT_Map map in m_pUpnPNat.GetPortMappings()){
                    ListViewItem it = new ListViewItem(map.Enabled.ToString());
                    it.SubItems.Add(map.Description);
                    it.SubItems.Add(map.Protocol);
                    it.SubItems.Add(map.RemoteHost);
                    it.SubItems.Add(map.ExternalPort);
                    it.SubItems.Add(map.InternalHost);
                    it.SubItems.Add(map.InternalPort.ToString());
                    it.SubItems.Add(map.LeaseDuration.ToString());
                    it.Tag = map;
                    m_pList.Items.Add(it);
                }
        }

        #endregion
    }
}
