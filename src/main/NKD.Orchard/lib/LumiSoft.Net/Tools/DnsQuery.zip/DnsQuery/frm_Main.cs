using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using LumiSoft.Net.DNS;
using LumiSoft.Net.DNS.Client;

namespace DnsQuery
{
	/// <summary>
	/// Main application window.
	/// </summary>
	public class frm_Main : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button m_pQuery;
		private System.Windows.Forms.ComboBox m_pQType;
		private System.Windows.Forms.TextBox m_pQName;
		private System.Windows.Forms.TextBox m_pDnsServer;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.CheckBox m_pCacheResult;
		private System.Windows.Forms.TextBox m_pResults;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Default constructor.
		/// </summary>
		public frm_Main()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			m_pQType.Items.Add("IPv4 host address (A)");
			m_pQType.Items.Add("Name server (NS)");
			m_pQType.Items.Add("Canonical name (CNAME)");
			m_pQType.Items.Add("Start of authority (SOA)");
			m_pQType.Items.Add("Domain name pointer (PTR)");
			m_pQType.Items.Add("Domain name pointer (HINFO)");
			m_pQType.Items.Add("Mail exchange (MX)");
			m_pQType.Items.Add("Text entries (TXT)");
			m_pQType.Items.Add("IPv6 host address (AAAA)");
            m_pQType.Items.Add("Any record (ANY)");
			m_pQType.SelectedIndex = 0;
		}

		#region method Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.m_pQuery = new System.Windows.Forms.Button();
			this.m_pQType = new System.Windows.Forms.ComboBox();
			this.m_pQName = new System.Windows.Forms.TextBox();
			this.m_pDnsServer = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.m_pCacheResult = new System.Windows.Forms.CheckBox();
			this.m_pResults = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			this.SuspendLayout();
			// 
			// m_pQuery
			// 
			this.m_pQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.m_pQuery.Location = new System.Drawing.Point(440, 280);
			this.m_pQuery.Name = "m_pQuery";
			this.m_pQuery.Size = new System.Drawing.Size(64, 24);
			this.m_pQuery.TabIndex = 0;
			this.m_pQuery.Text = "Query";
			this.m_pQuery.Click += new System.EventHandler(this.m_pQuery_Click);
			// 
			// m_pQType
			// 
			this.m_pQType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.m_pQType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.m_pQType.Location = new System.Drawing.Point(280, 280);
			this.m_pQType.Name = "m_pQType";
			this.m_pQType.Size = new System.Drawing.Size(152, 21);
			this.m_pQType.TabIndex = 1;
			// 
			// m_pQName
			// 
			this.m_pQName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.m_pQName.Location = new System.Drawing.Point(16, 280);
			this.m_pQName.Name = "m_pQName";
			this.m_pQName.Size = new System.Drawing.Size(256, 20);
			this.m_pQName.TabIndex = 3;
			this.m_pQName.Text = "";
			// 
			// m_pDnsServer
			// 
			this.m_pDnsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.m_pDnsServer.Location = new System.Drawing.Point(80, 256);
			this.m_pDnsServer.Name = "m_pDnsServer";
			this.m_pDnsServer.Size = new System.Drawing.Size(112, 20);
			this.m_pDnsServer.TabIndex = 4;
			this.m_pDnsServer.Text = "194.126.115.18";
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label1.Location = new System.Drawing.Point(16, 256);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 16);
			this.label1.TabIndex = 5;
			this.label1.Text = "Dns server";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 311);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(520, 22);
			this.statusBar1.TabIndex = 6;
			this.statusBar1.Text = "statusBar1";
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.statusBarPanel1.Text = "Server response:";
			this.statusBarPanel1.Width = 504;
			// 
			// m_pCacheResult
			// 
			this.m_pCacheResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.m_pCacheResult.Location = new System.Drawing.Point(200, 256);
			this.m_pCacheResult.Name = "m_pCacheResult";
			this.m_pCacheResult.Size = new System.Drawing.Size(152, 16);
			this.m_pCacheResult.TabIndex = 7;
			this.m_pCacheResult.Text = "Cache result";
			// 
			// m_pResults
			// 
			this.m_pResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.m_pResults.Location = new System.Drawing.Point(16, 8);
			this.m_pResults.Multiline = true;
			this.m_pResults.Name = "m_pResults";
			this.m_pResults.Size = new System.Drawing.Size(488, 240);
			this.m_pResults.TabIndex = 8;
			this.m_pResults.Text = "";
			// 
			// frm_Main
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(520, 333);
			this.Controls.Add(this.m_pResults);
			this.Controls.Add(this.m_pDnsServer);
			this.Controls.Add(this.m_pQName);
			this.Controls.Add(this.m_pCacheResult);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.m_pQType);
			this.Controls.Add(this.m_pQuery);
			this.Name = "frm_Main";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "DnsQuery";
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		
		#region Events Handling

		private void m_pQuery_Click(object sender, System.EventArgs e)
		{
			try{
				m_pResults.Text = "";

				Dns_Client.DnsServers = new string[]{m_pDnsServer.Text};
                Dns_Client.UseDnsCache = m_pCacheResult.Checked;

				using(Dns_Client dns = new Dns_Client()){
				    DnsServerResponse reponse = null;

				    if(m_pQType.SelectedIndex == 0){
					    reponse = dns.Query(m_pQName.Text,DNS_QType.A);
				    }
				    else if(m_pQType.SelectedIndex == 1){
    					reponse = dns.Query(m_pQName.Text,DNS_QType.NS);
	    			}
		    		else if(m_pQType.SelectedIndex == 2){
			    		reponse = dns.Query(m_pQName.Text,DNS_QType.CNAME);
				    }				
				    else if(m_pQType.SelectedIndex == 3){
					    reponse = dns.Query(m_pQName.Text,DNS_QType.SOA);
    				}
	    			else if(m_pQType.SelectedIndex == 4){
		    			reponse = dns.Query(m_pQName.Text,DNS_QType.PTR);
			    	}
				    else if(m_pQType.SelectedIndex == 5){
					    reponse = dns.Query(m_pQName.Text,DNS_QType.HINFO);
    				}
	    			else if(m_pQType.SelectedIndex == 6){
		    			reponse = dns.Query(m_pQName.Text,DNS_QType.MX);
			    	}
				    else if(m_pQType.SelectedIndex == 7){
					    reponse = dns.Query(m_pQName.Text,DNS_QType.TXT);
				    }
				    else if(m_pQType.SelectedIndex == 8){
					    reponse = dns.Query(m_pQName.Text,DNS_QType.AAAA);
				    }                    
				    else if(m_pQType.SelectedIndex == 9){
					    reponse = dns.Query(m_pQName.Text,DNS_QType.ANY);
				    }

				    if(!reponse.ConnectionOk){
					    statusBarPanel1.Text = "Server response: No connection to DNS server !";
					    return;
				    }

				    statusBarPanel1.Text = "Server response: " + reponse.ResponseCode.ToString();

				    String text = "";
				    text += "//--- Answers ---------------------\r\n";
				    text += Records_To_String(reponse.Answers);
			
				    text += "//--- Authoritive Answers ---------------------\r\n";
				    text += Records_To_String(reponse.AuthoritiveAnswers);
			
				    text += "//--- Additional Answers ---------------------\r\n";
				    text += Records_To_String(reponse.AdditionalAnswers);
									
				    m_pResults.Text = text;
                }
			}
			catch(Exception x){
				System.Windows.Forms.MessageBox.Show(this,"Error:" + x.Message,"Error:",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
		}

		#endregion


		#region method Records_To_String

		/// <summary>
		/// Converts dns record to string.
		/// </summary>
		/// <param name="records"></param>
		/// <returns></returns>
		private String Records_To_String(DNS_rr[] records)
		{
			String text = "";
			
			for(int i=0;i<records.Length;i++){
				DNS_rr record = records[i];
				
				text += "Record: " + (i + 1) + ", Name=\"" + record.Name + "\", Type=" + record.RecordType + ", TTL=" + record.TTL + "\r\n";
				text += " RDATA:\r\n";
				
				if(record.RecordType == DNS_QType.A){	
					DNS_rr_A aRec = (DNS_rr_A)record;
						
					text += "       IP: " + aRec.IP + "\r\n";
				}
				else if(record.RecordType == DNS_QType.NS){
					DNS_rr_NS nsRec = (DNS_rr_NS)record;
						
					text += "       Name Server: " + nsRec.NameServer + "\r\n";
				}
				else if(record.RecordType == DNS_QType.CNAME){
					DNS_rr_CNAME cnameRec = (DNS_rr_CNAME)record;
						
					text += "       Alias: " + cnameRec.Alias + "\r\n";
				}
				else if(record.RecordType == DNS_QType.SOA){
					DNS_rr_SOA soaRec = (DNS_rr_SOA)record;
						
					text += "       Name Server: " + soaRec.NameServer + "\r\n";
					text += "       Admin email: " + soaRec.AdminEmail + "\r\n";					
				}
				else if(record.RecordType == DNS_QType.PTR){
					DNS_rr_PTR ptrRec = (DNS_rr_PTR)record;
						
					text += "       Domain Name: " + ptrRec.DomainName + "\r\n";
				}
				else if(record.RecordType == DNS_QType.HINFO){
					DNS_rr_HINFO hinfoRec = (DNS_rr_HINFO)record;
					
					text += "       OS: " + hinfoRec.OS + "\r\n";
					text += "       CPU: " + hinfoRec.CPU + "\r\n";
				}			
				else if(record.RecordType == DNS_QType.MX){
					DNS_rr_MX mxRec = (DNS_rr_MX)record;
						
					text += "       Pereference: " + mxRec.Preference + "\r\n";
					text += "       Mail Host: " + mxRec.Host + "\r\n";
				}
				else if(record.RecordType == DNS_QType.TXT){
					DNS_rr_TXT txtRec = (DNS_rr_TXT)record;
						
					text += "       Text: " + txtRec.Text + "\r\n";
				}
                else if(record.RecordType == DNS_QType.AAAA){
					DNS_rr_AAAA aRec = (DNS_rr_AAAA)record;
						
					text += "       IP: " + aRec.IP + "\r\n";
				}
				
				text += "\r\n";
			}
			
			return text;
		}

		#endregion

	}
}
