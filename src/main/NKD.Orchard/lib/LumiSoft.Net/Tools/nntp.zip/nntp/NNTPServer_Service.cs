using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Threading; 
using LumiSoft.Net.NNTP;

namespace LumiSoft.Net.NNTP.Server
{
	public class NNTPServer_Service : System.ServiceProcess.ServiceBase
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private NNTP_Server m_pServer	   = null;
		public   static   NNTP_API   m_API = null;		
		private  DataSet  dsSettings       = null;
		internal string   m_connStr        = "";				// Sql connection string to nntp DB.
		internal string   m_NNTPStorePath  = "";
		internal string   m_StartUpPath    = "";
		internal string   m_SettingsPath   = "";		
		private DB_Type   m_DB_Type        = DB_Type.XML;
		private bool	  m_Pulling		   = false;
		private int       m_PullInterval   = 0;
		private System.Timers.Timer timer1;
		private DateTime m_PullTime;
		private Hashtable m_PullTable      = null;

		public NNTPServer_Service()
		{

			InitializeComponent();

			// TODO: Add any initialization after the InitComponent call
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.m_pServer = new LumiSoft.Net.NNTP.Server.NNTP_Server();
			this.timer1 = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.timer1)).BeginInit();
			// 
			// m_pServer
			// 
			this.m_pServer.CommandIdleTimeOut = 10000;
			this.m_pServer.LogCommands = true;
			this.m_pServer.MaxBadCommands = 8;
			this.m_pServer.MaxMessageSize = 1000000;
			this.m_pServer.SessionIdleTimeOut = 10000;
			this.m_pServer.Threads = 2000;
			this.m_pServer.XoverInfo += new LumiSoft.Net.NNTP.Server.XoverInfoHandler(this.m_pServer_XoverInfo);
			this.m_pServer.GroupInfo += new LumiSoft.Net.NNTP.Server.GroupInfoHandler(this.m_pServer_GroupInfo);
			this.m_pServer.GetArticle += new LumiSoft.Net.NNTP.Server.GetArticleHandler(this.m_pServer_GetArticle);
			this.m_pServer.SysError += new LumiSoft.Net.ErrorEventHandler(this.m_pServer_SysError);
			this.m_pServer.NewNews += new LumiSoft.Net.NNTP.Server.NewNewsHandler(this.m_pServer_NewNews);
			this.m_pServer.ListGroups += new LumiSoft.Net.NNTP.Server.ListGroupsHandler(this.m_pServer_ListGroups);
			this.m_pServer.StoreMessage += new LumiSoft.Net.NNTP.Server.StoreMessageHandler(this.m_pServer_StoreMessage);
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 15000;
			this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.timer1_Elapsed);
			// 
			// NNTPServer_Service
			// 
			this.ServiceName = "NNTP Server";
			((System.ComponentModel.ISupportInitialize)(this.timer1)).EndInit();

		}
		#endregion

		#region Dispose
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) 
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Start
		internal void Start()
		{
			OnStart(null);
		}
		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			string filePath     = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
			m_StartUpPath       = filePath.Substring(0,filePath.LastIndexOf('\\')) + "\\";
			m_SettingsPath      = m_StartUpPath + "Settings" + "\\";

			m_API = new NNTP_API(m_SettingsPath);
			m_PullTable = new Hashtable();
    
			LoadSettings();
		}
 
		#endregion
		
		#region Stop
		internal void Stop()
		{
			OnStop();
		}		
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			m_pServer.Enabled = false;
		}

		#endregion

		#region Events
		private void m_pServer_ListGroups(object sender,LumiSoft.Net.NNTP.Server.NNTP_ListGroups_eArgs e)
		{
			m_API.GetGroups(e.Groups);    
		}

		private NNTP_NewsGroup m_pServer_GroupInfo(object sender, LumiSoft.Net.NNTP.Server.NNTP_NewsGroup grp)
		{
			int count = m_API.GetArticleCount(grp.Name);
			int first = m_API.GetMinArticle(grp.Name);
			int last = m_API.GetMaxArticle(grp.Name);
			if(count > -1)
			{								
				grp.ArticlesCount  = count;
				grp.FirstArticleNo = first;
				grp.LastArticleNo  = last;
			}
			else
			{
				grp = null;				
			}
			return grp;
			
		}

		private void m_pServer_XoverInfo(object sender,LumiSoft.Net.NNTP.Server.NNTP_Articles_eArgs e)
		{
			m_API.GetArticles(e.Newsgroup,e.Articles);			
		}

		private string m_pServer_GetArticle(NNTP_Session ses, string id, string retVal)
		{
			return retVal = m_API.GetArticle(ses.SelectedGroup,id,retVal);			
		}

		private string m_pServer_StoreMessage(NNTP_Session ses, MemoryStream msgStream, string[] newsgroups)
		{
			return m_API.StoreMessage(msgStream,newsgroups);
		}

		private void m_pServer_NewNews(object sender, NNTP_Articles_eArgs e, string newsgroups, DateTime since)
		{
			m_API.GetNewNews(newsgroups,since,e.Articles);			
		}

		private void pull_PullComplete(object sender,string server, int newMessages)
		{
			RemovePullThread(server);
			if(m_PullTable.Count == 0)
			{
				m_Pulling = false;
			}
				DataSet dsFeeds = m_API.GetPullFeeds();
			if(newMessages > 0)
			{
				foreach(DataRow dr in dsFeeds.Tables["Feeds"].Rows)
				{
					if(dr["server"].ToString() == server)
					{
						dr["LastSync"]  = DateTime.Now;							 
					}
				}
			}
			dsFeeds.Tables["Feeds"].AcceptChanges();
			m_API.UpdatePullFeeds(dsFeeds);

		}

		private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			timer1.Enabled = false;
			PullNews();
			timer1.Enabled = true;

		}

		#endregion

		#region function AppendDirs

		private void AppendDirs(string path,ArrayList dirsAr,string remPath)
		{
			string[] dirs = Directory.GetDirectories(path);
			foreach(string dir in dirs)
			{
				dirsAr.Add(dir.Substring(remPath.Length).Replace("\\","/"));
				AppendDirs(dir.Replace("\\","/"),dirsAr,remPath);
			}
		}

		#endregion

		#region Pull News
		
		internal void PullNews()
		{
			if(DateTime.Now.CompareTo(m_PullTime.AddSeconds(m_PullInterval)) >= 0 && !m_Pulling)
			{
				DataSet dsFeeds = m_API.GetPullFeeds();
				foreach(DataRow dr in dsFeeds.Tables["Feeds"].Rows)
				{
					NNTP_Pull pull = new NNTP_Pull(this); 					
					pull.Newsgroups = dr["Newsgroups"].ToString();
					pull.PullServer = dr["Server"].ToString();
					pull.PullFrom   = Convert.ToDateTime(dr["LastSync"].ToString());
					
					pull.PullFrom.AddHours(-2); 
					AddPullThread(dr["Server"].ToString(),dr["Newsgroups"].ToString());
					pull.PullComplete +=new PullCompleteHandler(pull_PullComplete);

					// Create New Thread for news pull handling
					ThreadStart tStart = new ThreadStart(pull.Pull);
					Thread      tr     = new Thread(tStart);
					tr.Priority        = ThreadPriority.Lowest;
					tr.Start();

					m_PullTime = DateTime.Now;
					m_Pulling  = true;
				}
			}					
		}
	 

		#endregion

		#region Settings
		private void LoadSettings()
		{

			try
			{
				lock(this)
				{
					dsSettings = m_API.GetSettings();
					
					DataRow dr = dsSettings.Tables["Settings"].Rows[0];
					m_connStr             = dr["ConnectionString"].ToString();
					m_DB_Type             = (DB_Type)Enum.Parse(typeof(DB_Type),dr["DataBaseType"].ToString());
					string nntpStorePath  = dr["NNTPRoot"].ToString();
					if(!nntpStorePath.EndsWith("\\"))
					{
						nntpStorePath += "\\";
					}
					if(nntpStorePath.Length < 3)
					{
						nntpStorePath = m_StartUpPath + "NNTPStore\\";
					}
					m_NNTPStorePath = nntpStorePath;

					m_PullInterval               = Convert.ToInt32(dr["PullInterval"]) * 1000;

					//------- NNTP Settings ---------------------------------------------//					
					m_pServer.IpAddress          = dr["NNTP_IPAddress"].ToString();
					m_pServer.Port               = Convert.ToInt32(dr["NNTP_Port"]);
					m_pServer.Threads            = Convert.ToInt32(dr["NNTP_Threads"]);
					m_pServer.SessionIdleTimeOut = Convert.ToInt32(dr["NNTP_SessionIdleTimeOut"]) * 1000; // Seconds to milliseconds
					m_pServer.CommandIdleTimeOut = Convert.ToInt32(dr["NNTP_CommandIdleTimeOut"]) * 1000; // Seconds to milliseconds
					m_pServer.MaxMessageSize     = Convert.ToInt32(dr["MaxMessageSize"]) * 1000000;       // Mb to byte.
					m_pServer.MaxBadCommands     = Convert.ToInt32(dr["NNTP_MaxBadCommands"]);
					m_pServer.Enabled            = Convert.ToBoolean(dr["NNTP_Enabled"]);

				}
			}
			catch(Exception x)
			{
				Error.DumpError(x,new System.Diagnostics.StackTrace());
			}


		}


		#endregion
 
		#region function AddPullThread

		private void AddPullThread(string server,string data)
		{
			lock(m_PullTable)
			{				
				m_PullTable.Add(server,data);				
			}
		}

		#endregion

		#region function RemovePullThread

		private void RemovePullThread(string server)
		{
			lock(m_PullTable)
			{				
				if(!m_PullTable.ContainsKey(server))
				{
					//Core.WriteLog(m_pServer.m_SartUpPath + "nntpServiceError.log","RemoveThread: doesn't contain");
				}
				m_PullTable.Remove(server);				
			}
		}

		#endregion

		#region function m_pServer_SysError
        
		public void m_pServer_SysError(object sender, LumiSoft.Net.Error_EventArgs e)
		{
			Error.DumpError(e.Exception,e.StackTrace);
		}

		#endregion

		#region Properties
		/// <summary>
		/// Gets api.
		/// </summary>
		public NNTP_API ServerAPI
		{
			get{ return m_API; }			
		}

		/// <summary>
		/// Returns true if currently pulling news
		/// </summary>
		public bool IsPulling
		{
			get{ return m_Pulling; }			
		}

		#endregion

	
	}
}
