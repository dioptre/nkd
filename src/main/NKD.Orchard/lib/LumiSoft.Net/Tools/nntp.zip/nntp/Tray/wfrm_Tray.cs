using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading; 
using LumiSoft.Net.NNTP;
using LumiSoft.Net.NNTP.Server;

namespace LumiSoft.Net.NNTP.Server
{	
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class wfrm_Tray : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;		
		private System.Windows.Forms.Button btnPull;		
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem_Start;
		private System.Windows.Forms.MenuItem menuItem_Stop;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem_Exit;
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		
		private NNTPServer_Service m_NNTPServer	   = null;		


		public wfrm_Tray()
		{			
			InitializeComponent();

			m_NNTPServer = new  NNTPServer_Service();
			m_NNTPServer.Start();
			menuItem_Start.Enabled = false;
			this.WindowState = FormWindowState.Minimized; 
			
		}

		#region method Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(wfrm_Tray));
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.btnPull = new System.Windows.Forms.Button();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem_Start = new System.Windows.Forms.MenuItem();
			this.menuItem_Stop = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem_Exit = new System.Windows.Forms.MenuItem();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 88);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox1.Size = new System.Drawing.Size(560, 328);
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "";
			// 
			// btnPull
			// 
			this.btnPull.Enabled = false;
			this.btnPull.Location = new System.Drawing.Point(8, 56);
			this.btnPull.Name = "btnPull";
			this.btnPull.TabIndex = 3;
			this.btnPull.Text = "pull";
			this.btnPull.Click += new System.EventHandler(this.btnPull_Click);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem_Start,
																						 this.menuItem_Stop,
																						 this.menuItem1,
																						 this.menuItem_Exit});
			// 
			// menuItem_Start
			// 
			this.menuItem_Start.Index = 0;
			this.menuItem_Start.Text = "Start";
			this.menuItem_Start.Click += new System.EventHandler(this.menuItem_Start_Click);
			// 
			// menuItem_Stop
			// 
			this.menuItem_Stop.Index = 1;
			this.menuItem_Stop.Text = "Stop";
			this.menuItem_Stop.Click += new System.EventHandler(this.menuItem_Stop_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 2;
			this.menuItem1.Text = "-";
			// 
			// menuItem_Exit
			// 
			this.menuItem_Exit.Index = 3;
			this.menuItem_Exit.Text = "Exit";
			this.menuItem_Exit.Click += new System.EventHandler(this.menuItem_Exit_Click);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.ContextMenu = this.contextMenu1;
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "NNTPServer";
			this.notifyIcon1.Visible = true;
			// 
			// wfrm_Tray
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 429);
			this.Controls.Add(this.btnPull);
			this.Controls.Add(this.textBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "wfrm_Tray";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "NNTP Server";
			this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		#region Forms events

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void btnPull_Click(object sender, System.EventArgs e)
		{
			m_NNTPServer.PullNews();
		
		}

		private void menuItem_Start_Click(object sender, System.EventArgs e)
		{
			m_NNTPServer.Start();		
			menuItem_Start.Enabled = false;
			menuItem_Stop.Enabled  = true;

		}

		private void menuItem_Stop_Click(object sender, System.EventArgs e)
		{
			m_NNTPServer.Stop();
			menuItem_Start.Enabled = true;
			menuItem_Stop.Enabled  = false;
		}

		private void menuItem_Exit_Click(object sender, System.EventArgs e)
		{
			m_NNTPServer.Stop();
			this.Close();
		}

		#endregion


		#region Debug

		public void AddDebug(string line)
		{

			if(textBox1.Lines.Length > 200)
			{
				textBox1.Text = "";
			}
			textBox1.Lines = ((string)(textBox1.Text + line + "\n")).Split('\n');
		}

		public static void AddDebugS(string line)
		{
			//m_sForm.AddDebug(line);
		}	
	
		#endregion






	}
}
